import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import {
  InstituteSettings,
  Invoice,
  MonthlyPeriodMetrics,
  Payment,
  WeakPointFinding,
} from '../shared/types';
import { formatINR, formatPeriodLabel } from '../shared/finance';

function formatPDFCurrency(paise: number): string {
  const rupees = Math.round(paise) / 100;
  return `INR ${rupees.toLocaleString('en-IN', {
    minimumFractionDigits: paise % 100 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  })}`;
}

export function generatePaymentReceiptPDF(params: {
  payment: Payment;
  invoice: Invoice | undefined;
  settings: InstituteSettings;
}): void {
  const { payment, invoice, settings } = params;
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });

  // Top header band
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, 595, 96, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text(settings.instituteName || 'IIS Institute', 40, 42);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  const addressLine = [settings.address, settings.city, settings.phone, settings.email]
    .filter(Boolean)
    .join('  |  ');
  doc.text(addressLine || 'Academic Excellence & Structured Coaching', 40, 62);
  doc.text('OFFICIAL FEE PAYMENT RECEIPT (ASIA/KOLKATA IST)', 40, 80);

  // Receipt Meta Box
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text(`Receipt No: ${payment.receiptNumber}`, 40, 130);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text(`Payment Date: ${payment.paymentDate}`, 40, 148);
  doc.text(`Billing Month: ${formatPeriodLabel(payment.billingPeriod)}`, 40, 164);
  doc.text(`Payment Mode: ${payment.paymentMethod.replace('_', ' ')}`, 340, 130);
  doc.text(`Status: ${payment.status}`, 340, 148);
  doc.text(`Idempotency Ref: ${payment.idempotencyKey}`, 340, 164);

  autoTable(doc, {
    startY: 186,
    head: [['Student & Course Details', 'Information']],
    body: [
      ['Student Name', payment.studentName],
      ['Course Enrolled', payment.courseName],
      ['Linked Invoice Number', invoice?.invoiceNumber ?? payment.invoiceId],
      ['Invoice Gross Fee', invoice ? formatPDFCurrency(invoice.grossAmountPaise) : '-'],
      ['Scholarship / Discount', invoice ? formatPDFCurrency(invoice.discountPaise) : '-'],
      ['Net Payable on Invoice', invoice ? formatPDFCurrency(invoice.netAmountDuePaise) : '-'],
      ['Amount Received (This Receipt)', formatPDFCurrency(payment.amountPaise)],
      ['Cumulative Paid on Invoice', invoice ? formatPDFCurrency(invoice.paidAmountPaise) : formatPDFCurrency(payment.amountPaise)],
      ['Remaining Balance Due', invoice ? formatPDFCurrency(invoice.balanceDuePaise) : 'INR 0'],
      ['Reference / Remarks', payment.referenceNote || 'Verified payment entry'],
    ],
    theme: 'grid',
    headStyles: { fillColor: [37, 99, 235], textColor: 255, fontStyle: 'bold' },
    styles: { fontSize: 10, cellPadding: 8 },
    columnStyles: {
      0: { fontStyle: 'bold', cellWidth: 210 },
      1: { cellWidth: 305 },
    },
  });

  const finalY = (doc as unknown as { lastAutoTable?: { finalY?: number } }).lastAutoTable?.finalY ?? 460;

  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.text(
    'This computer-generated receipt is verified against atomic ledger records of IIS Institute Management System.',
    40,
    finalY + 36
  );
  doc.text('Authorized Institute Signatory', 410, finalY + 76);
  doc.line(395, finalY + 62, 555, finalY + 62);

  doc.save(`${payment.receiptNumber}.pdf`);
}

export function generateFinancialReportPDF(params: {
  settings: InstituteSettings;
  current: MonthlyPeriodMetrics;
  previous: MonthlyPeriodMetrics;
  trailingSeries: MonthlyPeriodMetrics[];
  findings: WeakPointFinding[];
}): void {
  const { settings, current, previous, trailingSeries, findings } = params;
  const doc = new jsPDF({ unit: 'pt', format: 'a4' });

  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, 595, 88, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(17);
  doc.text(`${settings.instituteName || 'IIS Institute'} — Financial Summary`, 40, 38);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text(
    `Reporting Period: ${current.label} (Compared with ${previous.label})  |  Currency: INR  |  TZ: Asia/Kolkata`,
    40,
    60
  );

  autoTable(doc, {
    startY: 110,
    head: [['Executive Financial Metric', current.label, previous.label]],
    body: [
      ['Invoiced Net Fee Revenue', formatPDFCurrency(current.invoicedNetPaise), formatPDFCurrency(previous.invoicedNetPaise)],
      ['Verified Collected Fee Revenue', formatPDFCurrency(current.collectedFeePaise), formatPDFCurrency(previous.collectedFeePaise)],
      ['Pending Uncollected Balance', formatPDFCurrency(current.pendingBalancePaise), formatPDFCurrency(previous.pendingBalancePaise)],
      ['Collection Realization Rate', `${current.collectionRatePercent.toFixed(1)}%`, `${previous.collectionRatePercent.toFixed(1)}%`],
      ['Accrued Teacher Share Liability', formatPDFCurrency(current.accruedTeacherSharePaise), formatPDFCurrency(previous.accruedTeacherSharePaise)],
      ['Disbursed Teacher Payouts (Cash)', formatPDFCurrency(current.paidTeacherPayoutPaise), formatPDFCurrency(previous.paidTeacherPayoutPaise)],
      ['Unpaid Teacher Share Liability', formatPDFCurrency(current.unpaidTeacherLiabilityPaise), formatPDFCurrency(previous.unpaidTeacherLiabilityPaise)],
      ['Operating Expenses (Non-Teacher)', formatPDFCurrency(current.operatingExpensesPaise), formatPDFCurrency(previous.operatingExpensesPaise)],
      ['Net Operating Income (Accrual)', formatPDFCurrency(current.netOperatingIncomePaise), formatPDFCurrency(previous.netOperatingIncomePaise)],
      ['Net Margin (%)', `${current.netMarginPercent.toFixed(1)}%`, `${previous.netMarginPercent.toFixed(1)}%`],
      ['Active Enrolled Students', String(current.activeStudentsCount), String(previous.activeStudentsCount)],
    ],
    theme: 'striped',
    headStyles: { fillColor: [37, 99, 235], textColor: 255 },
    styles: { fontSize: 9.5, cellPadding: 6 },
  });

  const afterKpiY = (doc as unknown as { lastAutoTable?: { finalY?: number } }).lastAutoTable?.finalY ?? 380;

  autoTable(doc, {
    startY: afterKpiY + 22,
    head: [['Month', 'Collected Fees', 'Teacher Accrued', 'Expenses', 'Net Operating Income', 'Collection %']],
    body: trailingSeries.slice(-6).map((m) => [
      m.label,
      formatPDFCurrency(m.collectedFeePaise),
      formatPDFCurrency(m.accruedTeacherSharePaise),
      formatPDFCurrency(m.operatingExpensesPaise),
      formatPDFCurrency(m.netOperatingIncomePaise),
      `${m.collectionRatePercent.toFixed(1)}%`,
    ]),
    theme: 'grid',
    headStyles: { fillColor: [15, 23, 42], textColor: 255 },
    styles: { fontSize: 8.5, cellPadding: 5 },
  });

  const afterTrendY = (doc as unknown as { lastAutoTable?: { finalY?: number } }).lastAutoTable?.finalY ?? 580;

  if (findings.length > 0 && afterTrendY < 700) {
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('Key Financial Risk & Growth Alerts', 40, afterTrendY + 24);
    autoTable(doc, {
      startY: afterTrendY + 32,
      head: [['Alert Metric', 'Severity', 'Current', 'Finding']],
      body: findings.slice(0, 5).map((f) => [
        f.metricName,
        f.severity.toUpperCase(),
        f.currentValueFormatted.replace(/₹/g, 'INR '),
        f.reason.replace(/₹/g, 'INR '),
      ]),
      theme: 'grid',
      headStyles: { fillColor: [217, 119, 6], textColor: 255 },
      styles: { fontSize: 8, cellPadding: 5 },
    });
  }

  doc.save(`IIS_Financial_Summary_${current.period}.pdf`);
}

export async function downloadServerCSV(params: {
  filename: string;
  headers: string[];
  rows: Array<Array<string | number | null>>;
  idToken: string | null;
  isDemoMode: boolean;
}): Promise<void> {
  const { filename, headers, rows, idToken, isDemoMode } = params;
  const reqHeaders: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (isDemoMode) {
    reqHeaders['X-Demo-Sandbox'] = 'true';
  } else if (idToken) {
    reqHeaders['Authorization'] = `Bearer ${idToken}`;
  }

  const response = await fetch('/api/export/csv', {
    method: 'POST',
    headers: reqHeaders,
    body: JSON.stringify({ filename, headers, rows }),
  });

  if (!response.ok) {
    throw new Error('Failed to export CSV report from server.');
  }

  const blob = await response.blob();
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// Re-export formatINR for convenience in receipt previews
export { formatINR };
