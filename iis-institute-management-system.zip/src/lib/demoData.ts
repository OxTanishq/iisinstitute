import {
  AcademicProgress,
  AllocationStatus,
  AuditLog,
  Batch,
  Course,
  Enrollment,
  Expense,
  ExpenseCategory,
  InstituteSettings,
  Invoice,
  InvoiceStatus,
  Payment,
  PaymentMethod,
  PaymentSchedule,
  PaymentStatus,
  PayoutStatus,
  Student,
  StudentReport,
  Teacher,
  TeacherAgreement,
  TeacherCompensationModel,
  TeacherPayout,
  TeacherShareAllocation,
  UserProfile,
  UserRole,
} from '../shared/types';
import { getCurrentPeriodIST, getTrailingPeriods, shiftPeriod } from '../shared/finance';

export interface DemoDataset {
  users: UserProfile[];
  settings: InstituteSettings;
  courses: Course[];
  batches: Batch[];
  teachers: Teacher[];
  students: Student[];
  enrollments: Enrollment[];
  invoices: Invoice[];
  payments: Payment[];
  agreements: TeacherAgreement[];
  allocations: TeacherShareAllocation[];
  payouts: TeacherPayout[];
  expenses: Expense[];
  reports: StudentReport[];
  auditLogs: AuditLog[];
}

export function buildIsolatedDemoDataset(): DemoDataset {
  const currentPeriod = getCurrentPeriodIST(); // e.g. 2026-10
  const prevPeriod = shiftPeriod(currentPeriod, -1); // e.g. 2026-09
  const trailing12 = getTrailingPeriods(currentPeriod, 12);
  const nowISO = new Date().toISOString();

  const users: UserProfile[] = [
    {
      id: 'demo_admin_1',
      uid: 'demo_admin_1',
      email: 'director@iisinstitute.edu.in',
      displayName: 'Rajeshwar Sharma (Owner)',
      role: UserRole.ADMIN,
      teacherId: '',
      status: 'ACTIVE',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'demo_teacher_uid_1',
      uid: 'demo_teacher_uid_1',
      email: 'ananya.verma@iisinstitute.edu.in',
      displayName: 'Dr. Ananya Verma',
      role: UserRole.TEACHER,
      teacherId: 'tch_1',
      status: 'ACTIVE',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'demo_accountant_uid_1',
      uid: 'demo_accountant_uid_1',
      email: 'accounts@iisinstitute.edu.in',
      displayName: 'Meera Kulkarni (Accountant)',
      role: UserRole.ACCOUNTANT,
      teacherId: '',
      status: 'ACTIVE',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
  ];

  const settings: InstituteSettings = {
    id: 'general',
    instituteName: 'IIS Institute of Science & Commerce',
    logoUrl: '',
    tagline: 'Precision Coaching for Competitive & Board Excellence',
    phone: '+91 98204 51280',
    email: 'office@iisinstitute.edu.in',
    address: '2nd Floor, Vidya Bhavan, Gokhale Road, Dadar West',
    city: 'Mumbai, Maharashtra 400028',
    receiptPrefix: 'IIS',
    defaultDueDay: 10,
    financialYearStartMonth: 4,
    updatedBy: 'demo_admin_1',
    createdAt: nowISO,
    updatedAt: nowISO,
  };

  const viewerUids = ['demo_admin_1', 'demo_accountant_uid_1'];

  const courses: Course[] = [
    {
      id: 'crs_jee',
      code: 'JEE-ADV',
      name: 'JEE Physics & Mathematics',
      subjectCategory: 'Engineering Entrance',
      defaultMonthlyFeePaise: 450000, // ₹4,500
      durationMonths: 12,
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'crs_neet',
      code: 'NEET-BIO',
      name: 'NEET Biology & Chemistry',
      subjectCategory: 'Medical Entrance',
      defaultMonthlyFeePaise: 420000, // ₹4,200
      durationMonths: 12,
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'crs_cbse10',
      code: 'CBSE-X',
      name: 'Class 10 Foundation (Maths & Science)',
      subjectCategory: 'Board Foundation',
      defaultMonthlyFeePaise: 250000, // ₹2,500
      durationMonths: 10,
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'crs_comm',
      code: 'COMM-XII',
      name: 'Class 12 Accountancy & Economics',
      subjectCategory: 'Commerce',
      defaultMonthlyFeePaise: 280000, // ₹2,800
      durationMonths: 10,
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
  ];

  const teachers: Teacher[] = [
    {
      id: 'tch_1',
      teacherCode: 'FAC-101',
      fullName: 'Dr. Ananya Verma',
      email: 'ananya.verma@iisinstitute.edu.in',
      phone: '+91 98112 34091',
      specialization: 'IIT-JEE Physics & Calculus',
      subjects: ['Physics', 'Mathematics'],
      linkedUserUid: 'demo_teacher_uid_1',
      joinedDate: `${trailing12[0]}-01`,
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'tch_2',
      teacherCode: 'FAC-102',
      fullName: 'Prof. Siddharth Nair',
      email: 'siddharth.nair@iisinstitute.edu.in',
      phone: '+91 98230 77812',
      specialization: 'Organic Chemistry & Botany',
      subjects: ['Biology', 'Chemistry'],
      linkedUserUid: '',
      joinedDate: `${trailing12[0]}-01`,
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'tch_3',
      teacherCode: 'FAC-103',
      fullName: 'Kavita Deshmukh',
      email: 'kavita.d@iisinstitute.edu.in',
      phone: '+91 97654 11902',
      specialization: 'CBSE Science & Foundation Maths',
      subjects: ['Science', 'Mathematics'],
      linkedUserUid: '',
      joinedDate: `${trailing12[1]}-05`,
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'tch_4',
      teacherCode: 'FAC-104',
      fullName: 'CA Rohit Malhotra',
      email: 'rohit.malhotra@iisinstitute.edu.in',
      phone: '+91 98901 44321',
      specialization: 'Corporate Accounting & Macroeconomics',
      subjects: ['Accountancy', 'Economics'],
      linkedUserUid: '',
      joinedDate: `${trailing12[2]}-10`,
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
  ];

  const batches: Batch[] = [
    {
      id: 'bat_jee_morn',
      code: 'JEE-M1',
      name: 'JEE Morning Achievers',
      courseId: 'crs_jee',
      courseName: 'JEE Physics & Mathematics',
      teacherId: 'tch_1',
      teacherUid: 'demo_teacher_uid_1',
      teacherName: 'Dr. Ananya Verma',
      scheduleLabel: 'Mon, Wed, Fri · 7:30 AM – 9:30 AM',
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'bat_neet_eve',
      code: 'NEET-E1',
      name: 'NEET Target Batch',
      courseId: 'crs_neet',
      courseName: 'NEET Biology & Chemistry',
      teacherId: 'tch_2',
      teacherUid: '',
      teacherName: 'Prof. Siddharth Nair',
      scheduleLabel: 'Tue, Thu, Sat · 4:30 PM – 6:30 PM',
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'bat_cbse_aft',
      code: 'CBSE-A1',
      name: 'Class 10 Merit Batch',
      courseId: 'crs_cbse10',
      courseName: 'Class 10 Foundation (Maths & Science)',
      teacherId: 'tch_3',
      teacherUid: '',
      teacherName: 'Kavita Deshmukh',
      scheduleLabel: 'Mon–Fri · 3:00 PM – 4:15 PM',
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'bat_comm_eve',
      code: 'COMM-E1',
      name: 'Commerce Board Scholars',
      courseId: 'crs_comm',
      courseName: 'Class 12 Accountancy & Economics',
      teacherId: 'tch_4',
      teacherUid: '',
      teacherName: 'CA Rohit Malhotra',
      scheduleLabel: 'Tue, Thu, Sat · 6:45 PM – 8:15 PM',
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
  ];

  const agreements: TeacherAgreement[] = [
    {
      id: 'agr_1',
      teacherId: 'tch_1',
      teacherUid: 'demo_teacher_uid_1',
      teacherName: 'Dr. Ananya Verma',
      modelType: TeacherCompensationModel.PERCENTAGE,
      fixedMonthlyPaise: 0,
      shareBasisPoints: 4000, // 40% share!
      perStudentPaise: 0,
      effectiveFrom: `${trailing12[0]}-01`,
      effectiveTo: '',
      notes: '40% revenue share on collected JEE student fees',
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'agr_2',
      teacherId: 'tch_2',
      teacherUid: '',
      teacherName: 'Prof. Siddharth Nair',
      modelType: TeacherCompensationModel.PERCENTAGE,
      fixedMonthlyPaise: 0,
      shareBasisPoints: 3500, // 35%
      perStudentPaise: 0,
      effectiveFrom: `${trailing12[0]}-01`,
      effectiveTo: '',
      notes: '35% share on collected NEET fees',
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'agr_3',
      teacherId: 'tch_3',
      teacherUid: '',
      teacherName: 'Kavita Deshmukh',
      modelType: TeacherCompensationModel.FIXED_SALARY,
      fixedMonthlyPaise: 900000, // ₹9,000 fixed retainer
      shareBasisPoints: 0,
      perStudentPaise: 0,
      effectiveFrom: `${trailing12[0]}-01`,
      effectiveTo: '',
      notes: 'Fixed monthly faculty salary for Class 10 batch',
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'agr_4',
      teacherId: 'tch_4',
      teacherUid: '',
      teacherName: 'CA Rohit Malhotra',
      modelType: TeacherCompensationModel.PER_STUDENT,
      fixedMonthlyPaise: 0,
      shareBasisPoints: 0,
      perStudentPaise: 95000, // ₹950 per student
      effectiveFrom: `${trailing12[0]}-01`,
      effectiveTo: '',
      notes: '₹950 per active paid Commerce student per month',
      status: 'ACTIVE',
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
  ];

  const studentSpecs = [
    { id: 'stu_1', code: 'IIS-2026-001', name: 'Aarav Kulkarni', crs: courses[0], bat: batches[0], tch: teachers[0], enrollIdx: 0, guardian: 'Sandeep Kulkarni', phone: '+91 98201 11201' },
    { id: 'stu_2', code: 'IIS-2026-002', name: 'Diya Chatterjee', crs: courses[0], bat: batches[0], tch: teachers[0], enrollIdx: 1, guardian: 'Subhash Chatterjee', phone: '+91 98201 11202' },
    { id: 'stu_3', code: 'IIS-2026-003', name: 'Rohan Joshi', crs: courses[0], bat: batches[0], tch: teachers[0], enrollIdx: 2, guardian: 'Prakash Joshi', phone: '+91 98201 11203' },
    { id: 'stu_4', code: 'IIS-2026-004', name: 'Ishita Banerjee', crs: courses[0], bat: batches[0], tch: teachers[0], enrollIdx: 5, guardian: 'malay Banerjee', phone: '+91 98201 11204' },
    { id: 'stu_5', code: 'IIS-2026-005', name: 'Vivaan Iyer', crs: courses[1], bat: batches[1], tch: teachers[1], enrollIdx: 0, guardian: 'Ramesh Iyer', phone: '+91 98201 11205' },
    { id: 'stu_6', code: 'IIS-2026-006', name: 'Saanvi Menon', crs: courses[1], bat: batches[1], tch: teachers[1], enrollIdx: 2, guardian: 'Harish Menon', phone: '+91 98201 11206' },
    { id: 'stu_7', code: 'IIS-2026-007', name: 'Kabir Sengupta', crs: courses[1], bat: batches[1], tch: teachers[1], enrollIdx: 4, guardian: 'joydeep Sengupta', phone: '+91 98201 11207' },
    { id: 'stu_8', code: 'IIS-2026-008', name: 'Anika Reddy', crs: courses[2], bat: batches[2], tch: teachers[2], enrollIdx: 1, guardian: 'Venkatesh Reddy', phone: '+91 98201 11208' },
    { id: 'stu_9', code: 'IIS-2026-009', name: 'ArjunPatel', crs: courses[2], bat: batches[2], tch: teachers[2], enrollIdx: 3, guardian: 'Ketan Patel', phone: '+91 98201 11209' },
    { id: 'stu_10', code: 'IIS-2026-010', name: 'Neha Gokhale', crs: courses[2], bat: batches[2], tch: teachers[2], enrollIdx: 8, guardian: 'Milind Gokhale', phone: '+91 98201 11210' },
    { id: 'stu_11', code: 'IIS-2026-011', name: 'Pranav Agarwal', crs: courses[3], bat: batches[3], tch: teachers[3], enrollIdx: 3, guardian: 'Manoj Agarwal', phone: '+91 98201 11211' },
    { id: 'stu_12', code: 'IIS-2026-012', name: 'Tanvi Kapoor', crs: courses[3], bat: batches[3], tch: teachers[3], enrollIdx: 11, guardian: 'Vikram Kapoor', phone: '+91 98201 11212' },
  ];

  const students: Student[] = studentSpecs.map((s) => ({
    id: s.id,
    studentCode: s.code,
    fullName: s.name === 'ArjunPatel' ? 'Arjun Patel' : s.name,
    primaryCourseId: s.crs.id,
    primaryCourseName: s.crs.name,
    courseIds: [s.crs.id],
    batchId: s.bat.id,
    batchName: s.bat.name,
    enrollmentDate: `${trailing12[s.enrollIdx]}-04`,
    monthlyFeePaise: s.crs.defaultMonthlyFeePaise,
    paymentSchedule: PaymentSchedule.MONTHLY,
    status: 'ACTIVE',
    guardianName: s.guardian,
    guardianPhone: s.phone,
    assignedTeacherId: s.tch.id,
    assignedTeacherUid: s.tch.linkedUserUid,
    assignedTeacherName: s.tch.fullName,
    financeViewerUids: viewerUids,
    createdBy: 'demo_admin_1',
    createdAt: nowISO,
    updatedAt: nowISO,
  }));

  const enrollments: Enrollment[] = students.map((stu) => ({
    id: `enr_${stu.id}_${stu.primaryCourseId}`,
    studentId: stu.id,
    studentName: stu.fullName,
    courseId: stu.primaryCourseId,
    courseName: stu.primaryCourseName,
    batchId: stu.batchId,
    teacherId: stu.assignedTeacherId,
    assignedTeacherUid: stu.assignedTeacherUid,
    agreedFeePaise: stu.monthlyFeePaise,
    startDate: stu.enrollmentDate,
    status: 'ACTIVE',
    financeViewerUids: viewerUids,
    createdBy: 'demo_admin_1',
    createdAt: nowISO,
    updatedAt: nowISO,
  }));

  const invoices: Invoice[] = [];
  const payments: Payment[] = [];
  const allocations: TeacherShareAllocation[] = [];
  const payouts: TeacherPayout[] = [];
  const expenses: Expense[] = [];

  let invSeq = 1001;
  let rcptSeq = 5001;
  let payoutSeq = 301;

  trailing12.forEach((period, mIdx) => {
    const isCurrent = period === currentPeriod;
    const isPrev = period === prevPeriod;

    // Fixed monthly salary allocation for tch_3
    allocations.push({
      id: `alloc_salary_tch_3_${period}`,
      agreementId: 'agr_3',
      modelTypeSnapshot: TeacherCompensationModel.FIXED_SALARY,
      rateSnapshotLabel: 'Fixed salary (₹9,000/mo)',
      teacherId: 'tch_3',
      teacherUid: '',
      teacherName: 'Kavita Deshmukh',
      paymentId: '',
      invoiceId: '',
      studentId: '',
      studentName: 'Batch Retainer',
      billingPeriod: period,
      basisAmountPaise: 900000,
      allocatedAmountPaise: 900000,
      status: isCurrent ? AllocationStatus.ACCRUED : AllocationStatus.SETTLED,
      payoutId: isCurrent ? '' : `po_tch_3_${period}`,
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    });

    students.forEach((stu, sIdx) => {
      if (stu.enrollmentDate.slice(0, 7) > period) return;

      const invId = `inv_${period}_${stu.id}`;
      const gross = stu.monthlyFeePaise;
      const discount = sIdx === 1 ? 30000 : 0; // ₹300 scholarship for Diya
      const net = gross - discount;
      const dueDate = `${period}-10`;

      // Realistic collection behavior: historical months 100% paid, prev month ~92% paid, current month has paid, partial, and overdue items so weak-point alerts & receivables table shine!
      let paid = net;
      let status: InvoiceStatus = InvoiceStatus.PAID;

      if (isCurrent) {
        if (sIdx === 2 || sIdx === 6 || sIdx === 10) {
          // Unpaid overdue/pending in current month
          paid = 0;
          status = InvoiceStatus.OVERDUE;
        } else if (sIdx === 3 || sIdx === 9) {
          // Partial installment paid
          paid = Math.round(net * 0.5);
          status = InvoiceStatus.PARTIAL;
        }
      } else if (isPrev && sIdx === 6) {
        paid = Math.round(net * 0.5);
        status = InvoiceStatus.OVERDUE;
      }

      const balance = net - paid;
      invoices.push({
        id: invId,
        invoiceNumber: `IIS-INV-${invSeq++}`,
        studentId: stu.id,
        studentName: stu.fullName,
        courseId: stu.primaryCourseId,
        courseName: stu.primaryCourseName,
        batchId: stu.batchId,
        billingPeriod: period,
        grossAmountPaise: gross,
        discountPaise: discount,
        netAmountDuePaise: net,
        paidAmountPaise: paid,
        balanceDuePaise: balance,
        dueDate,
        status,
        assignedTeacherId: stu.assignedTeacherId,
        notes: discount > 0 ? 'Merit fee concession applied' : '',
        financeViewerUids: viewerUids,
        createdBy: 'demo_admin_1',
        createdAt: nowISO,
        updatedAt: nowISO,
      });

      if (paid > 0) {
        const payId = `pay_${period}_${stu.id}`;
        const methods = [PaymentMethod.UPI, PaymentMethod.BANK_TRANSFER, PaymentMethod.CASH];
        const method = methods[(sIdx + mIdx) % methods.length];
        payments.push({
          id: payId,
          receiptNumber: `IIS-RCP-${rcptSeq++}`,
          idempotencyKey: `idem_${period}_${stu.id}_1`,
          invoiceId: invId,
          studentId: stu.id,
          studentName: stu.fullName,
          courseId: stu.primaryCourseId,
          courseName: stu.primaryCourseName,
          billingPeriod: period,
          amountPaise: paid,
          paymentMethod: method,
          paymentDate: `${period}-0${(sIdx % 8) + 1}`,
          referenceNote: method === PaymentMethod.UPI ? 'UPI Verified Settlement' : 'Front-desk collection',
          status: PaymentStatus.COMPLETED,
          reversalReason: '',
          financeViewerUids: viewerUids,
          recordedBy: 'demo_admin_1',
          createdAt: nowISO,
          updatedAt: nowISO,
        });

        // Allocate teacher share
        if (stu.assignedTeacherId === 'tch_1') {
          const share = Math.round((paid * 4000) / 10000);
          allocations.push({
            id: `alloc_${payId}_tch_1`,
            agreementId: 'agr_1',
            modelTypeSnapshot: TeacherCompensationModel.PERCENTAGE,
            rateSnapshotLabel: '40% of collected fee',
            teacherId: 'tch_1',
            teacherUid: 'demo_teacher_uid_1',
            teacherName: 'Dr. Ananya Verma',
            paymentId: payId,
            invoiceId: invId,
            studentId: stu.id,
            studentName: stu.fullName,
            billingPeriod: period,
            basisAmountPaise: paid,
            allocatedAmountPaise: share,
            status: isCurrent ? AllocationStatus.ACCRUED : AllocationStatus.SETTLED,
            payoutId: isCurrent ? '' : `po_tch_1_${period}`,
            financeViewerUids: viewerUids,
            createdBy: 'demo_admin_1',
            createdAt: nowISO,
            updatedAt: nowISO,
          });
        } else if (stu.assignedTeacherId === 'tch_2') {
          const share = Math.round((paid * 3500) / 10000);
          allocations.push({
            id: `alloc_${payId}_tch_2`,
            agreementId: 'agr_2',
            modelTypeSnapshot: TeacherCompensationModel.PERCENTAGE,
            rateSnapshotLabel: '35% of collected fee',
            teacherId: 'tch_2',
            teacherUid: '',
            teacherName: 'Prof. Siddharth Nair',
            paymentId: payId,
            invoiceId: invId,
            studentId: stu.id,
            studentName: stu.fullName,
            billingPeriod: period,
            basisAmountPaise: paid,
            allocatedAmountPaise: share,
            status: isCurrent ? AllocationStatus.ACCRUED : AllocationStatus.SETTLED,
            payoutId: isCurrent ? '' : `po_tch_2_${period}`,
            financeViewerUids: viewerUids,
            createdBy: 'demo_admin_1',
            createdAt: nowISO,
            updatedAt: nowISO,
          });
        } else if (stu.assignedTeacherId === 'tch_4') {
          allocations.push({
            id: `alloc_${payId}_tch_4`,
            agreementId: 'agr_4',
            modelTypeSnapshot: TeacherCompensationModel.PER_STUDENT,
            rateSnapshotLabel: '₹950 per active paid student',
            teacherId: 'tch_4',
            teacherUid: '',
            teacherName: 'CA Rohit Malhotra',
            paymentId: payId,
            invoiceId: invId,
            studentId: stu.id,
            studentName: stu.fullName,
            billingPeriod: period,
            basisAmountPaise: paid,
            allocatedAmountPaise: 95000,
            status: isCurrent ? AllocationStatus.ACCRUED : AllocationStatus.SETTLED,
            payoutId: isCurrent ? '' : `po_tch_4_${period}`,
            financeViewerUids: viewerUids,
            createdBy: 'demo_admin_1',
            createdAt: nowISO,
            updatedAt: nowISO,
          });
        }
      }
    });

    // Disburse teacher payouts for completed historical months (and partial payout in current month)
    teachers.forEach((tch) => {
      const periodTeacherAccrued = allocations
        .filter((a) => a.teacherId === tch.id && a.billingPeriod === period)
        .reduce((s, a) => s + a.allocatedAmountPaise, 0);

      if (periodTeacherAccrued <= 0) return;

      if (!isCurrent) {
        payouts.push({
          id: `po_${tch.id}_${period}`,
          payoutNumber: `IIS-PAY-${payoutSeq++}`,
          teacherId: tch.id,
          teacherUid: tch.linkedUserUid,
          teacherName: tch.fullName,
          billingPeriod: period,
          amountPaise: periodTeacherAccrued,
          paymentMethod: PaymentMethod.BANK_TRANSFER,
          payoutDate: `${period}-28`,
          referenceNote: `Monthly settlement for ${period}`,
          status: PayoutStatus.PAID,
          financeViewerUids: viewerUids,
          createdBy: 'demo_admin_1',
          createdAt: nowISO,
          updatedAt: nowISO,
        });
      } else if (tch.id === 'tch_3') {
        // Partial advance paid in current month so both paid & unpaid liability are visible
        payouts.push({
          id: `po_${tch.id}_${period}_adv`,
          payoutNumber: `IIS-PAY-${payoutSeq++}`,
          teacherId: tch.id,
          teacherUid: tch.linkedUserUid,
          teacherName: tch.fullName,
          billingPeriod: period,
          amountPaise: 450000,
          paymentMethod: PaymentMethod.UPI,
          payoutDate: `${period}-12`,
          referenceNote: 'Mid-month salary advance',
          status: PayoutStatus.PAID,
          financeViewerUids: viewerUids,
          createdBy: 'demo_admin_1',
          createdAt: nowISO,
          updatedAt: nowISO,
        });
      }
    });

    // Operating expenses per month
    expenses.push(
      {
        id: `exp_rent_${period}`,
        title: 'Classroom Suite Rent — Dadar West',
        category: ExpenseCategory.RENT,
        amountPaise: 850000, // ₹8,500
        expenseDate: `${period}-03`,
        billingPeriod: period,
        paymentMethod: PaymentMethod.BANK_TRANSFER,
        vendorName: 'Vidya Bhavan Trust',
        notes: 'Monthly classroom lease',
        status: 'RECORDED',
        financeViewerUids: viewerUids,
        createdBy: 'demo_admin_1',
        createdAt: nowISO,
        updatedAt: nowISO,
      },
      {
        id: `exp_util_${period}`,
        title: 'Electricity, AC & Fiber Broadband',
        category: ExpenseCategory.UTILITIES,
        amountPaise: isCurrent ? 260000 : 195000,
        expenseDate: `${period}-08`,
        billingPeriod: period,
        paymentMethod: PaymentMethod.UPI,
        vendorName: 'BEST Power & Airtel Business',
        notes: 'Campus utilities',
        status: 'RECORDED',
        financeViewerUids: viewerUids,
        createdBy: 'demo_admin_1',
        createdAt: nowISO,
        updatedAt: nowISO,
      },
      {
        id: `exp_mat_${period}`,
        title: 'Printed Test Series & DPPs',
        category: ExpenseCategory.MATERIALS,
        amountPaise: isCurrent ? 240000 : 140000,
        expenseDate: `${period}-14`,
        billingPeriod: period,
        paymentMethod: PaymentMethod.UPI,
        vendorName: 'Shree Print Pack',
        notes: 'Monthly mock test booklets',
        status: 'RECORDED',
        financeViewerUids: viewerUids,
        createdBy: 'demo_admin_1',
        createdAt: nowISO,
        updatedAt: nowISO,
      }
    );

    if (isCurrent) {
      expenses.push({
        id: `exp_mkt_${period}`,
        title: 'Board Exam Admissions Campaign',
        category: ExpenseCategory.MARKETING,
        amountPaise: 320000, // ₹3,200 spike in current month to trigger realistic expense & margin insights
        expenseDate: `${period}-15`,
        billingPeriod: period,
        paymentMethod: PaymentMethod.UPI,
        vendorName: 'Local Print & Digital Ads',
        notes: 'Pre-board batch outreach',
        status: 'RECORDED',
        financeViewerUids: viewerUids,
        createdBy: 'demo_admin_1',
        createdAt: nowISO,
        updatedAt: nowISO,
      });
    }
  });

  const reports: StudentReport[] = [
    {
      id: 'rep_1',
      studentId: 'stu_1',
      studentName: 'Aarav Kulkarni',
      courseId: 'crs_jee',
      courseName: 'JEE Physics & Mathematics',
      teacherId: 'tch_1',
      teacherUid: 'demo_teacher_uid_1',
      teacherName: 'Dr. Ananya Verma',
      reportingPeriod: currentPeriod,
      subject: 'Rotational Mechanics & Definite Integration',
      attendancePercent: 96,
      testMarks: 268,
      maxMarks: 300,
      academicProgress: AcademicProgress.EXCELLENT,
      strengths: 'Fast multi-concept problem formulation and vector torque diagrams.',
      areasForImprovement: 'Avoid sign errors under final 15-minute mock pressure.',
      teacherComments: 'Consistently top 2 in JEE Morning Achievers.',
      submissionDate: `${currentPeriod}-18`,
      financeViewerUids: viewerUids,
      createdBy: 'demo_teacher_uid_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'rep_2',
      studentId: 'stu_2',
      studentName: 'Diya Chatterjee',
      courseId: 'crs_jee',
      courseName: 'JEE Physics & Mathematics',
      teacherId: 'tch_1',
      teacherUid: 'demo_teacher_uid_1',
      teacherName: 'Dr. Ananya Verma',
      reportingPeriod: currentPeriod,
      subject: 'Electrostatics & Differential Equations',
      attendancePercent: 92,
      testMarks: 249,
      maxMarks: 300,
      academicProgress: AcademicProgress.GOOD,
      strengths: 'Strong conceptual clarity in Gauss Law applications.',
      areasForImprovement: 'Practice timed integer-type questions daily.',
      teacherComments: 'Well-disciplined; steady upward trajectory since August.',
      submissionDate: `${currentPeriod}-18`,
      financeViewerUids: viewerUids,
      createdBy: 'demo_teacher_uid_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'rep_3',
      studentId: 'stu_3',
      studentName: 'Rohan Joshi',
      courseId: 'crs_jee',
      courseName: 'JEE Physics & Mathematics',
      teacherId: 'tch_1',
      teacherUid: 'demo_teacher_uid_1',
      teacherName: 'Dr. Ananya Verma',
      reportingPeriod: currentPeriod,
      subject: 'Electrostatics & Differential Equations',
      attendancePercent: 74,
      testMarks: 162,
      maxMarks: 300,
      academicProgress: AcademicProgress.NEEDS_ATTENTION,
      strengths: 'Participates actively when present in doubt sessions.',
      areasForImprovement: 'Missed 4 morning lectures; DPP backlog in integration.',
      teacherComments: 'Parent meeting scheduled to improve morning attendance.',
      submissionDate: `${currentPeriod}-19`,
      financeViewerUids: viewerUids,
      createdBy: 'demo_teacher_uid_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'rep_4',
      studentId: 'stu_5',
      studentName: 'Vivaan Iyer',
      courseId: 'crs_neet',
      courseName: 'NEET Biology & Chemistry',
      teacherId: 'tch_2',
      teacherUid: '',
      teacherName: 'Prof. Siddharth Nair',
      reportingPeriod: currentPeriod,
      subject: 'Human Physiology & Reaction Mechanisms',
      attendancePercent: 98,
      testMarks: 652,
      maxMarks: 720,
      academicProgress: AcademicProgress.EXCELLENT,
      strengths: 'Near-100% NCERT retention in Human Physiology.',
      areasForImprovement: 'Speed up physical chemistry numericals.',
      teacherComments: 'Strong contender for top medical merit rank.',
      submissionDate: `${currentPeriod}-20`,
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
    {
      id: 'rep_5',
      studentId: 'stu_8',
      studentName: 'Anika Reddy',
      courseId: 'crs_cbse10',
      courseName: 'Class 10 Foundation (Maths & Science)',
      teacherId: 'tch_3',
      teacherUid: '',
      teacherName: 'Kavita Deshmukh',
      reportingPeriod: currentPeriod,
      subject: 'Trigonometry & Light Reflection',
      attendancePercent: 94,
      testMarks: 74,
      maxMarks: 80,
      academicProgress: AcademicProgress.EXCELLENT,
      strengths: 'Neat stepwise board presentation and ray diagrams.',
      areasForImprovement: 'Review identity proofs from exemplar exercises.',
      teacherComments: 'Excellent consistency across weekly unit tests.',
      submissionDate: `${currentPeriod}-21`,
      financeViewerUids: viewerUids,
      createdBy: 'demo_admin_1',
      createdAt: nowISO,
      updatedAt: nowISO,
    },
  ];

  const auditLogs: AuditLog[] = [
    {
      id: 'aud_1',
      actorUid: 'demo_admin_1',
      actorEmail: 'director@iisinstitute.edu.in',
      actorRole: UserRole.ADMIN,
      entityType: 'PAYMENT',
      entityId: 'pay_1',
      action: 'RECORD_FEE_PAYMENT',
      summary: 'Collected ₹4,500 via UPI for Aarav Kulkarni (JEE Physics & Mathematics)',
      amountPaise: 450000,
      createdAt: nowISO,
    },
    {
      id: 'aud_2',
      actorUid: 'demo_admin_1',
      actorEmail: 'director@iisinstitute.edu.in',
      actorRole: UserRole.ADMIN,
      entityType: 'TEACHER_PAYOUT',
      entityId: 'po_tch_3',
      action: 'DISBURSE_TEACHER_PAYOUT',
      summary: 'Disbursed ₹4,500 mid-month salary advance to Kavita Deshmukh via UPI',
      amountPaise: 450000,
      createdAt: nowISO,
    },
  ];

  return {
    users,
    settings,
    courses,
    batches,
    teachers,
    students,
    enrollments,
    invoices,
    payments,
    agreements,
    allocations,
    payouts,
    expenses,
    reports,
    auditLogs,
  };
}
