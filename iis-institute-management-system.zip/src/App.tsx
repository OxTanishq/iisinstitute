/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Toaster } from 'sonner';
import { ShieldOff } from 'lucide-react';
import { InstituteProvider, useInstitute } from './context/InstituteContext';
import { NavPageId } from './shared/types';
import { AppErrorBoundary, Button, Skeleton } from './components/ui/primitives';
import { LoginScreen } from './components/auth/LoginScreen';
import { AppShell } from './components/layout/AppShell';
import { OverviewPage } from './pages/OverviewPage';
import { StudentsPage, StudentProfilesPage } from './pages/StudentsPages';
import { FeeCollectionPage, OutstandingFeesPage } from './pages/FeesPages';
import { TeachersPage, TeacherPayoutsPage } from './pages/TeachersPages';
import { PerformanceReportsPage, ExpensesPage } from './pages/AcademicAndExpensePages';
import {
  RevenueAnalyticsPage,
  GrowthInsightsPage,
  FinancialReportsPage,
} from './pages/AnalyticsAndReportsPages';
import { SettingsPage } from './pages/SettingsPage';

function IISApplicationRouter() {
  const {
    authReady,
    firebaseUser,
    currentUserProfile,
    isDemoMode,
    signOutUser,
  } = useInstitute();

  const [activePage, setActivePage] = useState<NavPageId>('overview');
  const [selectedStudentId, setSelectedStudentId] = useState<string | null>(null);
  const [preselectedInvoiceId, setPreselectedInvoiceId] = useState<string | null>(null);

  if (!authReady) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-6">
        <div className="w-full max-w-md bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-10 w-full" />
        </div>
      </div>
    );
  }

  if (!firebaseUser && !isDemoMode) {
    return <LoginScreen />;
  }

  if (currentUserProfile?.status === 'SUSPENDED') {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white border border-red-200 rounded-xl p-8 text-center space-y-4">
          <ShieldOff className="h-10 w-10 text-red-600 mx-auto" />
          <h1 className="text-xl font-extrabold text-slate-900">Account Access Suspended</h1>
          <p className="text-sm text-slate-600 leading-relaxed">
            Your user profile ({currentUserProfile.email}) has been suspended by an Institute
            Administrator. Please contact IIS Institute administration for assistance.
          </p>
          <Button variant="secondary" onClick={signOutUser}>
            Sign Out
          </Button>
        </div>
      </div>
    );
  }

  const handleInspectStudent = (studentId: string) => {
    setSelectedStudentId(studentId);
    setActivePage('student-profiles');
  };

  const handleCollectForInvoice = (invoiceId: string) => {
    setPreselectedInvoiceId(invoiceId);
    setActivePage('fee-collection');
  };

  const renderActivePage = () => {
    switch (activePage) {
      case 'overview':
        return (
          <OverviewPage
            onNavigate={setActivePage}
            onInspectStudent={handleInspectStudent}
          />
        );
      case 'students':
        return (
          <StudentsPage
            onSelectStudentProfile={handleInspectStudent}
            onNavigate={setActivePage}
          />
        );
      case 'student-profiles':
        return (
          <StudentProfilesPage
            selectedStudentId={selectedStudentId}
            onSelectStudentId={setSelectedStudentId}
            onNavigate={setActivePage}
          />
        );
      case 'fee-collection':
        return (
          <FeeCollectionPage
            preselectedInvoiceId={preselectedInvoiceId}
            onClearPreselectedInvoice={() => setPreselectedInvoiceId(null)}
          />
        );
      case 'outstanding-fees':
        return <OutstandingFeesPage onCollectForInvoice={handleCollectForInvoice} />;
      case 'teachers':
        return <TeachersPage />;
      case 'teacher-payouts':
        return <TeacherPayoutsPage />;
      case 'performance-reports':
        return <PerformanceReportsPage />;
      case 'expenses':
        return <ExpensesPage />;
      case 'revenue-analytics':
        return <RevenueAnalyticsPage />;
      case 'growth-insights':
        return <GrowthInsightsPage />;
      case 'financial-reports':
        return <FinancialReportsPage />;
      case 'settings':
        return <SettingsPage />;
      default:
        return (
          <OverviewPage
            onNavigate={setActivePage}
            onInspectStudent={handleInspectStudent}
          />
        );
    }
  };

  return (
    <AppShell activePage={activePage} onNavigate={setActivePage}>
      {renderActivePage()}
    </AppShell>
  );
}

export default function App() {
  return (
    <AppErrorBoundary>
      <InstituteProvider>
        <IISApplicationRouter />
        <Toaster position="top-right" richColors closeButton />
      </InstituteProvider>
    </AppErrorBoundary>
  );
}
