export enum UserRole {
  ADMIN = 'ADMIN',
  TEACHER = 'TEACHER',
  ACCOUNTANT = 'ACCOUNTANT',
}

export enum RecordStatus {
  ACTIVE = 'ACTIVE',
  INACTIVE = 'INACTIVE',
  ARCHIVED = 'ARCHIVED',
  SUSPENDED = 'SUSPENDED',
}

export enum PaymentSchedule {
  MONTHLY = 'MONTHLY',
  QUARTERLY = 'QUARTERLY',
  CUSTOM = 'CUSTOM',
}

export enum InvoiceStatus {
  PENDING = 'PENDING',
  PARTIAL = 'PARTIAL',
  PAID = 'PAID',
  OVERDUE = 'OVERDUE',
  CANCELLED = 'CANCELLED',
}

export enum PaymentMethod {
  CASH = 'CASH',
  UPI = 'UPI',
  BANK_TRANSFER = 'BANK_TRANSFER',
}

export enum PaymentStatus {
  COMPLETED = 'COMPLETED',
  REVERSED = 'REVERSED',
}

export enum TeacherCompensationModel {
  FIXED_SALARY = 'FIXED_SALARY',
  PERCENTAGE = 'PERCENTAGE',
  PER_STUDENT = 'PER_STUDENT',
  CUSTOM = 'CUSTOM',
}

export enum AllocationStatus {
  ACCRUED = 'ACCRUED',
  SETTLED = 'SETTLED',
  REVERSED = 'REVERSED',
}

export enum PayoutStatus {
  PAID = 'PAID',
  PENDING = 'PENDING',
  REVERSED = 'REVERSED',
}

export enum ExpenseCategory {
  RENT = 'RENT',
  UTILITIES = 'UTILITIES',
  MARKETING = 'MARKETING',
  MATERIALS = 'MATERIALS',
  SOFTWARE = 'SOFTWARE',
  MAINTENANCE = 'MAINTENANCE',
  OTHER = 'OTHER',
}

export enum AcademicProgress {
  EXCELLENT = 'EXCELLENT',
  GOOD = 'GOOD',
  SATISFACTORY = 'SATISFACTORY',
  NEEDS_ATTENTION = 'NEEDS_ATTENTION',
}

export interface UserProfile {
  id: string;
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  teacherId: string;
  status: 'ACTIVE' | 'SUSPENDED';
  createdAt: string;
  updatedAt: string;
}

export interface InstituteSettings {
  id: string;
  instituteName: string;
  logoUrl: string;
  tagline: string;
  phone: string;
  email: string;
  address: string;
  city: string;
  receiptPrefix: string;
  defaultDueDay: number;
  financialYearStartMonth: number;
  updatedBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface Course {
  id: string;
  code: string;
  name: string;
  subjectCategory: string;
  defaultMonthlyFeePaise: number;
  durationMonths: number;
  status: 'ACTIVE' | 'ARCHIVED';
  financeViewerUids: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface Batch {
  id: string;
  code: string;
  name: string;
  courseId: string;
  courseName: string;
  teacherId: string;
  teacherUid: string;
  teacherName: string;
  scheduleLabel: string;
  status: 'ACTIVE' | 'ARCHIVED';
  financeViewerUids: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface Teacher {
  id: string;
  teacherCode: string;
  fullName: string;
  email: string;
  phone: string;
  specialization: string;
  subjects: string[];
  linkedUserUid: string;
  joinedDate: string;
  status: 'ACTIVE' | 'ARCHIVED';
  financeViewerUids: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface Student {
  id: string;
  studentCode: string;
  fullName: string;
  primaryCourseId: string;
  primaryCourseName: string;
  courseIds: string[];
  batchId: string;
  batchName: string;
  enrollmentDate: string;
  monthlyFeePaise: number;
  paymentSchedule: PaymentSchedule;
  status: 'ACTIVE' | 'INACTIVE' | 'ARCHIVED';
  guardianName: string;
  guardianPhone: string;
  assignedTeacherId: string;
  assignedTeacherUid: string;
  assignedTeacherName: string;
  financeViewerUids: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface Enrollment {
  id: string;
  studentId: string;
  studentName: string;
  courseId: string;
  courseName: string;
  batchId: string;
  teacherId: string;
  assignedTeacherUid: string;
  agreedFeePaise: number;
  startDate: string;
  status: 'ACTIVE' | 'COMPLETED' | 'DROPPED';
  financeViewerUids: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  studentId: string;
  studentName: string;
  courseId: string;
  courseName: string;
  batchId: string;
  billingPeriod: string; // YYYY-MM in Asia/Kolkata
  grossAmountPaise: number;
  discountPaise: number;
  netAmountDuePaise: number;
  paidAmountPaise: number;
  balanceDuePaise: number;
  dueDate: string; // YYYY-MM-DD
  status: InvoiceStatus;
  assignedTeacherId: string;
  notes: string;
  financeViewerUids: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface Payment {
  id: string;
  receiptNumber: string;
  idempotencyKey: string;
  invoiceId: string;
  studentId: string;
  studentName: string;
  courseId: string;
  courseName: string;
  billingPeriod: string; // YYYY-MM
  amountPaise: number;
  paymentMethod: PaymentMethod;
  paymentDate: string; // YYYY-MM-DD
  referenceNote: string;
  status: PaymentStatus;
  reversalReason: string;
  financeViewerUids: string[];
  recordedBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface TeacherAgreement {
  id: string;
  teacherId: string;
  teacherUid: string;
  teacherName: string;
  modelType: TeacherCompensationModel;
  fixedMonthlyPaise: number;
  shareBasisPoints: number; // e.g., 4000 = 40.00%
  perStudentPaise: number;
  effectiveFrom: string; // YYYY-MM-DD
  effectiveTo: string; // YYYY-MM-DD or ""
  notes: string;
  status: 'ACTIVE' | 'SUPERSEDED';
  financeViewerUids: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface TeacherShareAllocation {
  id: string;
  agreementId: string;
  modelTypeSnapshot: TeacherCompensationModel;
  rateSnapshotLabel: string;
  teacherId: string;
  teacherUid: string;
  teacherName: string;
  paymentId: string;
  invoiceId: string;
  studentId: string;
  studentName: string;
  billingPeriod: string; // YYYY-MM
  basisAmountPaise: number;
  allocatedAmountPaise: number;
  status: AllocationStatus;
  payoutId: string;
  financeViewerUids: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface TeacherPayout {
  id: string;
  payoutNumber: string;
  teacherId: string;
  teacherUid: string;
  teacherName: string;
  billingPeriod: string; // YYYY-MM
  amountPaise: number;
  paymentMethod: PaymentMethod;
  payoutDate: string; // YYYY-MM-DD
  referenceNote: string;
  status: PayoutStatus;
  financeViewerUids: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface Expense {
  id: string;
  title: string;
  category: ExpenseCategory;
  amountPaise: number;
  expenseDate: string; // YYYY-MM-DD
  billingPeriod: string; // YYYY-MM
  paymentMethod: PaymentMethod;
  vendorName: string;
  notes: string;
  status: 'RECORDED' | 'REVERSED';
  financeViewerUids: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface StudentReport {
  id: string;
  studentId: string;
  studentName: string;
  courseId: string;
  courseName: string;
  teacherId: string;
  teacherUid: string;
  teacherName: string;
  reportingPeriod: string; // YYYY-MM
  subject: string;
  attendancePercent: number;
  testMarks: number;
  maxMarks: number;
  academicProgress: AcademicProgress;
  strengths: string;
  areasForImprovement: string;
  teacherComments: string;
  submissionDate: string; // YYYY-MM-DD
  financeViewerUids: string[];
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuditLog {
  id: string;
  actorUid: string;
  actorEmail: string;
  actorRole: UserRole;
  entityType: string;
  entityId: string;
  action: string;
  summary: string;
  amountPaise: number;
  createdAt: string;
}

export interface MoMGrowthResult {
  currentValue: number;
  previousValue: number;
  absoluteDiff: number;
  growthPercent: number | null; // null when previousValue === 0
  formattedPercent: string; // e.g., "+14.2%" or "N/A"
  direction: 'up' | 'down' | 'flat';
  isZeroBase: boolean;
}

export type AlertSeverity = 'critical' | 'warning' | 'watch' | 'healthy';

export interface WeakPointFinding {
  id: string;
  metricName: string;
  category: 'REVENUE' | 'RECEIVABLES' | 'PAYOUTS' | 'EXPENSES' | 'MARGIN' | 'COURSE';
  currentValueFormatted: string;
  comparisonValueFormatted: string;
  percentChangeFormatted: string;
  percentChangeRaw: number | null;
  severity: AlertSeverity;
  reason: string;
  suggestedAction: string;
}

export interface MonthlyPeriodMetrics {
  period: string; // YYYY-MM
  label: string; // e.g. "Oct 2026"
  invoicedGrossPaise: number;
  invoicedNetPaise: number;
  collectedFeePaise: number;
  pendingBalancePaise: number;
  overdueBalancePaise: number;
  collectionRatePercent: number; // 0..100
  accruedTeacherSharePaise: number; // Liability accrued
  paidTeacherPayoutPaise: number; // Cash disbursed
  unpaidTeacherLiabilityPaise: number;
  operatingExpensesPaise: number;
  netOperatingIncomePaise: number; // collectedFeePaise - accruedTeacherSharePaise - operatingExpensesPaise
  cashNetSurplusPaise: number; // collectedFeePaise - paidTeacherPayoutPaise - operatingExpensesPaise
  netMarginPercent: number;
  teacherPayoutRatioPercent: number;
  activeStudentsCount: number;
  newEnrollmentsCount: number;
}

export type NavPageId =
  | 'overview'
  | 'students'
  | 'student-profiles'
  | 'fee-collection'
  | 'outstanding-fees'
  | 'teachers'
  | 'teacher-payouts'
  | 'performance-reports'
  | 'expenses'
  | 'revenue-analytics'
  | 'growth-insights'
  | 'financial-reports'
  | 'settings';
