import {
  AllocationStatus,
  Expense,
  Invoice,
  InvoiceStatus,
  MoMGrowthResult,
  MonthlyPeriodMetrics,
  Payment,
  PaymentStatus,
  PayoutStatus,
  Student,
  TeacherAgreement,
  TeacherCompensationModel,
  TeacherPayout,
  TeacherShareAllocation,
  WeakPointFinding,
} from './types';

export const IST_TIMEZONE = 'Asia/Kolkata';

const inrFullFormatter = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const inrWholeFormatter = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  minimumFractionDigits: 0,
  maximumFractionDigits: 0,
});

/**
 * Converts rupees (float/number) safely into integer paise.
 */
export function toPaise(rupees: number): number {
  if (!Number.isFinite(rupees)) return 0;
  return Math.round(rupees * 100);
}

/**
 * Converts integer paise into decimal rupees for charts or inputs.
 */
export function toRupees(paise: number): number {
  if (!Number.isFinite(paise)) return 0;
  return Math.round(paise) / 100;
}

/**
 * Formats integer paise in Indian Rupees (e.g. ₹2,000.00 or ₹1,45,000).
 */
export function formatINR(paise: number, showDecimals = false): string {
  const safePaise = Number.isFinite(paise) ? Math.round(paise) : 0;
  const rupees = safePaise / 100;
  if (showDecimals || safePaise % 100 !== 0) {
    return inrFullFormatter.format(rupees);
  }
  return inrWholeFormatter.format(rupees);
}

/**
 * Returns current date in Asia/Kolkata as YYYY-MM-DD.
 */
export function getTodayIST(now: Date = new Date()): string {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: IST_TIMEZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(now);
  const year = parts.find((p) => p.type === 'year')?.value ?? '2026';
  const month = parts.find((p) => p.type === 'month')?.value ?? '01';
  const day = parts.find((p) => p.type === 'day')?.value ?? '01';
  return `${year}-${month}-${day}`;
}

/**
 * Returns current reporting month in Asia/Kolkata as YYYY-MM.
 */
export function getCurrentPeriodIST(now: Date = new Date()): string {
  return getTodayIST(now).slice(0, 7);
}

/**
 * Extracts YYYY-MM billing period from a YYYY-MM-DD date string.
 */
export function periodFromDate(dateStr: string): string {
  if (!dateStr || dateStr.length < 7) return getCurrentPeriodIST();
  return dateStr.slice(0, 7);
}

/**
 * Shifts a YYYY-MM period by `deltaMonths` (e.g. -1 for previous month).
 */
export function shiftPeriod(period: string, deltaMonths: number): string {
  const [yStr, mStr] = period.split('-');
  const year = Number(yStr);
  const monthIndex = Number(mStr) - 1;
  const d = new Date(Date.UTC(year, monthIndex + deltaMonths, 1));
  const outYear = d.getUTCFullYear();
  const outMonth = String(d.getUTCMonth() + 1).padStart(2, '0');
  return `${outYear}-${outMonth}`;
}

/**
 * Returns human-friendly period label (e.g., "Oct 2026").
 */
export function formatPeriodLabel(period: string): string {
  const [yStr, mStr] = period.split('-');
  const year = Number(yStr);
  const monthIndex = Number(mStr) - 1;
  if (!Number.isFinite(year) || !Number.isFinite(monthIndex)) return period;
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${months[monthIndex] ?? mStr} ${year}`;
}

/**
 * Generates an ordered list of the trailing `count` periods ending at `endPeriod`.
 */
export function getTrailingPeriods(endPeriod: string, count: number): string[] {
  const list: string[] = [];
  for (let i = count - 1; i >= 0; i--) {
    list.push(shiftPeriod(endPeriod, -i));
  }
  return list;
}

/**
 * Reconciles an invoice strictly from its verified non-reversed payments.
 * Never marks an invoice PAID until verified paidAmountPaise >= netAmountDuePaise.
 */
export function reconcileInvoiceState(
  grossAmountPaise: number,
  discountPaise: number,
  verifiedPaymentsPaise: number,
  dueDate: string,
  todayIST: string = getTodayIST(),
  isCancelled = false
): {
  netAmountDuePaise: number;
  paidAmountPaise: number;
  balanceDuePaise: number;
  status: InvoiceStatus;
} {
  const safeGross = Math.max(0, Math.round(grossAmountPaise));
  const safeDiscount = Math.min(safeGross, Math.max(0, Math.round(discountPaise)));
  const netAmountDuePaise = safeGross - safeDiscount;
  const paidAmountPaise = Math.max(0, Math.round(verifiedPaymentsPaise));
  const balanceDuePaise = Math.max(0, netAmountDuePaise - paidAmountPaise);

  if (isCancelled) {
    return {
      netAmountDuePaise,
      paidAmountPaise,
      balanceDuePaise: 0,
      status: InvoiceStatus.CANCELLED,
    };
  }

  let status: InvoiceStatus;
  if (paidAmountPaise >= netAmountDuePaise && balanceDuePaise === 0) {
    status = InvoiceStatus.PAID;
  } else if (paidAmountPaise > 0) {
    status = dueDate < todayIST ? InvoiceStatus.OVERDUE : InvoiceStatus.PARTIAL;
  } else {
    status = dueDate < todayIST ? InvoiceStatus.OVERDUE : InvoiceStatus.PENDING;
  }

  return {
    netAmountDuePaise,
    paidAmountPaise,
    balanceDuePaise,
    status,
  };
}

/**
 * Selects the historical teacher agreement effective on `targetDate` (YYYY-MM-DD).
 * Preserves historical rates even after newer agreements are added.
 */
export function findEffectiveAgreement(
  agreements: TeacherAgreement[],
  teacherId: string,
  targetDate: string
): TeacherAgreement | null {
  const matching = agreements
    .filter((ag) => {
      if (ag.teacherId !== teacherId) return false;
      if (ag.effectiveFrom > targetDate) return false;
      if (ag.effectiveTo && ag.effectiveTo !== '' && ag.effectiveTo < targetDate) return false;
      return true;
    })
    .sort((a, b) => b.effectiveFrom.localeCompare(a.effectiveFrom));

  return matching[0] ?? null;
}

/**
 * Calculates deterministic teacher share allocation for a specific fee payment in integer paise.
 * Example: ₹2,000 (200,000 paise) * 40% (4,000 bps) = ₹800 (80,000 paise).
 */
export function calculatePaymentTeacherShare(
  paymentAmountPaise: number,
  agreement: TeacherAgreement | null,
  existingStudentPeriodAllocationsCount = 0
): {
  allocatedAmountPaise: number;
  rateSnapshotLabel: string;
  shouldCreateAllocation: boolean;
} {
  if (!agreement || paymentAmountPaise <= 0) {
    return {
      allocatedAmountPaise: 0,
      rateSnapshotLabel: 'No eligible payment-linked share',
      shouldCreateAllocation: false,
    };
  }

  const safePayment = Math.round(paymentAmountPaise);

  switch (agreement.modelType) {
    case TeacherCompensationModel.PERCENTAGE: {
      const bps = Math.max(0, Math.min(10000, Math.round(agreement.shareBasisPoints)));
      const share = Math.round((safePayment * bps) / 10000);
      const pctLabel = (bps / 100).toFixed(bps % 100 === 0 ? 0 : 2);
      return {
        allocatedAmountPaise: share,
        rateSnapshotLabel: `${pctLabel}% of collected fee`,
        shouldCreateAllocation: share > 0,
      };
    }

    case TeacherCompensationModel.PER_STUDENT: {
      // Allocate fixed per-student amount once per student per billing period
      if (existingStudentPeriodAllocationsCount > 0) {
        return {
          allocatedAmountPaise: 0,
          rateSnapshotLabel: `${formatINR(agreement.perStudentPaise)} per student (already accrued this period)`,
          shouldCreateAllocation: false,
        };
      }
      const perStu = Math.max(0, Math.round(agreement.perStudentPaise));
      return {
        allocatedAmountPaise: perStu,
        rateSnapshotLabel: `${formatINR(perStu)} per active paid student`,
        shouldCreateAllocation: perStu > 0,
      };
    }

    case TeacherCompensationModel.CUSTOM: {
      const bps = Math.max(0, Math.min(10000, Math.round(agreement.shareBasisPoints)));
      const share = Math.round((safePayment * bps) / 10000);
      const pctLabel = (bps / 100).toFixed(bps % 100 === 0 ? 0 : 2);
      return {
        allocatedAmountPaise: share,
        rateSnapshotLabel: `Custom (${pctLabel}% variable share + monthly retainer)`,
        shouldCreateAllocation: share > 0,
      };
    }

    case TeacherCompensationModel.FIXED_SALARY:
    default:
      // Fixed monthly salary is accrued monthly, not per student fee receipt
      return {
        allocatedAmountPaise: 0,
        rateSnapshotLabel: `Fixed salary (${formatINR(agreement.fixedMonthlyPaise)}/mo)`,
        shouldCreateAllocation: false,
      };
  }
}

/**
 * Calculates Month-over-Month growth safely:
 * Growth (%) = ((Current - Previous) / Previous) * 100
 * Returns growthPercent: null and formattedPercent: "N/A" when previous === 0.
 */
export function calculateMoMGrowth(currentValue: number, previousValue: number): MoMGrowthResult {
  const curr = Math.round(currentValue);
  const prev = Math.round(previousValue);
  const absoluteDiff = curr - prev;

  if (prev === 0) {
    return {
      currentValue: curr,
      previousValue: prev,
      absoluteDiff,
      growthPercent: null,
      formattedPercent: 'N/A',
      direction: curr > 0 ? 'up' : curr < 0 ? 'down' : 'flat',
      isZeroBase: true,
    };
  }

  const rawPct = ((curr - prev) / Math.abs(prev)) * 100;
  const rounded = Math.round(rawPct * 10) / 10;
  const sign = rounded > 0 ? '+' : '';

  return {
    currentValue: curr,
    previousValue: prev,
    absoluteDiff,
    growthPercent: rounded,
    formattedPercent: `${sign}${rounded.toFixed(1)}%`,
    direction: rounded > 0 ? 'up' : rounded < 0 ? 'down' : 'flat',
    isZeroBase: false,
  };
}

/**
 * Aggregates complete financial metrics for a single reporting period (YYYY-MM).
 * Strictly separates invoiced revenue from collected revenue, and accrued teacher liabilities from paid disbursements.
 */
export function computeMonthlyPeriodMetrics(params: {
  period: string;
  students: Student[];
  invoices: Invoice[];
  payments: Payment[];
  allocations: TeacherShareAllocation[];
  payouts: TeacherPayout[];
  expenses: Expense[];
  todayIST?: string;
}): MonthlyPeriodMetrics {
  const {
    period,
    students,
    invoices,
    payments,
    allocations,
    payouts,
    expenses,
    todayIST = getTodayIST(),
  } = params;

  const periodInvoices = invoices.filter(
    (inv) => inv.billingPeriod === period && inv.status !== InvoiceStatus.CANCELLED
  );

  const invoicedGrossPaise = periodInvoices.reduce((acc, i) => acc + i.grossAmountPaise, 0);
  const invoicedNetPaise = periodInvoices.reduce((acc, i) => acc + i.netAmountDuePaise, 0);
  const pendingBalancePaise = periodInvoices.reduce((acc, i) => acc + i.balanceDuePaise, 0);
  const overdueBalancePaise = periodInvoices
    .filter((i) => i.balanceDuePaise > 0 && i.dueDate < todayIST)
    .reduce((acc, i) => acc + i.balanceDuePaise, 0);

  // Collected revenue strictly sums non-reversed payments received in this period (by paymentDate IST period)
  const collectedFeePaise = payments
    .filter((p) => p.status === PaymentStatus.COMPLETED && periodFromDate(p.paymentDate) === period)
    .reduce((acc, p) => acc + p.amountPaise, 0);

  // Collection rate for this billing period's invoices
  const periodInvoicePaidPaise = periodInvoices.reduce((acc, i) => acc + i.paidAmountPaise, 0);
  const collectionRatePercent =
    invoicedNetPaise > 0
      ? Math.min(100, Math.round((periodInvoicePaidPaise / invoicedNetPaise) * 1000) / 10)
      : 0;

  // Accrued teacher share liabilities for the period
  const accruedTeacherSharePaise = allocations
    .filter((a) => a.billingPeriod === period && a.status !== AllocationStatus.REVERSED)
    .reduce((acc, a) => acc + a.allocatedAmountPaise, 0);

  // Actual teacher cash payouts made in or for the period
  const paidTeacherPayoutPaise = payouts
    .filter((po) => po.billingPeriod === period && po.status === PayoutStatus.PAID)
    .reduce((acc, po) => acc + po.amountPaise, 0);

  const unpaidTeacherLiabilityPaise = Math.max(0, accruedTeacherSharePaise - paidTeacherPayoutPaise);

  // Other operating expenses recorded in the period
  const operatingExpensesPaise = expenses
    .filter((ex) => ex.status === 'RECORDED' && ex.billingPeriod === period)
    .reduce((acc, ex) => acc + ex.amountPaise, 0);

  // Net Operating Income (Accrual-aware: Collected Revenue minus Accrued Teacher Share minus Operating Expenses)
  const netOperatingIncomePaise =
    collectedFeePaise - accruedTeacherSharePaise - operatingExpensesPaise;

  // Cash Net Surplus (Collected Revenue minus Disbursed Teacher Payouts minus Operating Expenses)
  const cashNetSurplusPaise = collectedFeePaise - paidTeacherPayoutPaise - operatingExpensesPaise;

  const netMarginPercent =
    collectedFeePaise > 0
      ? Math.round((netOperatingIncomePaise / collectedFeePaise) * 1000) / 10
      : 0;

  const teacherPayoutRatioPercent =
    collectedFeePaise > 0
      ? Math.round((accruedTeacherSharePaise / collectedFeePaise) * 1000) / 10
      : 0;

  const activeStudentsCount = students.filter(
    (s) => s.status === 'ACTIVE' && periodFromDate(s.enrollmentDate) <= period
  ).length;

  const newEnrollmentsCount = students.filter(
    (s) => s.status !== 'ARCHIVED' && periodFromDate(s.enrollmentDate) === period
  ).length;

  return {
    period,
    label: formatPeriodLabel(period),
    invoicedGrossPaise,
    invoicedNetPaise,
    collectedFeePaise,
    pendingBalancePaise,
    overdueBalancePaise,
    collectionRatePercent,
    accruedTeacherSharePaise,
    paidTeacherPayoutPaise,
    unpaidTeacherLiabilityPaise,
    operatingExpensesPaise,
    netOperatingIncomePaise,
    cashNetSurplusPaise,
    netMarginPercent,
    teacherPayoutRatioPercent,
    activeStudentsCount,
    newEnrollmentsCount,
  };
}

/**
 * Deterministic Weak-Point Detection Engine (Section 12).
 * Evaluates all 7 financial weakness vectors without fabricating numbers.
 */
export function detectInstituteWeakPoints(params: {
  current: MonthlyPeriodMetrics;
  previous: MonthlyPeriodMetrics;
  payments: Payment[];
  invoices: Invoice[];
}): WeakPointFinding[] {
  const { current, previous, payments, invoices } = params;
  const findings: WeakPointFinding[] = [];

  // 1. Falling Monthly Fee Collection
  const revGrowth = calculateMoMGrowth(current.collectedFeePaise, previous.collectedFeePaise);
  if (revGrowth.growthPercent !== null && revGrowth.growthPercent < 0) {
    findings.push({
      id: 'wp-falling-collection',
      metricName: 'Monthly Fee Collection',
      category: 'REVENUE',
      currentValueFormatted: formatINR(current.collectedFeePaise),
      comparisonValueFormatted: formatINR(previous.collectedFeePaise),
      percentChangeFormatted: revGrowth.formattedPercent,
      percentChangeRaw: revGrowth.growthPercent,
      severity: revGrowth.growthPercent <= -15 ? 'critical' : 'warning',
      reason: `Collected fee revenue fell by ${formatINR(Math.abs(revGrowth.absoluteDiff))} (${revGrowth.formattedPercent}) compared to ${previous.label}.`,
      suggestedAction:
        'Prioritize follow-ups on overdue invoices due before the 10th and trigger installment reminders for partial-balance students.',
    });
  }

  // 2. Increasing Outstanding Balances
  const outGrowth = calculateMoMGrowth(current.pendingBalancePaise, previous.pendingBalancePaise);
  if (
    current.pendingBalancePaise > 0 &&
    ((outGrowth.growthPercent !== null && outGrowth.growthPercent > 10) ||
      (previous.pendingBalancePaise === 0 && current.pendingBalancePaise > 0))
  ) {
    findings.push({
      id: 'wp-rising-receivables',
      metricName: 'Outstanding Fee Receivables',
      category: 'RECEIVABLES',
      currentValueFormatted: formatINR(current.pendingBalancePaise),
      comparisonValueFormatted: formatINR(previous.pendingBalancePaise),
      percentChangeFormatted: outGrowth.formattedPercent,
      percentChangeRaw: outGrowth.growthPercent,
      severity: current.overdueBalancePaise > current.collectedFeePaise * 0.25 ? 'critical' : 'warning',
      reason: `Uncollected balance for ${current.label} stands at ${formatINR(current.pendingBalancePaise)}, including ${formatINR(current.overdueBalancePaise)} past due.`,
      suggestedAction:
        'Review the Outstanding Fees ledger sorted by aging days and collect UPI/Bank commitments from guardians with overdue balances.',
    });
  }

  // 3. Declining Collection Rate
  const collRateDiff = Math.round((current.collectionRatePercent - previous.collectionRatePercent) * 10) / 10;
  if (previous.invoicedNetPaise > 0 && current.invoicedNetPaise > 0 && collRateDiff < -3) {
    findings.push({
      id: 'wp-collection-rate-drop',
      metricName: 'Invoice Collection Rate',
      category: 'RECEIVABLES',
      currentValueFormatted: `${current.collectionRatePercent.toFixed(1)}%`,
      comparisonValueFormatted: `${previous.collectionRatePercent.toFixed(1)}%`,
      percentChangeFormatted: `${collRateDiff.toFixed(1)} pts`,
      percentChangeRaw: collRateDiff,
      severity: current.collectionRatePercent < 70 ? 'critical' : 'warning',
      reason: `Invoice realization dropped from ${previous.collectionRatePercent.toFixed(1)}% in ${previous.label} to ${current.collectionRatePercent.toFixed(1)}% in ${current.label}.`,
      suggestedAction:
        'Align due dates with batch start weeks and require initial partial installment on invoice issuance.',
    });
  }

  // 4. Increasing Teacher Payout Ratio
  const payoutRatioDiff =
    Math.round((current.teacherPayoutRatioPercent - previous.teacherPayoutRatioPercent) * 10) / 10;
  if (
    current.collectedFeePaise > 0 &&
    (current.teacherPayoutRatioPercent > 50 || (previous.collectedFeePaise > 0 && payoutRatioDiff >= 5))
  ) {
    findings.push({
      id: 'wp-payout-ratio',
      metricName: 'Teacher Payout-to-Revenue Ratio',
      category: 'PAYOUTS',
      currentValueFormatted: `${current.teacherPayoutRatioPercent.toFixed(1)}%`,
      comparisonValueFormatted: `${previous.teacherPayoutRatioPercent.toFixed(1)}%`,
      percentChangeFormatted: `${payoutRatioDiff >= 0 ? '+' : ''}${payoutRatioDiff.toFixed(1)} pts`,
      percentChangeRaw: payoutRatioDiff,
      severity: current.teacherPayoutRatioPercent > 60 ? 'critical' : 'watch',
      reason: `Accrued teacher shares consume ${current.teacherPayoutRatioPercent.toFixed(1)}% of collected fees (${formatINR(current.accruedTeacherSharePaise)} of ${formatINR(current.collectedFeePaise)}).`,
      suggestedAction:
        'Audit fixed-salary batches with low student headcount and consider percentage-based or hybrid tier agreements for under-filled cohorts.',
    });
  }

  // 5. Rising Operating Expenses
  const expGrowth = calculateMoMGrowth(current.operatingExpensesPaise, previous.operatingExpensesPaise);
  if (expGrowth.growthPercent !== null && expGrowth.growthPercent > 12) {
    findings.push({
      id: 'wp-rising-expenses',
      metricName: 'Non-Payroll Operating Expenses',
      category: 'EXPENSES',
      currentValueFormatted: formatINR(current.operatingExpensesPaise),
      comparisonValueFormatted: formatINR(previous.operatingExpensesPaise),
      percentChangeFormatted: expGrowth.formattedPercent,
      percentChangeRaw: expGrowth.growthPercent,
      severity: expGrowth.growthPercent > 25 ? 'critical' : 'warning',
      reason: `Operating overhead increased by ${formatINR(expGrowth.absoluteDiff)} (${expGrowth.formattedPercent}) from ${previous.label} to ${current.label}.`,
      suggestedAction:
        'Inspect discretionary marketing, materials, and utility line items in Expenses to cap non-instructional spend growth.',
    });
  }

  // 6. Lower Revenue by Course
  const courseMapCurr = new Map<string, { name: string; paise: number }>();
  const courseMapPrev = new Map<string, { name: string; paise: number }>();

  for (const p of payments) {
    if (p.status !== PaymentStatus.COMPLETED) continue;
    const pPeriod = periodFromDate(p.paymentDate);
    if (pPeriod === current.period) {
      const existing = courseMapCurr.get(p.courseId) ?? { name: p.courseName, paise: 0 };
      existing.paise += p.amountPaise;
      courseMapCurr.set(p.courseId, existing);
    } else if (pPeriod === previous.period) {
      const existing = courseMapPrev.get(p.courseId) ?? { name: p.courseName, paise: 0 };
      existing.paise += p.amountPaise;
      courseMapPrev.set(p.courseId, existing);
    }
  }

  for (const [courseId, prevEntry] of courseMapPrev.entries()) {
    if (prevEntry.paise <= 0) continue;
    const currPaise = courseMapCurr.get(courseId)?.paise ?? 0;
    const cGrowth = calculateMoMGrowth(currPaise, prevEntry.paise);
    if (cGrowth.growthPercent !== null && cGrowth.growthPercent <= -15) {
      const uncollectedCoursePaise = invoices
        .filter(
          (i) =>
            i.courseId === courseId &&
            i.billingPeriod === current.period &&
            i.status !== InvoiceStatus.CANCELLED
        )
        .reduce((s, i) => s + i.balanceDuePaise, 0);

      findings.push({
        id: `wp-course-drop-${courseId}`,
        metricName: `Course Revenue: ${prevEntry.name}`,
        category: 'COURSE',
        currentValueFormatted: formatINR(currPaise),
        comparisonValueFormatted: formatINR(prevEntry.paise),
        percentChangeFormatted: cGrowth.formattedPercent,
        percentChangeRaw: cGrowth.growthPercent,
        severity: cGrowth.growthPercent <= -30 ? 'critical' : 'warning',
        reason: `Collections for ${prevEntry.name} declined ${cGrowth.formattedPercent} MoM${
          uncollectedCoursePaise > 0
            ? `, with ${formatINR(uncollectedCoursePaise)} still pending on current invoices.`
            : '.'
        }`,
        suggestedAction: `Check batch retention and pending invoices for ${prevEntry.name} students.`,
      });
    }
  }

  // 7. Decreasing Net Income Margins (explicitly catches rising revenue with falling profit!)
  const marginDiff = Math.round((current.netMarginPercent - previous.netMarginPercent) * 10) / 10;
  if (
    (current.netOperatingIncomePaise < 0 && current.collectedFeePaise > 0) ||
    (previous.collectedFeePaise > 0 && current.collectedFeePaise > 0 && marginDiff <= -5)
  ) {
    const revenueRoseButProfitFell =
      current.collectedFeePaise >= previous.collectedFeePaise &&
      current.netOperatingIncomePaise < previous.netOperatingIncomePaise;

    findings.push({
      id: 'wp-margin-compression',
      metricName: 'Net Operating Margin',
      category: 'MARGIN',
      currentValueFormatted: `${current.netMarginPercent.toFixed(1)}% (${formatINR(current.netOperatingIncomePaise)})`,
      comparisonValueFormatted: `${previous.netMarginPercent.toFixed(1)}% (${formatINR(previous.netOperatingIncomePaise)})`,
      percentChangeFormatted: `${marginDiff >= 0 ? '+' : ''}${marginDiff.toFixed(1)} pts`,
      percentChangeRaw: marginDiff,
      severity: current.netOperatingIncomePaise < 0 ? 'critical' : 'warning',
      reason: revenueRoseButProfitFell
        ? `Even though fee revenue held or grew, combined teacher shares and operating expenses compressed net profit from ${formatINR(previous.netOperatingIncomePaise)} to ${formatINR(current.netOperatingIncomePaise)}.`
        : `Net operating margin contracted by ${Math.abs(marginDiff).toFixed(1)} percentage points compared to ${previous.label}.`,
      suggestedAction:
        'Rebalance fee discounts and operating costs so top-line fee collections translate into positive net operating surplus.',
    });
  }

  return findings;
}
