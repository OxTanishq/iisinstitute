import { z } from 'zod';
import {
  AcademicProgress,
  AllocationStatus,
  ExpenseCategory,
  PaymentMethod,
  PaymentSchedule,
  PaymentStatus,
  PayoutStatus,
  TeacherCompensationModel,
  UserRole,
} from './types';

export const ID_REGEX = /^[a-zA-Z0-9_\-]+$/;
export const PERIOD_REGEX = /^[0-9]{4}-[0-9]{2}$/;
export const DATE_REGEX = /^[0-9]{4}-[0-9]{2}-[0-9]{2}$/;

export const validIdSchema = z
  .string()
  .min(1, 'ID is required')
  .max(128, 'ID cannot exceed 128 characters')
  .regex(ID_REGEX, 'Invalid identifier format');

export const optionalIdSchema = z
  .string()
  .max(128)
  .refine((val) => val === '' || ID_REGEX.test(val), 'Invalid identifier format');

export const rupeesInputToPaise = (rupees: number): number => {
  if (!Number.isFinite(rupees) || rupees < 0) return 0;
  return Math.round(rupees * 100);
};

export const courseInputSchema = z.object({
  code: z.string().trim().min(2, 'Course code must be at least 2 characters').max(32),
  name: z.string().trim().min(2, 'Course name must be at least 2 characters').max(120),
  subjectCategory: z.string().trim().max(80).default('General'),
  defaultMonthlyFeeRupees: z.number().min(0, 'Monthly fee cannot be negative').max(10000000),
  durationMonths: z.number().int().min(1).max(60),
  status: z.enum(['ACTIVE', 'ARCHIVED']).default('ACTIVE'),
});

export const batchInputSchema = z.object({
  code: z.string().trim().min(2, 'Batch code is required').max(32),
  name: z.string().trim().min(2, 'Batch name is required').max(120),
  courseId: validIdSchema,
  teacherId: validIdSchema,
  scheduleLabel: z.string().trim().min(2, 'Schedule description is required').max(120),
  status: z.enum(['ACTIVE', 'ARCHIVED']).default('ACTIVE'),
});

export const teacherInputSchema = z.object({
  teacherCode: z.string().trim().min(2, 'Teacher ID is required').max(32),
  fullName: z.string().trim().min(2, 'Full name is required').max(120),
  email: z.string().trim().email('Enter a valid email address').max(160),
  phone: z.string().trim().max(32).default(''),
  specialization: z.string().trim().max(120).default(''),
  subjects: z.array(z.string().trim().min(1).max(80)).max(10, 'Maximum 10 subjects allowed'),
  linkedUserUid: optionalIdSchema.default(''),
  joinedDate: z.string().regex(DATE_REGEX, 'Use YYYY-MM-DD format'),
});

export const studentInputSchema = z.object({
  studentCode: z.string().trim().min(2, 'Student ID is required').max(32),
  fullName: z.string().trim().min(2, 'Student full name is required').max(120),
  primaryCourseId: validIdSchema,
  courseIds: z.array(validIdSchema).min(1, 'Select at least one course').max(10, 'Maximum 10 courses'),
  batchId: validIdSchema,
  enrollmentDate: z.string().regex(DATE_REGEX, 'Select a valid enrollment date'),
  monthlyFeeRupees: z.number().min(0, 'Monthly fee cannot be negative').max(10000000),
  paymentSchedule: z.nativeEnum(PaymentSchedule),
  status: z.enum(['ACTIVE', 'INACTIVE', 'ARCHIVED']).default('ACTIVE'),
  guardianName: z.string().trim().max(120).default(''),
  guardianPhone: z.string().trim().max(32).default(''),
  assignedTeacherId: validIdSchema,
});

export const invoiceCreateSchema = z
  .object({
    studentId: validIdSchema,
    courseId: validIdSchema,
    billingPeriod: z.string().regex(PERIOD_REGEX, 'Use YYYY-MM format'),
    grossAmountRupees: z.number().min(0, 'Gross fee cannot be negative').max(10000000),
    discountRupees: z.number().min(0, 'Discount cannot be negative').max(10000000).default(0),
    dueDate: z.string().regex(DATE_REGEX, 'Select a valid due date'),
    notes: z.string().trim().max(300).default(''),
  })
  .refine((data) => data.discountRupees <= data.grossAmountRupees, {
    message: 'Discount cannot exceed gross invoice amount',
    path: ['discountRupees'],
  });

export const invoiceUpdateSchema = z
  .object({
    courseId: validIdSchema,
    billingPeriod: z.string().regex(PERIOD_REGEX, 'Use YYYY-MM format'),
    grossAmountRupees: z.number().min(0, 'Gross fee cannot be negative').max(10000000),
    discountRupees: z.number().min(0, 'Discount cannot be negative').max(10000000).default(0),
    dueDate: z.string().regex(DATE_REGEX, 'Select a valid due date'),
    notes: z.string().trim().max(300).default(''),
    isCancelled: z.boolean().default(false),
  })
  .refine((data) => data.discountRupees <= data.grossAmountRupees, {
    message: 'Discount cannot exceed gross invoice amount',
    path: ['discountRupees'],
  });

export const paymentCreateSchema = z.object({
  invoiceId: validIdSchema,
  idempotencyKey: z
    .string()
    .trim()
    .min(6, 'Idempotency key too short')
    .max(96)
    .regex(ID_REGEX, 'Invalid idempotency key'),
  amountRupees: z.number().positive('Payment amount must be greater than ₹0').max(10000000),
  paymentMethod: z.nativeEnum(PaymentMethod),
  paymentDate: z.string().regex(DATE_REGEX, 'Select a valid payment date'),
  referenceNote: z.string().trim().max(200).default(''),
});

export const paymentUpdateSchema = z.object({
  amountRupees: z.number().positive('Payment amount must be greater than ₹0').max(10000000),
  paymentMethod: z.nativeEnum(PaymentMethod),
  paymentDate: z.string().regex(DATE_REGEX, 'Select a valid payment date'),
  referenceNote: z.string().trim().max(200).default(''),
  status: z.nativeEnum(PaymentStatus).default(PaymentStatus.COMPLETED),
  reversalReason: z.string().trim().max(200).default(''),
});

export const teacherAgreementInputSchema = z.object({
  teacherId: validIdSchema,
  modelType: z.nativeEnum(TeacherCompensationModel),
  fixedMonthlyRupees: z.number().min(0).max(10000000).default(0),
  sharePercentage: z.number().min(0, 'Percentage cannot be negative').max(100, 'Percentage cannot exceed 100%').default(0),
  perStudentRupees: z.number().min(0).max(10000000).default(0),
  effectiveFrom: z.string().regex(DATE_REGEX, 'Select a valid effective start date'),
  effectiveTo: z
    .string()
    .max(16)
    .refine((v) => v === '' || DATE_REGEX.test(v), 'Select a valid effective end date')
    .default(''),
  notes: z.string().trim().max(240).default(''),
});

export const teacherAgreementUpdateSchema = teacherAgreementInputSchema.extend({
  status: z.enum(['ACTIVE', 'SUPERSEDED']).default('ACTIVE'),
});

export const teacherAllocationUpdateSchema = z.object({
  billingPeriod: z.string().regex(PERIOD_REGEX, 'Use YYYY-MM format'),
  basisAmountRupees: z.number().min(0, 'Basis amount cannot be negative').max(10000000),
  allocatedAmountRupees: z.number().min(0, 'Allocated share cannot be negative').max(10000000),
  rateSnapshotLabel: z.string().trim().min(1, 'Snapshot label is required').max(120),
  status: z.nativeEnum(AllocationStatus),
});

export const teacherPayoutInputSchema = z.object({
  teacherId: validIdSchema,
  billingPeriod: z.string().regex(PERIOD_REGEX, 'Use YYYY-MM format'),
  amountRupees: z.number().positive('Payout amount must be greater than ₹0').max(10000000),
  paymentMethod: z.nativeEnum(PaymentMethod),
  payoutDate: z.string().regex(DATE_REGEX, 'Select a valid payout date'),
  referenceNote: z.string().trim().max(200).default(''),
});

export const teacherPayoutUpdateSchema = teacherPayoutInputSchema.extend({
  status: z.nativeEnum(PayoutStatus).default(PayoutStatus.PAID),
});

export const expenseInputSchema = z.object({
  title: z.string().trim().min(2, 'Expense title is required').max(140),
  category: z.nativeEnum(ExpenseCategory),
  amountRupees: z.number().positive('Expense amount must be greater than ₹0').max(10000000),
  expenseDate: z.string().regex(DATE_REGEX, 'Select a valid expense date'),
  paymentMethod: z.nativeEnum(PaymentMethod),
  vendorName: z.string().trim().max(120).default(''),
  notes: z.string().trim().max(240).default(''),
});

export const expenseUpdateSchema = expenseInputSchema.extend({
  status: z.enum(['RECORDED', 'REVERSED']).default('RECORDED'),
});

export const studentReportInputSchema = z
  .object({
    studentId: validIdSchema,
    reportingPeriod: z.string().regex(PERIOD_REGEX, 'Select reporting month YYYY-MM'),
    subject: z.string().trim().min(1, 'Subject is required').max(80),
    attendancePercent: z.number().int().min(0, 'Min 0%').max(100, 'Max 100%'),
    testMarks: z.number().int().min(0, 'Marks cannot be negative'),
    maxMarks: z.number().int().min(1, 'Maximum marks must be at least 1').max(1000),
    academicProgress: z.nativeEnum(AcademicProgress),
    strengths: z.string().trim().max(400).default(''),
    areasForImprovement: z.string().trim().max(400).default(''),
    teacherComments: z.string().trim().max(600).default(''),
    submissionDate: z.string().regex(DATE_REGEX, 'Select a valid submission date'),
  })
  .refine((d) => d.testMarks <= d.maxMarks, {
    message: 'Scored marks cannot exceed maximum marks',
    path: ['testMarks'],
  });

export const instituteSettingsInputSchema = z.object({
  instituteName: z.string().trim().min(2).max(140),
  logoUrl: z.string().trim().max(500).default(''),
  tagline: z.string().trim().max(200).default(''),
  phone: z.string().trim().max(32).default(''),
  email: z.string().trim().max(160).default(''),
  address: z.string().trim().max(300).default(''),
  city: z.string().trim().max(80).default(''),
  receiptPrefix: z.string().trim().min(1).max(16),
  defaultDueDay: z.number().int().min(1).max(28),
  financialYearStartMonth: z.number().int().min(1).max(12),
});

export const roleUpdateSchema = z.object({
  userId: validIdSchema,
  displayName: z.string().trim().min(1, 'Display name is required').max(120).optional(),
  email: z.string().trim().email('Enter a valid email').max(160).optional(),
  role: z.nativeEnum(UserRole),
  teacherId: optionalIdSchema.default(''),
  status: z.enum(['ACTIVE', 'SUSPENDED']).default('ACTIVE'),
});

export const auditLogUpdateSchema = z.object({
  action: z.string().trim().min(2, 'Action code is required').max(64),
  summary: z.string().trim().min(2, 'Summary is required').max(300),
  amountRupees: z.number().min(0).max(10000000).default(0),
});
