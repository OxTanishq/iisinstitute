import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, type User as FirebaseUser } from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
  writeBatch,
  type DocumentReference,
  type Query,
  type DocumentData,
} from 'firebase/firestore';
import { toast } from 'sonner';
import {
  auth,
  BOOTSTRAPPED_ADMIN_EMAIL,
  db,
  generateCleanId,
  googleProvider,
  handleFirestoreError,
  OperationType,
  timestampToISO,
} from '../lib/firebase';
import { buildIsolatedDemoDataset, type DemoDataset } from '../lib/demoData';
import {
  AcademicProgress,
  AllocationStatus,
  AuditLog,
  Batch,
  Course,
  Enrollment,
  Expense,
  ExpenseCategory,
  InstituteSettings,
  Invoice,
  InvoiceStatus,
  Payment,
  PaymentMethod,
  PaymentSchedule,
  PaymentStatus,
  PayoutStatus,
  Student,
  StudentReport,
  Teacher,
  TeacherAgreement,
  TeacherCompensationModel,
  TeacherPayout,
  TeacherShareAllocation,
  UserProfile,
  UserRole,
} from '../shared/types';
import {
  calculatePaymentTeacherShare,
  findEffectiveAgreement,
  formatINR,
  getCurrentPeriodIST,
  getTodayIST,
  periodFromDate,
  reconcileInvoiceState,
  toPaise,
} from '../shared/finance';
import {
  auditLogUpdateSchema,
  batchInputSchema,
  courseInputSchema,
  expenseInputSchema,
  expenseUpdateSchema,
  instituteSettingsInputSchema,
  invoiceCreateSchema,
  invoiceUpdateSchema,
  paymentCreateSchema,
  paymentUpdateSchema,
  roleUpdateSchema,
  studentInputSchema,
  studentReportInputSchema,
  teacherAgreementInputSchema,
  teacherAgreementUpdateSchema,
  teacherAllocationUpdateSchema,
  teacherInputSchema,
  teacherPayoutInputSchema,
  teacherPayoutUpdateSchema,
} from '../shared/validation';

const DEFAULT_SETTINGS: InstituteSettings = {
  id: 'general',
  instituteName: 'IIS Institute',
  logoUrl: '',
  tagline: 'Excellence in Academic & Competitive Coaching',
  phone: '',
  email: '',
  address: '',
  city: '',
  receiptPrefix: 'IIS',
  defaultDueDay: 10,
  financialYearStartMonth: 4,
  updatedBy: '',
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
};

export interface InstituteContextValue {
  // Auth & Mode
  authReady: boolean;
  dataLoading: boolean;
  firebaseUser: FirebaseUser | null;
  currentUserProfile: UserProfile | null;
  activeRole: UserRole;
  isDemoMode: boolean;
  selectedPeriod: string;
  setSelectedPeriod: (period: string) => void;
  signInWithGoogle: () => Promise<void>;
  signOutUser: () => Promise<void>;
  enterDemoSandbox: (role?: UserRole) => void;
  exitDemoSandbox: () => void;
  switchDemoRole: (role: UserRole) => void;
  getAuthToken: () => Promise<string | null>;

  // Data Collections
  users: UserProfile[];
  settings: InstituteSettings;
  courses: Course[];
  batches: Batch[];
  teachers: Teacher[];
  students: Student[];
  enrollments: Enrollment[];
  invoices: Invoice[];
  payments: Payment[];
  agreements: TeacherAgreement[];
  allocations: TeacherShareAllocation[];
  payouts: TeacherPayout[];
  expenses: Expense[];
  reports: StudentReport[];
  auditLogs: AuditLog[];

  // Actions
  createCourse: (input: {
    code: string;
    name: string;
    subjectCategory: string;
    defaultMonthlyFeeRupees: number;
    durationMonths: number;
  }) => Promise<void>;
  updateCourse: (
    courseId: string,
    input: {
      code: string;
      name: string;
      subjectCategory: string;
      defaultMonthlyFeeRupees: number;
      durationMonths: number;
      status: 'ACTIVE' | 'ARCHIVED';
    }
  ) => Promise<void>;
  archiveCourse: (courseId: string) => Promise<void>;
  deleteCourse: (courseId: string) => Promise<void>;

  createBatch: (input: {
    code: string;
    name: string;
    courseId: string;
    teacherId: string;
    scheduleLabel: string;
  }) => Promise<void>;
  updateBatch: (
    batchId: string,
    input: {
      code: string;
      name: string;
      courseId: string;
      teacherId: string;
      scheduleLabel: string;
      status: 'ACTIVE' | 'ARCHIVED';
    }
  ) => Promise<void>;
  deleteBatch: (batchId: string) => Promise<void>;

  createTeacher: (input: {
    teacherCode: string;
    fullName: string;
    email: string;
    phone: string;
    specialization: string;
    subjects: string[];
    linkedUserUid: string;
    joinedDate: string;
  }) => Promise<void>;
  updateTeacher: (
    teacherId: string,
    input: {
      teacherCode: string;
      fullName: string;
      email: string;
      phone: string;
      specialization: string;
      subjects: string[];
      linkedUserUid: string;
      joinedDate: string;
      status: 'ACTIVE' | 'ARCHIVED';
    }
  ) => Promise<void>;
  deleteTeacher: (teacherId: string) => Promise<void>;

  saveTeacherAgreement: (input: {
    teacherId: string;
    modelType: TeacherCompensationModel;
    fixedMonthlyRupees: number;
    sharePercentage: number;
    perStudentRupees: number;
    effectiveFrom: string;
    effectiveTo: string;
    notes: string;
  }) => Promise<void>;
  updateTeacherAgreement: (
    agreementId: string,
    input: {
      teacherId: string;
      modelType: TeacherCompensationModel;
      fixedMonthlyRupees: number;
      sharePercentage: number;
      perStudentRupees: number;
      effectiveFrom: string;
      effectiveTo: string;
      notes: string;
      status: 'ACTIVE' | 'SUPERSEDED';
    }
  ) => Promise<void>;
  deleteTeacherAgreement: (agreementId: string) => Promise<void>;

  accrueMonthlyFixedSalaries: (period: string) => Promise<number>;
  updateTeacherAllocation: (
    allocationId: string,
    input: {
      billingPeriod: string;
      basisAmountRupees: number;
      allocatedAmountRupees: number;
      rateSnapshotLabel: string;
      status: AllocationStatus;
    }
  ) => Promise<void>;
  deleteTeacherAllocation: (allocationId: string) => Promise<void>;

  createStudent: (input: {
    studentCode: string;
    fullName: string;
    primaryCourseId: string;
    courseIds: string[];
    batchId: string;
    enrollmentDate: string;
    monthlyFeeRupees: number;
    paymentSchedule: PaymentSchedule;
    status: 'ACTIVE' | 'INACTIVE' | 'ARCHIVED';
    guardianName: string;
    guardianPhone: string;
    assignedTeacherId: string;
  }) => Promise<void>;

  updateStudent: (
    studentId: string,
    input: {
      studentCode: string;
      fullName: string;
      primaryCourseId: string;
      courseIds: string[];
      batchId: string;
      enrollmentDate: string;
      monthlyFeeRupees: number;
      paymentSchedule: PaymentSchedule;
      status: 'ACTIVE' | 'INACTIVE' | 'ARCHIVED';
      guardianName: string;
      guardianPhone: string;
      assignedTeacherId: string;
    }
  ) => Promise<void>;

  archiveStudent: (studentId: string) => Promise<void>;
  deleteStudent: (studentId: string) => Promise<void>;

  createInvoice: (input: {
    studentId: string;
    courseId: string;
    billingPeriod: string;
    grossAmountRupees: number;
    discountRupees: number;
    dueDate: string;
    notes: string;
  }) => Promise<void>;
  updateInvoice: (
    invoiceId: string,
    input: {
      courseId: string;
      billingPeriod: string;
      grossAmountRupees: number;
      discountRupees: number;
      dueDate: string;
      notes: string;
      isCancelled?: boolean;
    }
  ) => Promise<void>;
  deleteInvoice: (invoiceId: string) => Promise<void>;

  generateMonthlyInvoicesForActiveStudents: (billingPeriod: string) => Promise<number>;

  recordFeePayment: (input: {
    invoiceId: string;
    idempotencyKey: string;
    amountRupees: number;
    paymentMethod: PaymentMethod;
    paymentDate: string;
    referenceNote: string;
  }) => Promise<Payment>;
  updateFeePayment: (
    paymentId: string,
    input: {
      amountRupees: number;
      paymentMethod: PaymentMethod;
      paymentDate: string;
      referenceNote: string;
      status: PaymentStatus;
      reversalReason?: string;
    }
  ) => Promise<void>;
  reverseFeePayment: (paymentId: string, reason: string) => Promise<void>;
  deleteFeePayment: (paymentId: string) => Promise<void>;

  recordTeacherPayout: (input: {
    teacherId: string;
    billingPeriod: string;
    amountRupees: number;
    paymentMethod: PaymentMethod;
    payoutDate: string;
    referenceNote: string;
  }) => Promise<void>;
  updateTeacherPayout: (
    payoutId: string,
    input: {
      teacherId: string;
      billingPeriod: string;
      amountRupees: number;
      paymentMethod: PaymentMethod;
      payoutDate: string;
      referenceNote: string;
      status: PayoutStatus;
    }
  ) => Promise<void>;
  deleteTeacherPayout: (payoutId: string) => Promise<void>;

  createExpense: (input: {
    title: string;
    category: ExpenseCategory;
    amountRupees: number;
    expenseDate: string;
    paymentMethod: PaymentMethod;
    vendorName: string;
    notes: string;
  }) => Promise<void>;
  updateExpense: (
    expenseId: string,
    input: {
      title: string;
      category: ExpenseCategory;
      amountRupees: number;
      expenseDate: string;
      paymentMethod: PaymentMethod;
      vendorName: string;
      notes: string;
      status: 'RECORDED' | 'REVERSED';
    }
  ) => Promise<void>;
  reverseExpense: (expenseId: string, reason: string) => Promise<void>;
  deleteExpense: (expenseId: string) => Promise<void>;

  submitStudentReport: (input: {
    studentId: string;
    reportingPeriod: string;
    subject: string;
    attendancePercent: number;
    testMarks: number;
    maxMarks: number;
    academicProgress: AcademicProgress;
    strengths: string;
    areasForImprovement: string;
    teacherComments: string;
    submissionDate: string;
  }) => Promise<void>;

  updateStudentReport: (
    reportId: string,
    input: {
      studentId: string;
      reportingPeriod: string;
      subject: string;
      attendancePercent: number;
      testMarks: number;
      maxMarks: number;
      academicProgress: AcademicProgress;
      strengths: string;
      areasForImprovement: string;
      teacherComments: string;
      submissionDate: string;
    }
  ) => Promise<void>;
  deleteStudentReport: (reportId: string) => Promise<void>;

  saveInstituteSettings: (input: {
    instituteName: string;
    logoUrl: string;
    tagline: string;
    phone: string;
    email: string;
    address: string;
    city: string;
    receiptPrefix: string;
    defaultDueDay: number;
    financialYearStartMonth: number;
  }) => Promise<void>;
  resetInstituteSettings: () => Promise<void>;

  updateUserRole: (input: {
    userId: string;
    displayName?: string;
    email?: string;
    role: UserRole;
    teacherId: string;
    status: 'ACTIVE' | 'SUSPENDED';
  }) => Promise<void>;
  deleteUserProfile: (userId: string) => Promise<void>;

  updateAuditLog: (
    logId: string,
    input: {
      action: string;
      summary: string;
      amountRupees: number;
    }
  ) => Promise<void>;
  deleteAuditLog: (logId: string) => Promise<void>;
}

const InstituteContext = createContext<InstituteContextValue | null>(null);

export function useInstitute(): InstituteContextValue {
  const ctx = useContext(InstituteContext);
  if (!ctx) {
    throw new Error('useInstitute must be used inside InstituteProvider');
  }
  return ctx;
}

export function InstituteProvider({ children }: { children: React.ReactNode }) {
  const [authReady, setAuthReady] = useState(false);
  const [dataLoading, setDataLoading] = useState(false);
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [currentUserProfile, setCurrentUserProfile] = useState<UserProfile | null>(null);

  // Isolated Demo Sandbox State
  const [isDemoMode, setIsDemoMode] = useState(false);
  const [demoRole, setDemoRole] = useState<UserRole>(UserRole.ADMIN);
  const [demoData, setDemoData] = useState<DemoDataset>(() => buildIsolatedDemoDataset());

  const [selectedPeriod, setSelectedPeriod] = useState<string>(() => getCurrentPeriodIST());

  // Live Firestore Collections State
  const [liveUsers, setLiveUsers] = useState<UserProfile[]>([]);
  const [liveSettings, setLiveSettings] = useState<InstituteSettings>(DEFAULT_SETTINGS);
  const [liveCourses, setLiveCourses] = useState<Course[]>([]);
  const [liveBatches, setLiveBatches] = useState<Batch[]>([]);
  const [liveTeachers, setLiveTeachers] = useState<Teacher[]>([]);
  const [liveStudents, setLiveStudents] = useState<Student[]>([]);
  const [liveEnrollments, setLiveEnrollments] = useState<Enrollment[]>([]);
  const [liveInvoices, setLiveInvoices] = useState<Invoice[]>([]);
  const [livePayments, setLivePayments] = useState<Payment[]>([]);
  const [liveAgreements, setLiveAgreements] = useState<TeacherAgreement[]>([]);
  const [liveAllocations, setLiveAllocations] = useState<TeacherShareAllocation[]>([]);
  const [livePayouts, setLivePayouts] = useState<TeacherPayout[]>([]);
  const [liveExpenses, setLiveExpenses] = useState<Expense[]>([]);
  const [liveReports, setLiveReports] = useState<StudentReport[]>([]);
  const [liveAuditLogs, setLiveAuditLogs] = useState<AuditLog[]>([]);

  // 1. Auth & User Profile Bootstrap
  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      setFirebaseUser(fbUser);
      if (!fbUser) {
        setCurrentUserProfile(null);
        setAuthReady(true);
        return;
      }

      setDataLoading(true);
      const userDocPath = `users/${fbUser.uid}`;
      try {
        const userRef = doc(db, 'users', fbUser.uid);
        const snap = await getDoc(userRef);
        const isBootstrappedOwner =
          Boolean(fbUser.emailVerified) &&
          fbUser.email?.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase();

        if (!snap.exists()) {
          const initialRole = isBootstrappedOwner ? UserRole.ADMIN : UserRole.TEACHER;
          await setDoc(userRef, {
            uid: fbUser.uid,
            email: fbUser.email ?? 'staff@iisinstitute.edu.in',
            displayName: fbUser.displayName?.trim() || fbUser.email?.split('@')[0] || 'Institute User',
            role: initialRole,
            teacherId: '',
            status: 'ACTIVE',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
          const createdSnap = await getDoc(userRef);
          const d = createdSnap.data();
          if (d) {
            setCurrentUserProfile({
              id: createdSnap.id,
              uid: d.uid,
              email: d.email,
              displayName: d.displayName,
              role: d.role as UserRole,
              teacherId: d.teacherId ?? '',
              status: d.status,
              createdAt: timestampToISO(d.createdAt),
              updatedAt: timestampToISO(d.updatedAt),
            });
          }
        } else {
          const d = snap.data();
          setCurrentUserProfile({
            id: snap.id,
            uid: d.uid,
            email: d.email,
            displayName: d.displayName,
            role: d.role as UserRole,
            teacherId: d.teacherId ?? '',
            status: d.status,
            createdAt: timestampToISO(d.createdAt),
            updatedAt: timestampToISO(d.updatedAt),
          });
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, userDocPath);
      } finally {
        setAuthReady(true);
      }
    });

    return () => unsub();
  }, []);

  // 2. Role-Scoped Real-Time Firestore Listeners
  useEffect(() => {
    if (!authReady || !firebaseUser || !currentUserProfile || isDemoMode) {
      setDataLoading(false);
      return;
    }

    if (currentUserProfile.status === 'SUSPENDED') {
      setDataLoading(false);
      return;
    }

    setDataLoading(true);
    const uid = firebaseUser.uid;
    const role = currentUserProfile.role;
    const isOwner =
      Boolean(firebaseUser.emailVerified) &&
      firebaseUser.email?.toLowerCase() === BOOTSTRAPPED_ADMIN_EMAIL.toLowerCase();

    const unsubs: Array<() => void> = [];

    const subscribeQuery = <T,>(
      path: string,
      q: Query<DocumentData>,
      mapper: (id: string, data: DocumentData) => T,
      setter: (items: T[]) => void
    ) => {
      const u = onSnapshot(
        q,
        (snapshot) => {
          const list = snapshot.docs.map((docSnap) => mapper(docSnap.id, docSnap.data()));
          setter(list);
          setDataLoading(false);
        },
        (err) => {
          handleFirestoreError(err, OperationType.LIST, path);
        }
      );
      unsubs.push(u);
    };

    // Settings document listener
    const settingsUnsub = onSnapshot(
      doc(db, 'institute_settings', 'general'),
      (snap) => {
        if (snap.exists()) {
          const d = snap.data();
          setLiveSettings({
            id: snap.id,
            instituteName: d.instituteName,
            logoUrl: d.logoUrl ?? '',
            tagline: d.tagline ?? '',
            phone: d.phone ?? '',
            email: d.email ?? '',
            address: d.address ?? '',
            city: d.city ?? '',
            receiptPrefix: d.receiptPrefix ?? 'IIS',
            defaultDueDay: d.defaultDueDay ?? 10,
            financialYearStartMonth: d.financialYearStartMonth ?? 4,
            updatedBy: d.updatedBy ?? '',
            createdAt: timestampToISO(d.createdAt),
            updatedAt: timestampToISO(d.updatedAt),
          });
        } else {
          setLiveSettings(DEFAULT_SETTINGS);
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, 'institute_settings/general')
    );
    unsubs.push(settingsUnsub);

    // Self user profile listener
    const selfUnsub = onSnapshot(
      doc(db, 'users', uid),
      (snap) => {
        if (snap.exists()) {
          const d = snap.data();
          setCurrentUserProfile({
            id: snap.id,
            uid: d.uid,
            email: d.email,
            displayName: d.displayName,
            role: d.role as UserRole,
            teacherId: d.teacherId ?? '',
            status: d.status,
            createdAt: timestampToISO(d.createdAt),
            updatedAt: timestampToISO(d.updatedAt),
          });
        }
      },
      (err) => handleFirestoreError(err, OperationType.GET, `users/${uid}`)
    );
    unsubs.push(selfUnsub);

    const buildFinanceScopedQuery = (colName: string): Query<DocumentData> =>
      isOwner
        ? query(collection(db, colName))
        : query(collection(db, colName), where('financeViewerUids', 'array-contains', uid));

    if (isOwner) {
      subscribeQuery<UserProfile>(
        'users',
        query(collection(db, 'users')),
        (id, d) => ({
          id,
          uid: d.uid,
          email: d.email,
          displayName: d.displayName,
          role: d.role as UserRole,
          teacherId: d.teacherId ?? '',
          status: d.status,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveUsers
      );
    } else {
      setLiveUsers([currentUserProfile]);
    }

    if (role === UserRole.ADMIN || role === UserRole.ACCOUNTANT) {
      subscribeQuery<Course>(
        'courses',
        buildFinanceScopedQuery('courses'),
        (id, d) => ({
          id,
          code: d.code,
          name: d.name,
          subjectCategory: d.subjectCategory ?? '',
          defaultMonthlyFeePaise: d.defaultMonthlyFeePaise ?? 0,
          durationMonths: d.durationMonths ?? 12,
          status: d.status,
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveCourses
      );

      subscribeQuery<Batch>(
        'batches',
        buildFinanceScopedQuery('batches'),
        (id, d) => ({
          id,
          code: d.code,
          name: d.name,
          courseId: d.courseId,
          courseName: d.courseName,
          teacherId: d.teacherId,
          teacherUid: d.teacherUid ?? '',
          teacherName: d.teacherName,
          scheduleLabel: d.scheduleLabel ?? '',
          status: d.status,
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveBatches
      );

      subscribeQuery<Teacher>(
        'teachers',
        buildFinanceScopedQuery('teachers'),
        (id, d) => ({
          id,
          teacherCode: d.teacherCode,
          fullName: d.fullName,
          email: d.email,
          phone: d.phone ?? '',
          specialization: d.specialization ?? '',
          subjects: d.subjects ?? [],
          linkedUserUid: d.linkedUserUid ?? '',
          joinedDate: d.joinedDate,
          status: d.status,
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveTeachers
      );

      subscribeQuery<Student>(
        'students',
        buildFinanceScopedQuery('students'),
        (id, d) => ({
          id,
          studentCode: d.studentCode,
          fullName: d.fullName,
          primaryCourseId: d.primaryCourseId,
          primaryCourseName: d.primaryCourseName,
          courseIds: d.courseIds ?? [],
          batchId: d.batchId,
          batchName: d.batchName,
          enrollmentDate: d.enrollmentDate,
          monthlyFeePaise: d.monthlyFeePaise ?? 0,
          paymentSchedule: d.paymentSchedule as PaymentSchedule,
          status: d.status,
          guardianName: d.guardianName ?? '',
          guardianPhone: d.guardianPhone ?? '',
          assignedTeacherId: d.assignedTeacherId,
          assignedTeacherUid: d.assignedTeacherUid ?? '',
          assignedTeacherName: d.assignedTeacherName,
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveStudents
      );

      subscribeQuery<Enrollment>(
        'enrollments',
        buildFinanceScopedQuery('enrollments'),
        (id, d) => ({
          id,
          studentId: d.studentId,
          studentName: d.studentName,
          courseId: d.courseId,
          courseName: d.courseName,
          batchId: d.batchId,
          teacherId: d.teacherId,
          assignedTeacherUid: d.assignedTeacherUid ?? '',
          agreedFeePaise: d.agreedFeePaise ?? 0,
          startDate: d.startDate,
          status: d.status,
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveEnrollments
      );

      subscribeQuery<Invoice>(
        'invoices',
        buildFinanceScopedQuery('invoices'),
        (id, d) => ({
          id,
          invoiceNumber: d.invoiceNumber,
          studentId: d.studentId,
          studentName: d.studentName,
          courseId: d.courseId,
          courseName: d.courseName,
          batchId: d.batchId ?? '',
          billingPeriod: d.billingPeriod,
          grossAmountPaise: d.grossAmountPaise ?? 0,
          discountPaise: d.discountPaise ?? 0,
          netAmountDuePaise: d.netAmountDuePaise ?? 0,
          paidAmountPaise: d.paidAmountPaise ?? 0,
          balanceDuePaise: d.balanceDuePaise ?? 0,
          dueDate: d.dueDate,
          status: d.status as InvoiceStatus,
          assignedTeacherId: d.assignedTeacherId ?? '',
          notes: d.notes ?? '',
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveInvoices
      );

      subscribeQuery<Payment>(
        'payments',
        buildFinanceScopedQuery('payments'),
        (id, d) => ({
          id,
          receiptNumber: d.receiptNumber,
          idempotencyKey: d.idempotencyKey,
          invoiceId: d.invoiceId,
          studentId: d.studentId,
          studentName: d.studentName,
          courseId: d.courseId ?? '',
          courseName: d.courseName,
          billingPeriod: d.billingPeriod,
          amountPaise: d.amountPaise ?? 0,
          paymentMethod: d.paymentMethod as PaymentMethod,
          paymentDate: d.paymentDate,
          referenceNote: d.referenceNote ?? '',
          status: d.status as PaymentStatus,
          reversalReason: d.reversalReason ?? '',
          financeViewerUids: d.financeViewerUids ?? [],
          recordedBy: d.recordedBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLivePayments
      );

      subscribeQuery<TeacherAgreement>(
        'teacher_agreements',
        buildFinanceScopedQuery('teacher_agreements'),
        (id, d) => ({
          id,
          teacherId: d.teacherId,
          teacherUid: d.teacherUid ?? '',
          teacherName: d.teacherName,
          modelType: d.modelType as TeacherCompensationModel,
          fixedMonthlyPaise: d.fixedMonthlyPaise ?? 0,
          shareBasisPoints: d.shareBasisPoints ?? 0,
          perStudentPaise: d.perStudentPaise ?? 0,
          effectiveFrom: d.effectiveFrom,
          effectiveTo: d.effectiveTo ?? '',
          notes: d.notes ?? '',
          status: d.status,
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveAgreements
      );

      subscribeQuery<TeacherShareAllocation>(
        'teacher_share_allocations',
        buildFinanceScopedQuery('teacher_share_allocations'),
        (id, d) => ({
          id,
          agreementId: d.agreementId ?? '',
          modelTypeSnapshot: d.modelTypeSnapshot as TeacherCompensationModel,
          rateSnapshotLabel: d.rateSnapshotLabel ?? '',
          teacherId: d.teacherId,
          teacherUid: d.teacherUid ?? '',
          teacherName: d.teacherName,
          paymentId: d.paymentId ?? '',
          invoiceId: d.invoiceId ?? '',
          studentId: d.studentId ?? '',
          studentName: d.studentName ?? '',
          billingPeriod: d.billingPeriod,
          basisAmountPaise: d.basisAmountPaise ?? 0,
          allocatedAmountPaise: d.allocatedAmountPaise ?? 0,
          status: d.status as AllocationStatus,
          payoutId: d.payoutId ?? '',
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveAllocations
      );

      subscribeQuery<TeacherPayout>(
        'teacher_payouts',
        buildFinanceScopedQuery('teacher_payouts'),
        (id, d) => ({
          id,
          payoutNumber: d.payoutNumber,
          teacherId: d.teacherId,
          teacherUid: d.teacherUid ?? '',
          teacherName: d.teacherName,
          billingPeriod: d.billingPeriod,
          amountPaise: d.amountPaise ?? 0,
          paymentMethod: d.paymentMethod as PaymentMethod,
          payoutDate: d.payoutDate,
          referenceNote: d.referenceNote ?? '',
          status: d.status as PayoutStatus,
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLivePayouts
      );

      subscribeQuery<Expense>(
        'expenses',
        buildFinanceScopedQuery('expenses'),
        (id, d) => ({
          id,
          title: d.title,
          category: d.category as ExpenseCategory,
          amountPaise: d.amountPaise ?? 0,
          expenseDate: d.expenseDate,
          billingPeriod: d.billingPeriod,
          paymentMethod: d.paymentMethod as PaymentMethod,
          vendorName: d.vendorName ?? '',
          notes: d.notes ?? '',
          status: d.status,
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveExpenses
      );

      if (role === UserRole.ADMIN) {
        subscribeQuery<StudentReport>(
          'student_reports',
          buildFinanceScopedQuery('student_reports'),
          (id, d) => ({
            id,
            studentId: d.studentId,
            studentName: d.studentName,
            courseId: d.courseId ?? '',
            courseName: d.courseName ?? '',
            teacherId: d.teacherId,
            teacherUid: d.teacherUid ?? '',
            teacherName: d.teacherName,
            reportingPeriod: d.reportingPeriod,
            subject: d.subject,
            attendancePercent: d.attendancePercent ?? 0,
            testMarks: d.testMarks ?? 0,
            maxMarks: d.maxMarks ?? 100,
            academicProgress: d.academicProgress as AcademicProgress,
            strengths: d.strengths ?? '',
            areasForImprovement: d.areasForImprovement ?? '',
            teacherComments: d.teacherComments ?? '',
            submissionDate: d.submissionDate,
            financeViewerUids: d.financeViewerUids ?? [],
            createdBy: d.createdBy,
            createdAt: timestampToISO(d.createdAt),
            updatedAt: timestampToISO(d.updatedAt),
          }),
          setLiveReports
        );

        if (isOwner) {
          subscribeQuery<AuditLog>(
            'audit_logs',
            query(collection(db, 'audit_logs')),
            (id, d) => ({
              id,
              actorUid: d.actorUid,
              actorEmail: d.actorEmail,
              actorRole: d.actorRole as UserRole,
              entityType: d.entityType,
              entityId: d.entityId,
              action: d.action,
              summary: d.summary,
              amountPaise: d.amountPaise ?? 0,
              createdAt: timestampToISO(d.createdAt),
            }),
            setLiveAuditLogs
          );
        }
      }
    } else if (role === UserRole.TEACHER) {
      // Strictly scoped Teacher queries — NEVER subscribes to invoices, payments, expenses, or audit_logs
      setLiveInvoices([]);
      setLivePayments([]);
      setLiveExpenses([]);
      setLiveAuditLogs([]);
      setLiveCourses([]);

      subscribeQuery<Teacher>(
        'teachers',
        query(collection(db, 'teachers'), where('linkedUserUid', '==', uid)),
        (id, d) => ({
          id,
          teacherCode: d.teacherCode,
          fullName: d.fullName,
          email: d.email,
          phone: d.phone ?? '',
          specialization: d.specialization ?? '',
          subjects: d.subjects ?? [],
          linkedUserUid: d.linkedUserUid ?? '',
          joinedDate: d.joinedDate,
          status: d.status,
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveTeachers
      );

      subscribeQuery<Batch>(
        'batches',
        query(collection(db, 'batches'), where('teacherUid', '==', uid)),
        (id, d) => ({
          id,
          code: d.code,
          name: d.name,
          courseId: d.courseId,
          courseName: d.courseName,
          teacherId: d.teacherId,
          teacherUid: d.teacherUid ?? '',
          teacherName: d.teacherName,
          scheduleLabel: d.scheduleLabel ?? '',
          status: d.status,
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveBatches
      );

      subscribeQuery<Student>(
        'students',
        query(collection(db, 'students'), where('assignedTeacherUid', '==', uid)),
        (id, d) => ({
          id,
          studentCode: d.studentCode,
          fullName: d.fullName,
          primaryCourseId: d.primaryCourseId,
          primaryCourseName: d.primaryCourseName,
          courseIds: d.courseIds ?? [],
          batchId: d.batchId,
          batchName: d.batchName,
          enrollmentDate: d.enrollmentDate,
          monthlyFeePaise: d.monthlyFeePaise ?? 0,
          paymentSchedule: d.paymentSchedule as PaymentSchedule,
          status: d.status,
          guardianName: d.guardianName ?? '',
          guardianPhone: d.guardianPhone ?? '',
          assignedTeacherId: d.assignedTeacherId,
          assignedTeacherUid: d.assignedTeacherUid ?? '',
          assignedTeacherName: d.assignedTeacherName,
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveStudents
      );

      subscribeQuery<Enrollment>(
        'enrollments',
        query(collection(db, 'enrollments'), where('assignedTeacherUid', '==', uid)),
        (id, d) => ({
          id,
          studentId: d.studentId,
          studentName: d.studentName,
          courseId: d.courseId,
          courseName: d.courseName,
          batchId: d.batchId,
          teacherId: d.teacherId,
          assignedTeacherUid: d.assignedTeacherUid ?? '',
          agreedFeePaise: d.agreedFeePaise ?? 0,
          startDate: d.startDate,
          status: d.status,
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveEnrollments
      );

      subscribeQuery<TeacherAgreement>(
        'teacher_agreements',
        query(collection(db, 'teacher_agreements'), where('teacherUid', '==', uid)),
        (id, d) => ({
          id,
          teacherId: d.teacherId,
          teacherUid: d.teacherUid ?? '',
          teacherName: d.teacherName,
          modelType: d.modelType as TeacherCompensationModel,
          fixedMonthlyPaise: d.fixedMonthlyPaise ?? 0,
          shareBasisPoints: d.shareBasisPoints ?? 0,
          perStudentPaise: d.perStudentPaise ?? 0,
          effectiveFrom: d.effectiveFrom,
          effectiveTo: d.effectiveTo ?? '',
          notes: d.notes ?? '',
          status: d.status,
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveAgreements
      );

      subscribeQuery<TeacherShareAllocation>(
        'teacher_share_allocations',
        query(collection(db, 'teacher_share_allocations'), where('teacherUid', '==', uid)),
        (id, d) => ({
          id,
          agreementId: d.agreementId ?? '',
          modelTypeSnapshot: d.modelTypeSnapshot as TeacherCompensationModel,
          rateSnapshotLabel: d.rateSnapshotLabel ?? '',
          teacherId: d.teacherId,
          teacherUid: d.teacherUid ?? '',
          teacherName: d.teacherName,
          paymentId: d.paymentId ?? '',
          invoiceId: d.invoiceId ?? '',
          studentId: d.studentId ?? '',
          studentName: d.studentName ?? '',
          billingPeriod: d.billingPeriod,
          basisAmountPaise: d.basisAmountPaise ?? 0,
          allocatedAmountPaise: d.allocatedAmountPaise ?? 0,
          status: d.status as AllocationStatus,
          payoutId: d.payoutId ?? '',
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveAllocations
      );

      subscribeQuery<TeacherPayout>(
        'teacher_payouts',
        query(collection(db, 'teacher_payouts'), where('teacherUid', '==', uid)),
        (id, d) => ({
          id,
          payoutNumber: d.payoutNumber,
          teacherId: d.teacherId,
          teacherUid: d.teacherUid ?? '',
          teacherName: d.teacherName,
          billingPeriod: d.billingPeriod,
          amountPaise: d.amountPaise ?? 0,
          paymentMethod: d.paymentMethod as PaymentMethod,
          payoutDate: d.payoutDate,
          referenceNote: d.referenceNote ?? '',
          status: d.status as PayoutStatus,
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLivePayouts
      );

      subscribeQuery<StudentReport>(
        'student_reports',
        query(collection(db, 'student_reports'), where('teacherUid', '==', uid)),
        (id, d) => ({
          id,
          studentId: d.studentId,
          studentName: d.studentName,
          courseId: d.courseId ?? '',
          courseName: d.courseName ?? '',
          teacherId: d.teacherId,
          teacherUid: d.teacherUid ?? '',
          teacherName: d.teacherName,
          reportingPeriod: d.reportingPeriod,
          subject: d.subject,
          attendancePercent: d.attendancePercent ?? 0,
          testMarks: d.testMarks ?? 0,
          maxMarks: d.maxMarks ?? 100,
          academicProgress: d.academicProgress as AcademicProgress,
          strengths: d.strengths ?? '',
          areasForImprovement: d.areasForImprovement ?? '',
          teacherComments: d.teacherComments ?? '',
          submissionDate: d.submissionDate,
          financeViewerUids: d.financeViewerUids ?? [],
          createdBy: d.createdBy,
          createdAt: timestampToISO(d.createdAt),
          updatedAt: timestampToISO(d.updatedAt),
        }),
        setLiveReports
      );
    }

    const fallbackTimer = setTimeout(() => setDataLoading(false), 1200);
    return () => {
      clearTimeout(fallbackTimer);
      unsubs.forEach((fn) => fn());
    };
  }, [authReady, firebaseUser, currentUserProfile?.role, currentUserProfile?.status, isDemoMode]);

  const activeRole = isDemoMode ? demoRole : currentUserProfile?.role ?? UserRole.TEACHER;

  const activeUserProfile = useMemo<UserProfile | null>(() => {
    if (!isDemoMode) return currentUserProfile;
    if (demoRole === UserRole.ADMIN) return demoData.users[0];
    if (demoRole === UserRole.TEACHER) return demoData.users[1];
    return demoData.users[2];
  }, [isDemoMode, demoRole, demoData.users, currentUserProfile]);

  // Helper to compute financeViewerUids (all active ADMIN and ACCOUNTANT UIDs, max 10)
  const getFinanceViewerUids = useCallback((): string[] => {
    const sourceUsers = isDemoMode ? demoData.users : liveUsers;
    const uids = new Set<string>();
    if (firebaseUser?.uid) uids.add(firebaseUser.uid);
    sourceUsers
      .filter((u) => u.status === 'ACTIVE' && (u.role === UserRole.ADMIN || u.role === UserRole.ACCOUNTANT))
      .forEach((u) => uids.add(u.uid));
    return Array.from(uids).slice(0, 10);
  }, [isDemoMode, demoData.users, liveUsers, firebaseUser]);

  // Scoped datasets (also enforces least-privilege scoping in Demo Sandbox when switching to TEACHER/ACCOUNTANT!)
  const courses = isDemoMode ? demoData.courses : liveCourses;
  const batches = useMemo(() => {
    const raw = isDemoMode ? demoData.batches : liveBatches;
    if (activeRole === UserRole.TEACHER && activeUserProfile) {
      return raw.filter((b) => b.teacherUid === activeUserProfile.uid || b.teacherId === activeUserProfile.teacherId);
    }
    return raw;
  }, [isDemoMode, demoData.batches, liveBatches, activeRole, activeUserProfile]);

  const teachers = useMemo(() => {
    const raw = isDemoMode ? demoData.teachers : liveTeachers;
    if (activeRole === UserRole.TEACHER && activeUserProfile) {
      return raw.filter((t) => t.linkedUserUid === activeUserProfile.uid || t.id === activeUserProfile.teacherId);
    }
    return raw;
  }, [isDemoMode, demoData.teachers, liveTeachers, activeRole, activeUserProfile]);

  const students = useMemo(() => {
    const raw = isDemoMode ? demoData.students : liveStudents;
    if (activeRole === UserRole.TEACHER && activeUserProfile) {
      return raw.filter(
        (s) => s.assignedTeacherUid === activeUserProfile.uid || s.assignedTeacherId === activeUserProfile.teacherId
      );
    }
    return raw;
  }, [isDemoMode, demoData.students, liveStudents, activeRole, activeUserProfile]);

  const enrollments = useMemo(() => {
    const raw = isDemoMode ? demoData.enrollments : liveEnrollments;
    if (activeRole === UserRole.TEACHER && activeUserProfile) {
      return raw.filter(
        (e) => e.assignedTeacherUid === activeUserProfile.uid || e.teacherId === activeUserProfile.teacherId
      );
    }
    return raw;
  }, [isDemoMode, demoData.enrollments, liveEnrollments, activeRole, activeUserProfile]);

  const invoices = useMemo(() => {
    if (activeRole === UserRole.TEACHER) return [];
    return isDemoMode ? demoData.invoices : liveInvoices;
  }, [isDemoMode, demoData.invoices, liveInvoices, activeRole]);

  const payments = useMemo(() => {
    if (activeRole === UserRole.TEACHER) return [];
    return isDemoMode ? demoData.payments : livePayments;
  }, [isDemoMode, demoData.payments, livePayments, activeRole]);

  const agreements = useMemo(() => {
    const raw = isDemoMode ? demoData.agreements : liveAgreements;
    if (activeRole === UserRole.TEACHER && activeUserProfile) {
      return raw.filter((a) => a.teacherUid === activeUserProfile.uid || a.teacherId === activeUserProfile.teacherId);
    }
    return raw;
  }, [isDemoMode, demoData.agreements, liveAgreements, activeRole, activeUserProfile]);

  const allocations = useMemo(() => {
    const raw = isDemoMode ? demoData.allocations : liveAllocations;
    if (activeRole === UserRole.TEACHER && activeUserProfile) {
      return raw.filter((a) => a.teacherUid === activeUserProfile.uid || a.teacherId === activeUserProfile.teacherId);
    }
    return raw;
  }, [isDemoMode, demoData.allocations, liveAllocations, activeRole, activeUserProfile]);

  const payouts = useMemo(() => {
    const raw = isDemoMode ? demoData.payouts : livePayouts;
    if (activeRole === UserRole.TEACHER && activeUserProfile) {
      return raw.filter((p) => p.teacherUid === activeUserProfile.uid || p.teacherId === activeUserProfile.teacherId);
    }
    return raw;
  }, [isDemoMode, demoData.payouts, livePayouts, activeRole, activeUserProfile]);

  const expenses = useMemo(() => {
    if (activeRole === UserRole.TEACHER) return [];
    return isDemoMode ? demoData.expenses : liveExpenses;
  }, [isDemoMode, demoData.expenses, liveExpenses, activeRole]);

  const reports = useMemo(() => {
    const raw = isDemoMode ? demoData.reports : liveReports;
    if (activeRole === UserRole.TEACHER && activeUserProfile) {
      return raw.filter((r) => r.teacherUid === activeUserProfile.uid || r.teacherId === activeUserProfile.teacherId);
    }
    return raw;
  }, [isDemoMode, demoData.reports, liveReports, activeRole, activeUserProfile]);

  const settings = isDemoMode ? demoData.settings : liveSettings;
  const users = isDemoMode ? demoData.users : liveUsers;
  const auditLogs = activeRole === UserRole.ADMIN ? (isDemoMode ? demoData.auditLogs : liveAuditLogs) : [];

  // Auth Actions
  const signInWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      setIsDemoMode(false);
      toast.success('Signed in to IIS Institute Management System');
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Google Sign-In failed';
      toast.error(msg);
    }
  };

  const signOutUser = async () => {
    if (isDemoMode) {
      setIsDemoMode(false);
      return;
    }
    await signOut(auth);
    toast.success('Signed out');
  };

  const enterDemoSandbox = (role: UserRole = UserRole.ADMIN) => {
    setDemoData(buildIsolatedDemoDataset());
    setDemoRole(role);
    setIsDemoMode(true);
    toast.success('Entered Isolated Demo Sandbox (production database untouched)');
  };

  const exitDemoSandbox = () => {
    setIsDemoMode(false);
    toast.info('Exited Demo Sandbox');
  };

  const switchDemoRole = (role: UserRole) => {
    setDemoRole(role);
    toast.success(`Switched Demo Sandbox role to ${role}`);
  };

  const getAuthToken = useCallback(async (): Promise<string | null> => {
    if (!auth.currentUser) return null;
    return auth.currentUser.getIdToken();
  }, []);

  // Audit helper
  const appendAuditLog = async (params: {
    entityType: string;
    entityId: string;
    action: string;
    summary: string;
    amountPaise: number;
  }) => {
    const actor = activeUserProfile;
    if (!actor) return;

    if (isDemoMode) {
      const log: AuditLog = {
        id: generateCleanId('aud'),
        actorUid: actor.uid,
        actorEmail: actor.email,
        actorRole: actor.role,
        entityType: params.entityType,
        entityId: params.entityId,
        action: params.action,
        summary: params.summary.slice(0, 300),
        amountPaise: Math.max(0, Math.round(params.amountPaise)),
        createdAt: new Date().toISOString(),
      };
      setDemoData((prev) => ({ ...prev, auditLogs: [log, ...prev.auditLogs] }));
      return;
    }

    const logId = generateCleanId('aud');
    try {
      await setDoc(doc(db, 'audit_logs', logId), {
        actorUid: actor.uid,
        actorEmail: actor.email.slice(0, 160),
        actorRole: actor.role,
        entityType: params.entityType.slice(0, 64),
        entityId: params.entityId,
        action: params.action.slice(0, 64),
        summary: params.summary.slice(0, 300),
        amountPaise: Math.max(0, Math.round(params.amountPaise)),
        createdAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `audit_logs/${logId}`);
    }
  };

  // Helper for chunked Firestore batch deletes (<= 450 docs per batch)
  const commitBatchDeletes = async (refs: DocumentReference[], pathLabel: string) => {
    if (refs.length === 0) return;
    try {
      for (let i = 0; i < refs.length; i += 450) {
        const b = writeBatch(db);
        refs.slice(i, i + 450).forEach((r) => b.delete(r));
        await b.commit();
      }
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, pathLabel);
    }
  };

  // Course CRUD
  const createCourse: InstituteContextValue['createCourse'] = async (rawInput) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can create courses.');
    const parsed = courseInputSchema.parse(rawInput);
    const id = generateCleanId('crs');
    const feePaise = toPaise(parsed.defaultMonthlyFeeRupees);
    const viewerUids = getFinanceViewerUids();

    if (isDemoMode) {
      const now = new Date().toISOString();
      const newCourse: Course = {
        id,
        code: parsed.code,
        name: parsed.name,
        subjectCategory: parsed.subjectCategory,
        defaultMonthlyFeePaise: feePaise,
        durationMonths: parsed.durationMonths,
        status: 'ACTIVE',
        financeViewerUids: viewerUids,
        createdBy: activeUserProfile!.uid,
        createdAt: now,
        updatedAt: now,
      };
      setDemoData((prev) => ({ ...prev, courses: [newCourse, ...prev.courses] }));
      await appendAuditLog({
        entityType: 'COURSE',
        entityId: id,
        action: 'CREATE_COURSE',
        summary: `Created course ${parsed.name} (${formatINR(feePaise)}/mo)`,
        amountPaise: feePaise,
      });
      return;
    }

    try {
      await setDoc(doc(db, 'courses', id), {
        code: parsed.code,
        name: parsed.name,
        subjectCategory: parsed.subjectCategory,
        defaultMonthlyFeePaise: feePaise,
        durationMonths: parsed.durationMonths,
        status: 'ACTIVE',
        financeViewerUids: viewerUids,
        createdBy: firebaseUser!.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await appendAuditLog({
        entityType: 'COURSE',
        entityId: id,
        action: 'CREATE_COURSE',
        summary: `Created course ${parsed.name} (${formatINR(feePaise)}/mo)`,
        amountPaise: feePaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `courses/${id}`);
    }
  };

  const updateCourse: InstituteContextValue['updateCourse'] = async (courseId, rawInput) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can edit courses.');
    const parsed = courseInputSchema.parse(rawInput);
    const feePaise = toPaise(parsed.defaultMonthlyFeeRupees);
    const viewerUids = getFinanceViewerUids();

    if (isDemoMode) {
      const now = new Date().toISOString();
      setDemoData((prev) => ({
        ...prev,
        courses: prev.courses.map((c) =>
          c.id === courseId
            ? {
                ...c,
                code: parsed.code,
                name: parsed.name,
                subjectCategory: parsed.subjectCategory,
                defaultMonthlyFeePaise: feePaise,
                durationMonths: parsed.durationMonths,
                status: parsed.status,
                financeViewerUids: viewerUids,
                updatedAt: now,
              }
            : c
        ),
        batches: prev.batches.map((b) =>
          b.courseId === courseId ? { ...b, courseName: parsed.name, updatedAt: now } : b
        ),
        students: prev.students.map((s) =>
          s.primaryCourseId === courseId
            ? { ...s, primaryCourseName: parsed.name, updatedAt: now }
            : s
        ),
      }));
      await appendAuditLog({
        entityType: 'COURSE',
        entityId: courseId,
        action: 'UPDATE_COURSE',
        summary: `Updated course ${parsed.name} (${formatINR(feePaise)}/mo)`,
        amountPaise: feePaise,
      });
      return;
    }

    try {
      await updateDoc(doc(db, 'courses', courseId), {
        code: parsed.code,
        name: parsed.name,
        subjectCategory: parsed.subjectCategory,
        defaultMonthlyFeePaise: feePaise,
        durationMonths: parsed.durationMonths,
        status: parsed.status,
        financeViewerUids: viewerUids,
        updatedAt: serverTimestamp(),
      });
      await appendAuditLog({
        entityType: 'COURSE',
        entityId: courseId,
        action: 'UPDATE_COURSE',
        summary: `Updated course ${parsed.name} (${formatINR(feePaise)}/mo)`,
        amountPaise: feePaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `courses/${courseId}`);
    }
  };

  const archiveCourse: InstituteContextValue['archiveCourse'] = async (courseId) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can archive courses.');
    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        courses: prev.courses.map((c) => (c.id === courseId ? { ...c, status: 'ARCHIVED' } : c)),
      }));
      return;
    }
    try {
      await updateDoc(doc(db, 'courses', courseId), {
        status: 'ARCHIVED',
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `courses/${courseId}`);
    }
  };

  const deleteCourse: InstituteContextValue['deleteCourse'] = async (courseId) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can delete courses.');
    const existing = courses.find((c) => c.id === courseId);
    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        courses: prev.courses.filter((c) => c.id !== courseId),
      }));
      await appendAuditLog({
        entityType: 'COURSE',
        entityId: courseId,
        action: 'DELETE_COURSE',
        summary: `Deleted course ${existing?.name ?? courseId}`,
        amountPaise: 0,
      });
      return;
    }
    try {
      await deleteDoc(doc(db, 'courses', courseId));
      await appendAuditLog({
        entityType: 'COURSE',
        entityId: courseId,
        action: 'DELETE_COURSE',
        summary: `Deleted course ${existing?.name ?? courseId}`,
        amountPaise: 0,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `courses/${courseId}`);
    }
  };

  // Batch CRUD
  const createBatch: InstituteContextValue['createBatch'] = async (rawInput) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can create batches.');
    const parsed = batchInputSchema.parse(rawInput);
    const course = courses.find((c) => c.id === parsed.courseId);
    const teacher = teachers.find((t) => t.id === parsed.teacherId);
    if (!course || !teacher) throw new Error('Selected course or teacher was not found.');

    const id = generateCleanId('bat');
    const viewerUids = getFinanceViewerUids();

    if (isDemoMode) {
      const now = new Date().toISOString();
      const newBatch: Batch = {
        id,
        code: parsed.code,
        name: parsed.name,
        courseId: course.id,
        courseName: course.name,
        teacherId: teacher.id,
        teacherUid: teacher.linkedUserUid,
        teacherName: teacher.fullName,
        scheduleLabel: parsed.scheduleLabel,
        status: 'ACTIVE',
        financeViewerUids: viewerUids,
        createdBy: activeUserProfile!.uid,
        createdAt: now,
        updatedAt: now,
      };
      setDemoData((prev) => ({ ...prev, batches: [newBatch, ...prev.batches] }));
      return;
    }

    try {
      await setDoc(doc(db, 'batches', id), {
        code: parsed.code,
        name: parsed.name,
        courseId: course.id,
        courseName: course.name,
        teacherId: teacher.id,
        teacherUid: teacher.linkedUserUid ?? '',
        teacherName: teacher.fullName,
        scheduleLabel: parsed.scheduleLabel,
        status: 'ACTIVE',
        financeViewerUids: viewerUids,
        createdBy: firebaseUser!.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `batches/${id}`);
    }
  };

  const updateBatch: InstituteContextValue['updateBatch'] = async (batchId, rawInput) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can edit batches.');
    const parsed = batchInputSchema.parse(rawInput);
    const course = courses.find((c) => c.id === parsed.courseId);
    const teacher = teachers.find((t) => t.id === parsed.teacherId);
    if (!course || !teacher) throw new Error('Selected course or teacher was not found.');
    const viewerUids = getFinanceViewerUids();

    if (isDemoMode) {
      const now = new Date().toISOString();
      setDemoData((prev) => ({
        ...prev,
        batches: prev.batches.map((b) =>
          b.id === batchId
            ? {
                ...b,
                code: parsed.code,
                name: parsed.name,
                courseId: course.id,
                courseName: course.name,
                teacherId: teacher.id,
                teacherUid: teacher.linkedUserUid,
                teacherName: teacher.fullName,
                scheduleLabel: parsed.scheduleLabel,
                status: parsed.status,
                financeViewerUids: viewerUids,
                updatedAt: now,
              }
            : b
        ),
        students: prev.students.map((s) =>
          s.batchId === batchId ? { ...s, batchName: parsed.name, updatedAt: now } : s
        ),
      }));
      return;
    }

    try {
      await updateDoc(doc(db, 'batches', batchId), {
        code: parsed.code,
        name: parsed.name,
        courseId: course.id,
        courseName: course.name,
        teacherId: teacher.id,
        teacherUid: teacher.linkedUserUid ?? '',
        teacherName: teacher.fullName,
        scheduleLabel: parsed.scheduleLabel,
        status: parsed.status,
        financeViewerUids: viewerUids,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `batches/${batchId}`);
    }
  };

  const deleteBatch: InstituteContextValue['deleteBatch'] = async (batchId) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can delete batches.');
    const existing = batches.find((b) => b.id === batchId);
    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        batches: prev.batches.filter((b) => b.id !== batchId),
      }));
      await appendAuditLog({
        entityType: 'BATCH',
        entityId: batchId,
        action: 'DELETE_BATCH',
        summary: `Deleted batch ${existing?.name ?? batchId}`,
        amountPaise: 0,
      });
      return;
    }
    try {
      await deleteDoc(doc(db, 'batches', batchId));
      await appendAuditLog({
        entityType: 'BATCH',
        entityId: batchId,
        action: 'DELETE_BATCH',
        summary: `Deleted batch ${existing?.name ?? batchId}`,
        amountPaise: 0,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `batches/${batchId}`);
    }
  };

  // Teacher CRUD
  const createTeacher: InstituteContextValue['createTeacher'] = async (rawInput) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can add teachers.');
    const parsed = teacherInputSchema.parse(rawInput);
    const id = generateCleanId('tch');
    const viewerUids = getFinanceViewerUids();

    if (isDemoMode) {
      const now = new Date().toISOString();
      const newTeacher: Teacher = {
        id,
        teacherCode: parsed.teacherCode,
        fullName: parsed.fullName,
        email: parsed.email,
        phone: parsed.phone,
        specialization: parsed.specialization,
        subjects: parsed.subjects,
        linkedUserUid: parsed.linkedUserUid,
        joinedDate: parsed.joinedDate,
        status: 'ACTIVE',
        financeViewerUids: viewerUids,
        createdBy: activeUserProfile!.uid,
        createdAt: now,
        updatedAt: now,
      };
      setDemoData((prev) => ({ ...prev, teachers: [newTeacher, ...prev.teachers] }));
      await appendAuditLog({
        entityType: 'TEACHER',
        entityId: id,
        action: 'CREATE_TEACHER',
        summary: `Added faculty member ${parsed.fullName} (${parsed.teacherCode})`,
        amountPaise: 0,
      });
      return;
    }

    try {
      await setDoc(doc(db, 'teachers', id), {
        teacherCode: parsed.teacherCode,
        fullName: parsed.fullName,
        email: parsed.email,
        phone: parsed.phone,
        specialization: parsed.specialization,
        subjects: parsed.subjects,
        linkedUserUid: parsed.linkedUserUid,
        joinedDate: parsed.joinedDate,
        status: 'ACTIVE',
        financeViewerUids: viewerUids,
        createdBy: firebaseUser!.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await appendAuditLog({
        entityType: 'TEACHER',
        entityId: id,
        action: 'CREATE_TEACHER',
        summary: `Added faculty member ${parsed.fullName} (${parsed.teacherCode})`,
        amountPaise: 0,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `teachers/${id}`);
    }
  };

  const updateTeacher: InstituteContextValue['updateTeacher'] = async (teacherId, rawInput) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can update teachers.');
    const parsed = teacherInputSchema.parse(rawInput);
    const viewerUids = getFinanceViewerUids();

    if (isDemoMode) {
      const now = new Date().toISOString();
      setDemoData((prev) => ({
        ...prev,
        teachers: prev.teachers.map((t) =>
          t.id === teacherId
            ? {
                ...t,
                ...parsed,
                status: rawInput.status,
                financeViewerUids: viewerUids,
                updatedAt: now,
              }
            : t
        ),
        batches: prev.batches.map((b) =>
          b.teacherId === teacherId
            ? { ...b, teacherName: parsed.fullName, teacherUid: parsed.linkedUserUid, updatedAt: now }
            : b
        ),
        students: prev.students.map((s) =>
          s.assignedTeacherId === teacherId
            ? {
                ...s,
                assignedTeacherName: parsed.fullName,
                assignedTeacherUid: parsed.linkedUserUid,
                updatedAt: now,
              }
            : s
        ),
        agreements: prev.agreements.map((ag) =>
          ag.teacherId === teacherId
            ? { ...ag, teacherName: parsed.fullName, teacherUid: parsed.linkedUserUid, updatedAt: now }
            : ag
        ),
      }));
      return;
    }

    try {
      await updateDoc(doc(db, 'teachers', teacherId), {
        teacherCode: parsed.teacherCode,
        fullName: parsed.fullName,
        email: parsed.email,
        phone: parsed.phone,
        specialization: parsed.specialization,
        subjects: parsed.subjects,
        linkedUserUid: parsed.linkedUserUid,
        joinedDate: parsed.joinedDate,
        status: rawInput.status,
        financeViewerUids: viewerUids,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `teachers/${teacherId}`);
    }
  };

  const deleteTeacher: InstituteContextValue['deleteTeacher'] = async (teacherId) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can delete teachers.');
    const existing = teachers.find((t) => t.id === teacherId);

    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        teachers: prev.teachers.filter((t) => t.id !== teacherId),
        agreements: prev.agreements.filter((a) => a.teacherId !== teacherId),
        allocations: prev.allocations.filter((a) => a.teacherId !== teacherId),
        payouts: prev.payouts.filter((p) => p.teacherId !== teacherId),
      }));
      await appendAuditLog({
        entityType: 'TEACHER',
        entityId: teacherId,
        action: 'DELETE_TEACHER',
        summary: `Deleted faculty member ${existing?.fullName ?? teacherId} and linked compensation records`,
        amountPaise: 0,
      });
      return;
    }

    const refsToDelete: DocumentReference[] = [
      doc(db, 'teachers', teacherId),
      ...agreements.filter((a) => a.teacherId === teacherId).map((a) => doc(db, 'teacher_agreements', a.id)),
      ...allocations
        .filter((a) => a.teacherId === teacherId)
        .map((a) => doc(db, 'teacher_share_allocations', a.id)),
      ...payouts.filter((p) => p.teacherId === teacherId).map((p) => doc(db, 'teacher_payouts', p.id)),
    ];
    await commitBatchDeletes(refsToDelete, `teachers/${teacherId}`);
    await appendAuditLog({
      entityType: 'TEACHER',
      entityId: teacherId,
      action: 'DELETE_TEACHER',
      summary: `Deleted faculty member ${existing?.fullName ?? teacherId}`,
      amountPaise: 0,
    });
  };

  // Teacher Compensation Agreements (Historical preservation via effective dates)
  const saveTeacherAgreement: InstituteContextValue['saveTeacherAgreement'] = async (rawInput) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can modify compensation agreements.');
    const parsed = teacherAgreementInputSchema.parse(rawInput);
    const teacher = teachers.find((t) => t.id === parsed.teacherId);
    if (!teacher) throw new Error('Teacher not found.');

    const id = generateCleanId('agr');
    const fixedMonthlyPaise = toPaise(parsed.fixedMonthlyRupees);
    const shareBasisPoints = Math.round(parsed.sharePercentage * 100);
    const perStudentPaise = toPaise(parsed.perStudentRupees);
    const viewerUids = getFinanceViewerUids();

    // Compute day before new effectiveFrom to close open agreements without altering past reports
    const prevDayDate = new Date(`${parsed.effectiveFrom}T00:00:00Z`);
    prevDayDate.setUTCDate(prevDayDate.getUTCDate() - 1);
    const closedEffectiveTo = prevDayDate.toISOString().slice(0, 10);

    if (isDemoMode) {
      const now = new Date().toISOString();
      setDemoData((prev) => ({
        ...prev,
        agreements: [
          {
            id,
            teacherId: teacher.id,
            teacherUid: teacher.linkedUserUid,
            teacherName: teacher.fullName,
            modelType: parsed.modelType,
            fixedMonthlyPaise,
            shareBasisPoints,
            perStudentPaise,
            effectiveFrom: parsed.effectiveFrom,
            effectiveTo: parsed.effectiveTo,
            notes: parsed.notes,
            status: 'ACTIVE',
            financeViewerUids: viewerUids,
            createdBy: activeUserProfile!.uid,
            createdAt: now,
            updatedAt: now,
          },
          ...prev.agreements.map((ag) =>
            ag.teacherId === teacher.id && ag.status === 'ACTIVE' && ag.effectiveTo === ''
              ? { ...ag, effectiveTo: closedEffectiveTo, status: 'SUPERSEDED' as const, updatedAt: now }
              : ag
          ),
        ],
      }));
      return;
    }

    try {
      const batch = writeBatch(db);
      const openAgreements = agreements.filter(
        (ag) => ag.teacherId === teacher.id && ag.status === 'ACTIVE' && ag.effectiveTo === ''
      );
      for (const oldAg of openAgreements) {
        batch.update(doc(db, 'teacher_agreements', oldAg.id), {
          effectiveTo: closedEffectiveTo,
          status: 'SUPERSEDED',
          updatedAt: serverTimestamp(),
        });
      }

      batch.set(doc(db, 'teacher_agreements', id), {
        teacherId: teacher.id,
        teacherUid: teacher.linkedUserUid ?? '',
        teacherName: teacher.fullName,
        modelType: parsed.modelType,
        fixedMonthlyPaise,
        shareBasisPoints,
        perStudentPaise,
        effectiveFrom: parsed.effectiveFrom,
        effectiveTo: parsed.effectiveTo,
        notes: parsed.notes,
        status: 'ACTIVE',
        financeViewerUids: viewerUids,
        createdBy: firebaseUser!.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      await batch.commit();
      await appendAuditLog({
        entityType: 'TEACHER_AGREEMENT',
        entityId: id,
        action: 'DEFINE_TEACHER_AGREEMENT',
        summary: `Updated compensation terms (${parsed.modelType}) for ${teacher.fullName} effective ${parsed.effectiveFrom}`,
        amountPaise: fixedMonthlyPaise || perStudentPaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, `teacher_agreements/${id}`);
    }
  };

  const updateTeacherAgreement: InstituteContextValue['updateTeacherAgreement'] = async (
    agreementId,
    rawInput
  ) => {
    if (activeRole !== UserRole.ADMIN) {
      throw new Error('Only Administrators can edit compensation agreements.');
    }
    const parsed = teacherAgreementUpdateSchema.parse(rawInput);
    const existing = agreements.find((a) => a.id === agreementId);
    if (!existing) throw new Error('Compensation agreement not found.');
    const teacher = teachers.find((t) => t.id === existing.teacherId);

    const fixedMonthlyPaise = toPaise(parsed.fixedMonthlyRupees);
    const shareBasisPoints = Math.round(parsed.sharePercentage * 100);
    const perStudentPaise = toPaise(parsed.perStudentRupees);
    const viewerUids = getFinanceViewerUids();

    if (isDemoMode) {
      const now = new Date().toISOString();
      setDemoData((prev) => ({
        ...prev,
        agreements: prev.agreements.map((ag) =>
          ag.id === agreementId
            ? {
                ...ag,
                modelType: parsed.modelType,
                fixedMonthlyPaise,
                shareBasisPoints,
                perStudentPaise,
                effectiveFrom: parsed.effectiveFrom,
                effectiveTo: parsed.effectiveTo,
                notes: parsed.notes,
                status: parsed.status,
                teacherUid: teacher?.linkedUserUid ?? ag.teacherUid,
                teacherName: teacher?.fullName ?? ag.teacherName,
                financeViewerUids: viewerUids,
                updatedAt: now,
              }
            : ag
        ),
      }));
      return;
    }

    try {
      await updateDoc(doc(db, 'teacher_agreements', agreementId), {
        modelType: parsed.modelType,
        fixedMonthlyPaise,
        shareBasisPoints,
        perStudentPaise,
        effectiveFrom: parsed.effectiveFrom,
        effectiveTo: parsed.effectiveTo,
        notes: parsed.notes,
        status: parsed.status,
        teacherUid: teacher?.linkedUserUid ?? existing.teacherUid ?? '',
        teacherName: teacher?.fullName ?? existing.teacherName,
        financeViewerUids: viewerUids,
        updatedAt: serverTimestamp(),
      });
      await appendAuditLog({
        entityType: 'TEACHER_AGREEMENT',
        entityId: agreementId,
        action: 'UPDATE_TEACHER_AGREEMENT',
        summary: `Edited agreement terms (${parsed.modelType}) for ${existing.teacherName}`,
        amountPaise: fixedMonthlyPaise || perStudentPaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `teacher_agreements/${agreementId}`);
    }
  };

  const deleteTeacherAgreement: InstituteContextValue['deleteTeacherAgreement'] = async (
    agreementId
  ) => {
    if (activeRole !== UserRole.ADMIN) {
      throw new Error('Only Administrators can delete compensation agreements.');
    }
    const existing = agreements.find((a) => a.id === agreementId);
    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        agreements: prev.agreements.filter((a) => a.id !== agreementId),
      }));
      return;
    }
    try {
      await deleteDoc(doc(db, 'teacher_agreements', agreementId));
      await appendAuditLog({
        entityType: 'TEACHER_AGREEMENT',
        entityId: agreementId,
        action: 'DELETE_TEACHER_AGREEMENT',
        summary: `Deleted compensation agreement for ${existing?.teacherName ?? agreementId}`,
        amountPaise: 0,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `teacher_agreements/${agreementId}`);
    }
  };

  // Monthly Fixed Salary Accrual (Idempotent deterministic IDs)
  const accrueMonthlyFixedSalaries: InstituteContextValue['accrueMonthlyFixedSalaries'] = async (period) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can run salary accruals.');
    const targetDate = `${period}-15`;
    const viewerUids = getFinanceViewerUids();
    let createdCount = 0;

    for (const teacher of teachers.filter((t) => t.status === 'ACTIVE')) {
      const eff = findEffectiveAgreement(agreements, teacher.id, targetDate);
      if (
        !eff ||
        (eff.modelType !== TeacherCompensationModel.FIXED_SALARY &&
          eff.modelType !== TeacherCompensationModel.CUSTOM) ||
        eff.fixedMonthlyPaise <= 0
      ) {
        continue;
      }

      const deterministicId = `alloc_salary_${teacher.id}_${period}`;
      const alreadyExists = allocations.some((a) => a.id === deterministicId);
      if (alreadyExists) continue;

      if (isDemoMode) {
        const now = new Date().toISOString();
        setDemoData((prev) => ({
          ...prev,
          allocations: [
            {
              id: deterministicId,
              agreementId: eff.id,
              modelTypeSnapshot: eff.modelType,
              rateSnapshotLabel: `Fixed monthly retainer (${formatINR(eff.fixedMonthlyPaise)})`,
              teacherId: teacher.id,
              teacherUid: teacher.linkedUserUid,
              teacherName: teacher.fullName,
              paymentId: '',
              invoiceId: '',
              studentId: '',
              studentName: 'Monthly Fixed Retainer',
              billingPeriod: period,
              basisAmountPaise: eff.fixedMonthlyPaise,
              allocatedAmountPaise: eff.fixedMonthlyPaise,
              status: AllocationStatus.ACCRUED,
              payoutId: '',
              financeViewerUids: viewerUids,
              createdBy: activeUserProfile!.uid,
              createdAt: now,
              updatedAt: now,
            },
            ...prev.allocations,
          ],
        }));
        createdCount++;
      } else {
        try {
          await runTransaction(db, async (tx) => {
            const allocRef = doc(db, 'teacher_share_allocations', deterministicId);
            const snap = await tx.get(allocRef);
            if (snap.exists()) return;
            tx.set(allocRef, {
              agreementId: eff.id,
              modelTypeSnapshot: eff.modelType,
              rateSnapshotLabel: `Fixed monthly retainer (${formatINR(eff.fixedMonthlyPaise)})`,
              teacherId: teacher.id,
              teacherUid: teacher.linkedUserUid ?? '',
              teacherName: teacher.fullName,
              paymentId: '',
              invoiceId: '',
              studentId: '',
              studentName: 'Monthly Fixed Retainer',
              billingPeriod: period,
              basisAmountPaise: eff.fixedMonthlyPaise,
              allocatedAmountPaise: eff.fixedMonthlyPaise,
              status: AllocationStatus.ACCRUED,
              payoutId: '',
              financeViewerUids: viewerUids,
              createdBy: firebaseUser!.uid,
              createdAt: serverTimestamp(),
              updatedAt: serverTimestamp(),
            });
            createdCount++;
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.WRITE, `teacher_share_allocations/${deterministicId}`);
        }
      }
    }

    return createdCount;
  };

  const updateTeacherAllocation: InstituteContextValue['updateTeacherAllocation'] = async (
    allocationId,
    rawInput
  ) => {
    if (activeRole === UserRole.TEACHER) {
      throw new Error('Teachers cannot modify share allocation records.');
    }
    const parsed = teacherAllocationUpdateSchema.parse(rawInput);
    const basisAmountPaise = toPaise(parsed.basisAmountRupees);
    const allocatedAmountPaise = toPaise(parsed.allocatedAmountRupees);

    if (isDemoMode) {
      const now = new Date().toISOString();
      setDemoData((prev) => ({
        ...prev,
        allocations: prev.allocations.map((a) =>
          a.id === allocationId
            ? {
                ...a,
                billingPeriod: parsed.billingPeriod,
                basisAmountPaise,
                allocatedAmountPaise,
                rateSnapshotLabel: parsed.rateSnapshotLabel,
                status: parsed.status,
                updatedAt: now,
              }
            : a
        ),
      }));
      return;
    }

    try {
      await updateDoc(doc(db, 'teacher_share_allocations', allocationId), {
        billingPeriod: parsed.billingPeriod,
        basisAmountPaise,
        allocatedAmountPaise,
        rateSnapshotLabel: parsed.rateSnapshotLabel,
        status: parsed.status,
        updatedAt: serverTimestamp(),
      });
      await appendAuditLog({
        entityType: 'TEACHER_SHARE_ALLOCATION',
        entityId: allocationId,
        action: 'UPDATE_SHARE_ALLOCATION',
        summary: `Updated share allocation to ${formatINR(allocatedAmountPaise)} (${parsed.status})`,
        amountPaise: allocatedAmountPaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `teacher_share_allocations/${allocationId}`);
    }
  };

  const deleteTeacherAllocation: InstituteContextValue['deleteTeacherAllocation'] = async (
    allocationId
  ) => {
    if (activeRole === UserRole.TEACHER) {
      throw new Error('Teachers cannot delete share allocation records.');
    }
    const existing = allocations.find((a) => a.id === allocationId);
    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        allocations: prev.allocations.filter((a) => a.id !== allocationId),
      }));
      return;
    }
    try {
      await deleteDoc(doc(db, 'teacher_share_allocations', allocationId));
      await appendAuditLog({
        entityType: 'TEACHER_SHARE_ALLOCATION',
        entityId: allocationId,
        action: 'DELETE_SHARE_ALLOCATION',
        summary: `Deleted share allocation for ${existing?.teacherName ?? allocationId}`,
        amountPaise: existing?.allocatedAmountPaise ?? 0,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `teacher_share_allocations/${allocationId}`);
    }
  };

  // Student CRUD + Multi-course enrollments
  const createStudent: InstituteContextValue['createStudent'] = async (rawInput) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can enroll students.');
    const parsed = studentInputSchema.parse(rawInput);
    const duplicateCode = students.some(
      (s) => s.studentCode.toLowerCase() === parsed.studentCode.toLowerCase()
    );
    if (duplicateCode) {
      throw new Error(`Student ID "${parsed.studentCode}" is already assigned to another student.`);
    }

    const primaryCourse = courses.find((c) => c.id === parsed.primaryCourseId);
    const batch = batches.find((b) => b.id === parsed.batchId);
    const teacher = teachers.find((t) => t.id === parsed.assignedTeacherId);
    if (!primaryCourse || !batch || !teacher) {
      throw new Error('Please select a valid Course, Batch, and Assigned Teacher.');
    }

    const id = generateCleanId('stu');
    const feePaise = toPaise(parsed.monthlyFeeRupees);
    const viewerUids = getFinanceViewerUids();

    if (isDemoMode) {
      const now = new Date().toISOString();
      const newStudent: Student = {
        id,
        studentCode: parsed.studentCode,
        fullName: parsed.fullName,
        primaryCourseId: primaryCourse.id,
        primaryCourseName: primaryCourse.name,
        courseIds: parsed.courseIds,
        batchId: batch.id,
        batchName: batch.name,
        enrollmentDate: parsed.enrollmentDate,
        monthlyFeePaise: feePaise,
        paymentSchedule: parsed.paymentSchedule,
        status: parsed.status,
        guardianName: parsed.guardianName,
        guardianPhone: parsed.guardianPhone,
        assignedTeacherId: teacher.id,
        assignedTeacherUid: teacher.linkedUserUid,
        assignedTeacherName: teacher.fullName,
        financeViewerUids: viewerUids,
        createdBy: activeUserProfile!.uid,
        createdAt: now,
        updatedAt: now,
      };

      const newEnrollments: Enrollment[] = parsed.courseIds.map((cId) => {
        const cObj = courses.find((c) => c.id === cId) ?? primaryCourse;
        return {
          id: `enr_${id}_${cId}`,
          studentId: id,
          studentName: parsed.fullName,
          courseId: cObj.id,
          courseName: cObj.name,
          batchId: batch.id,
          teacherId: teacher.id,
          assignedTeacherUid: teacher.linkedUserUid,
          agreedFeePaise: cId === primaryCourse.id ? feePaise : cObj.defaultMonthlyFeePaise,
          startDate: parsed.enrollmentDate,
          status: 'ACTIVE',
          financeViewerUids: viewerUids,
          createdBy: activeUserProfile!.uid,
          createdAt: now,
          updatedAt: now,
        };
      });

      setDemoData((prev) => ({
        ...prev,
        students: [newStudent, ...prev.students],
        enrollments: [...newEnrollments, ...prev.enrollments],
      }));
      await appendAuditLog({
        entityType: 'STUDENT',
        entityId: id,
        action: 'ENROLL_STUDENT',
        summary: `Enrolled ${parsed.fullName} (${parsed.studentCode}) in ${primaryCourse.name}`,
        amountPaise: feePaise,
      });
      return;
    }

    try {
      await setDoc(doc(db, 'students', id), {
        studentCode: parsed.studentCode,
        fullName: parsed.fullName,
        primaryCourseId: primaryCourse.id,
        primaryCourseName: primaryCourse.name,
        courseIds: parsed.courseIds,
        batchId: batch.id,
        batchName: batch.name,
        enrollmentDate: parsed.enrollmentDate,
        monthlyFeePaise: feePaise,
        paymentSchedule: parsed.paymentSchedule,
        status: parsed.status,
        guardianName: parsed.guardianName,
        guardianPhone: parsed.guardianPhone,
        assignedTeacherId: teacher.id,
        assignedTeacherUid: teacher.linkedUserUid ?? '',
        assignedTeacherName: teacher.fullName,
        financeViewerUids: viewerUids,
        createdBy: firebaseUser!.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      // Create enrollment documents after student exists
      const enrollmentBatch = writeBatch(db);
      for (const cId of parsed.courseIds) {
        const cObj = courses.find((c) => c.id === cId) ?? primaryCourse;
        const enrId = `enr_${id}_${cId}`;
        enrollmentBatch.set(doc(db, 'enrollments', enrId), {
          studentId: id,
          studentName: parsed.fullName,
          courseId: cObj.id,
          courseName: cObj.name,
          batchId: batch.id,
          teacherId: teacher.id,
          assignedTeacherUid: teacher.linkedUserUid ?? '',
          agreedFeePaise: cId === primaryCourse.id ? feePaise : cObj.defaultMonthlyFeePaise,
          startDate: parsed.enrollmentDate,
          status: 'ACTIVE',
          financeViewerUids: viewerUids,
          createdBy: firebaseUser!.uid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      }
      await enrollmentBatch.commit();

      await appendAuditLog({
        entityType: 'STUDENT',
        entityId: id,
        action: 'ENROLL_STUDENT',
        summary: `Enrolled ${parsed.fullName} (${parsed.studentCode}) in ${primaryCourse.name}`,
        amountPaise: feePaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `students/${id}`);
    }
  };

  const updateStudent: InstituteContextValue['updateStudent'] = async (studentId, rawInput) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can edit student records.');
    const parsed = studentInputSchema.parse(rawInput);
    const primaryCourse = courses.find((c) => c.id === parsed.primaryCourseId);
    const batch = batches.find((b) => b.id === parsed.batchId);
    const teacher = teachers.find((t) => t.id === parsed.assignedTeacherId);
    if (!primaryCourse || !batch || !teacher) {
      throw new Error('Valid Course, Batch, and Assigned Teacher are required.');
    }

    const feePaise = toPaise(parsed.monthlyFeeRupees);
    const viewerUids = getFinanceViewerUids();

    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        students: prev.students.map((s) =>
          s.id === studentId
            ? {
                ...s,
                studentCode: parsed.studentCode,
                fullName: parsed.fullName,
                primaryCourseId: primaryCourse.id,
                primaryCourseName: primaryCourse.name,
                courseIds: parsed.courseIds,
                batchId: batch.id,
                batchName: batch.name,
                enrollmentDate: parsed.enrollmentDate,
                monthlyFeePaise: feePaise,
                paymentSchedule: parsed.paymentSchedule,
                status: parsed.status,
                guardianName: parsed.guardianName,
                guardianPhone: parsed.guardianPhone,
                assignedTeacherId: teacher.id,
                assignedTeacherUid: teacher.linkedUserUid,
                assignedTeacherName: teacher.fullName,
                financeViewerUids: viewerUids,
                updatedAt: new Date().toISOString(),
              }
            : s
        ),
      }));
      return;
    }

    try {
      await updateDoc(doc(db, 'students', studentId), {
        studentCode: parsed.studentCode,
        fullName: parsed.fullName,
        primaryCourseId: primaryCourse.id,
        primaryCourseName: primaryCourse.name,
        courseIds: parsed.courseIds,
        batchId: batch.id,
        batchName: batch.name,
        enrollmentDate: parsed.enrollmentDate,
        monthlyFeePaise: feePaise,
        paymentSchedule: parsed.paymentSchedule,
        status: parsed.status,
        guardianName: parsed.guardianName,
        guardianPhone: parsed.guardianPhone,
        assignedTeacherId: teacher.id,
        assignedTeacherUid: teacher.linkedUserUid ?? '',
        assignedTeacherName: teacher.fullName,
        financeViewerUids: viewerUids,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `students/${studentId}`);
    }
  };

  const archiveStudent: InstituteContextValue['archiveStudent'] = async (studentId) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can archive students.');
    const existing = students.find((s) => s.id === studentId);
    if (!existing) return;

    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        students: prev.students.map((s) => (s.id === studentId ? { ...s, status: 'ARCHIVED' } : s)),
      }));
      await appendAuditLog({
        entityType: 'STUDENT',
        entityId: studentId,
        action: 'ARCHIVE_STUDENT',
        summary: `Archived student ${existing.fullName} (${existing.studentCode})`,
        amountPaise: 0,
      });
      return;
    }

    try {
      await updateDoc(doc(db, 'students', studentId), {
        status: 'ARCHIVED',
        updatedAt: serverTimestamp(),
      });
      await appendAuditLog({
        entityType: 'STUDENT',
        entityId: studentId,
        action: 'ARCHIVE_STUDENT',
        summary: `Archived student ${existing.fullName} (${existing.studentCode})`,
        amountPaise: 0,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `students/${studentId}`);
    }
  };

  const deleteStudent: InstituteContextValue['deleteStudent'] = async (studentId) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can delete students.');
    const existing = students.find((s) => s.id === studentId);

    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        students: prev.students.filter((s) => s.id !== studentId),
        enrollments: prev.enrollments.filter((e) => e.studentId !== studentId),
        invoices: prev.invoices.filter((i) => i.studentId !== studentId),
        payments: prev.payments.filter((p) => p.studentId !== studentId),
        allocations: prev.allocations.filter((a) => a.studentId !== studentId),
        reports: prev.reports.filter((r) => r.studentId !== studentId),
      }));
      await appendAuditLog({
        entityType: 'STUDENT',
        entityId: studentId,
        action: 'DELETE_STUDENT',
        summary: `Deleted student ${existing?.fullName ?? studentId} and linked enrollments, invoices, payments & reports`,
        amountPaise: 0,
      });
      return;
    }

    const refsToDelete: DocumentReference[] = [
      doc(db, 'students', studentId),
      ...enrollments.filter((e) => e.studentId === studentId).map((e) => doc(db, 'enrollments', e.id)),
      ...invoices.filter((i) => i.studentId === studentId).map((i) => doc(db, 'invoices', i.id)),
      ...payments.filter((p) => p.studentId === studentId).map((p) => doc(db, 'payments', p.id)),
      ...allocations
        .filter((a) => a.studentId === studentId)
        .map((a) => doc(db, 'teacher_share_allocations', a.id)),
      ...reports.filter((r) => r.studentId === studentId).map((r) => doc(db, 'student_reports', r.id)),
    ];
    await commitBatchDeletes(refsToDelete, `students/${studentId}`);
    await appendAuditLog({
      entityType: 'STUDENT',
      entityId: studentId,
      action: 'DELETE_STUDENT',
      summary: `Deleted student ${existing?.fullName ?? studentId} and linked records`,
      amountPaise: 0,
    });
  };

  // Invoices
  const createInvoice: InstituteContextValue['createInvoice'] = async (rawInput) => {
    if (activeRole === UserRole.TEACHER) throw new Error('Unauthorized to create invoices.');
    const parsed = invoiceCreateSchema.parse(rawInput);
    const student = students.find((s) => s.id === parsed.studentId);
    const course = courses.find((c) => c.id === parsed.courseId);
    if (!student || !course) throw new Error('Selected student or course does not exist.');

    const grossPaise = toPaise(parsed.grossAmountRupees);
    const discountPaise = toPaise(parsed.discountRupees);
    const reconciled = reconcileInvoiceState(grossPaise, discountPaise, 0, parsed.dueDate, getTodayIST());
    const id = generateCleanId('inv');
    const invoiceNumber = `${settings.receiptPrefix}-INV-${Date.now().toString().slice(-6)}`;
    const viewerUids = getFinanceViewerUids();

    if (isDemoMode) {
      const now = new Date().toISOString();
      const inv: Invoice = {
        id,
        invoiceNumber,
        studentId: student.id,
        studentName: student.fullName,
        courseId: course.id,
        courseName: course.name,
        batchId: student.batchId,
        billingPeriod: parsed.billingPeriod,
        grossAmountPaise: grossPaise,
        discountPaise,
        netAmountDuePaise: reconciled.netAmountDuePaise,
        paidAmountPaise: 0,
        balanceDuePaise: reconciled.balanceDuePaise,
        dueDate: parsed.dueDate,
        status: reconciled.status,
        assignedTeacherId: student.assignedTeacherId,
        notes: parsed.notes,
        financeViewerUids: viewerUids,
        createdBy: activeUserProfile!.uid,
        createdAt: now,
        updatedAt: now,
      };
      setDemoData((prev) => ({ ...prev, invoices: [inv, ...prev.invoices] }));
      return;
    }

    try {
      await setDoc(doc(db, 'invoices', id), {
        invoiceNumber,
        studentId: student.id,
        studentName: student.fullName,
        courseId: course.id,
        courseName: course.name,
        batchId: student.batchId,
        billingPeriod: parsed.billingPeriod,
        grossAmountPaise: grossPaise,
        discountPaise,
        netAmountDuePaise: reconciled.netAmountDuePaise,
        paidAmountPaise: 0,
        balanceDuePaise: reconciled.balanceDuePaise,
        dueDate: parsed.dueDate,
        status: reconciled.status,
        assignedTeacherId: student.assignedTeacherId,
        notes: parsed.notes,
        financeViewerUids: viewerUids,
        createdBy: firebaseUser!.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await appendAuditLog({
        entityType: 'INVOICE',
        entityId: id,
        action: 'CREATE_INVOICE',
        summary: `Issued invoice ${invoiceNumber} to ${student.fullName} for ${formatINR(reconciled.netAmountDuePaise)}`,
        amountPaise: reconciled.netAmountDuePaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `invoices/${id}`);
    }
  };

  const updateInvoice: InstituteContextValue['updateInvoice'] = async (invoiceId, rawInput) => {
    if (activeRole === UserRole.TEACHER) throw new Error('Unauthorized to edit invoices.');
    const parsed = invoiceUpdateSchema.parse(rawInput);
    const existing = invoices.find((i) => i.id === invoiceId);
    if (!existing) throw new Error('Invoice not found.');

    const course = courses.find((c) => c.id === parsed.courseId);
    const courseName = course?.name ?? existing.courseName;
    const grossPaise = toPaise(parsed.grossAmountRupees);
    const discountPaise = toPaise(parsed.discountRupees);
    const netAmountDuePaise = grossPaise - discountPaise;

    const verifiedPaidPaise = payments
      .filter((p) => p.invoiceId === invoiceId && p.status === PaymentStatus.COMPLETED)
      .reduce((sum, p) => sum + p.amountPaise, 0);

    if (!parsed.isCancelled && netAmountDuePaise < verifiedPaidPaise) {
      throw new Error(
        `Net invoice amount (${formatINR(netAmountDuePaise)}) cannot be less than already collected payments (${formatINR(verifiedPaidPaise)}). Edit or delete/reverse payments first.`
      );
    }

    const reconciled = parsed.isCancelled
      ? {
          netAmountDuePaise,
          paidAmountPaise: verifiedPaidPaise,
          balanceDuePaise: 0,
          status: InvoiceStatus.CANCELLED,
        }
      : reconcileInvoiceState(grossPaise, discountPaise, verifiedPaidPaise, parsed.dueDate, getTodayIST());

    if (isDemoMode) {
      const now = new Date().toISOString();
      setDemoData((prev) => ({
        ...prev,
        invoices: prev.invoices.map((inv) =>
          inv.id === invoiceId
            ? {
                ...inv,
                courseId: parsed.courseId,
                courseName,
                billingPeriod: parsed.billingPeriod,
                grossAmountPaise: grossPaise,
                discountPaise,
                netAmountDuePaise: reconciled.netAmountDuePaise,
                paidAmountPaise: reconciled.paidAmountPaise,
                balanceDuePaise: reconciled.balanceDuePaise,
                dueDate: parsed.dueDate,
                status: reconciled.status,
                notes: parsed.notes,
                updatedAt: now,
              }
            : inv
        ),
      }));
      await appendAuditLog({
        entityType: 'INVOICE',
        entityId: invoiceId,
        action: 'UPDATE_INVOICE',
        summary: `Updated invoice ${existing.invoiceNumber} (${formatINR(reconciled.netAmountDuePaise)}, ${reconciled.status})`,
        amountPaise: reconciled.netAmountDuePaise,
      });
      return;
    }

    try {
      await updateDoc(doc(db, 'invoices', invoiceId), {
        courseId: parsed.courseId,
        courseName,
        billingPeriod: parsed.billingPeriod,
        grossAmountPaise: grossPaise,
        discountPaise,
        netAmountDuePaise: reconciled.netAmountDuePaise,
        paidAmountPaise: reconciled.paidAmountPaise,
        balanceDuePaise: reconciled.balanceDuePaise,
        dueDate: parsed.dueDate,
        status: reconciled.status,
        notes: parsed.notes,
        updatedAt: serverTimestamp(),
      });
      await appendAuditLog({
        entityType: 'INVOICE',
        entityId: invoiceId,
        action: 'UPDATE_INVOICE',
        summary: `Updated invoice ${existing.invoiceNumber} (${formatINR(reconciled.netAmountDuePaise)}, ${reconciled.status})`,
        amountPaise: reconciled.netAmountDuePaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `invoices/${invoiceId}`);
    }
  };

  const deleteInvoice: InstituteContextValue['deleteInvoice'] = async (invoiceId) => {
    if (activeRole === UserRole.TEACHER) throw new Error('Unauthorized to delete invoices.');
    const existing = invoices.find((i) => i.id === invoiceId);

    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        invoices: prev.invoices.filter((i) => i.id !== invoiceId),
        payments: prev.payments.filter((p) => p.invoiceId !== invoiceId),
        allocations: prev.allocations.filter((a) => a.invoiceId !== invoiceId),
      }));
      await appendAuditLog({
        entityType: 'INVOICE',
        entityId: invoiceId,
        action: 'DELETE_INVOICE',
        summary: `Deleted invoice ${existing?.invoiceNumber ?? invoiceId} and linked receipts/allocations`,
        amountPaise: existing?.netAmountDuePaise ?? 0,
      });
      return;
    }

    const refsToDelete: DocumentReference[] = [
      doc(db, 'invoices', invoiceId),
      ...payments.filter((p) => p.invoiceId === invoiceId).map((p) => doc(db, 'payments', p.id)),
      ...allocations
        .filter((a) => a.invoiceId === invoiceId)
        .map((a) => doc(db, 'teacher_share_allocations', a.id)),
    ];
    await commitBatchDeletes(refsToDelete, `invoices/${invoiceId}`);
    await appendAuditLog({
      entityType: 'INVOICE',
      entityId: invoiceId,
      action: 'DELETE_INVOICE',
      summary: `Deleted invoice ${existing?.invoiceNumber ?? invoiceId}`,
      amountPaise: existing?.netAmountDuePaise ?? 0,
    });
  };

  const generateMonthlyInvoicesForActiveStudents: InstituteContextValue['generateMonthlyInvoicesForActiveStudents'] =
    async (billingPeriod) => {
      if (activeRole === UserRole.TEACHER) throw new Error('Unauthorized.');
      const dueDay = String(settings.defaultDueDay || 10).padStart(2, '0');
      const dueDate = `${billingPeriod}-${dueDay}`;
      let generated = 0;

      for (const stu of students.filter((s) => s.status === 'ACTIVE')) {
        if (stu.enrollmentDate.slice(0, 7) > billingPeriod) continue;
        const alreadyBilled = invoices.some(
          (inv) =>
            inv.studentId === stu.id &&
            inv.courseId === stu.primaryCourseId &&
            inv.billingPeriod === billingPeriod &&
            inv.status !== InvoiceStatus.CANCELLED
        );
        if (alreadyBilled) continue;

        await createInvoice({
          studentId: stu.id,
          courseId: stu.primaryCourseId,
          billingPeriod,
          grossAmountRupees: stu.monthlyFeePaise / 100,
          discountRupees: 0,
          dueDate,
          notes: `Monthly tuition invoice (${billingPeriod})`,
        });
        generated++;
      }

      return generated;
    };

  // Atomic Fee Payment Collection + Idempotency + Server Verification + Teacher Share Allocation
  const recordFeePayment: InstituteContextValue['recordFeePayment'] = async (rawInput) => {
    if (activeRole === UserRole.TEACHER) {
      throw new Error('Teachers are not permitted to record fee collections.');
    }

    const parsed = paymentCreateSchema.parse(rawInput);
    const invoice = invoices.find((i) => i.id === parsed.invoiceId);
    if (!invoice) throw new Error('Target invoice not found.');
    if (invoice.status === InvoiceStatus.CANCELLED) {
      throw new Error('Cannot collect payment against a cancelled invoice.');
    }

    // Client pre-check for duplicate idempotency key
    const duplicate = payments.find((p) => p.idempotencyKey === parsed.idempotencyKey);
    if (duplicate) {
      throw new Error(`Duplicate submission blocked (Idempotency Key: ${parsed.idempotencyKey}).`);
    }

    const amountPaise = toPaise(parsed.amountRupees);
    const effectiveAgreement = invoice.assignedTeacherId
      ? findEffectiveAgreement(agreements, invoice.assignedTeacherId, parsed.paymentDate)
      : null;

    const existingStudentPeriodAllocationsCount = allocations.filter(
      (a) =>
        a.teacherId === invoice.assignedTeacherId &&
        a.studentId === invoice.studentId &&
        a.billingPeriod === invoice.billingPeriod &&
        a.status !== AllocationStatus.REVERSED
    ).length;

    // Authoritative server-side verification & calculation
    const token = await getAuthToken();
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (isDemoMode) {
      headers['X-Demo-Sandbox'] = 'true';
    } else if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const serverResp = await fetch('/api/finance/calculate-payment', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        invoiceId: invoice.id,
        idempotencyKey: parsed.idempotencyKey,
        grossAmountPaise: invoice.grossAmountPaise,
        discountPaise: invoice.discountPaise,
        existingPaidPaise: invoice.paidAmountPaise,
        paymentAmountPaise: amountPaise,
        dueDate: invoice.dueDate,
        paymentDate: parsed.paymentDate,
        agreement: effectiveAgreement
          ? {
              id: effectiveAgreement.id,
              teacherId: effectiveAgreement.teacherId,
              modelType: effectiveAgreement.modelType,
              fixedMonthlyPaise: effectiveAgreement.fixedMonthlyPaise,
              shareBasisPoints: effectiveAgreement.shareBasisPoints,
              perStudentPaise: effectiveAgreement.perStudentPaise,
            }
          : null,
        existingStudentPeriodAllocationsCount,
      }),
    });

    const calcBody = await serverResp.json();
    if (!serverResp.ok) {
      throw new Error(calcBody.error || 'Server financial validation rejected payment.');
    }

    const paymentId: string = calcBody.deterministicPaymentDocId;
    const receiptNumber = `${settings.receiptPrefix}-RCP-${Date.now().toString().slice(-6)}`;
    const viewerUids = getFinanceViewerUids();
    const assignedTeacher = teachers.find((t) => t.id === invoice.assignedTeacherId);

    if (isDemoMode) {
      const now = new Date().toISOString();
      const createdPayment: Payment = {
        id: paymentId,
        receiptNumber,
        idempotencyKey: parsed.idempotencyKey,
        invoiceId: invoice.id,
        studentId: invoice.studentId,
        studentName: invoice.studentName,
        courseId: invoice.courseId,
        courseName: invoice.courseName,
        billingPeriod: invoice.billingPeriod,
        amountPaise,
        paymentMethod: parsed.paymentMethod,
        paymentDate: parsed.paymentDate,
        referenceNote: parsed.referenceNote,
        status: PaymentStatus.COMPLETED,
        reversalReason: '',
        financeViewerUids: viewerUids,
        recordedBy: activeUserProfile!.uid,
        createdAt: now,
        updatedAt: now,
      };

      const localShare = calculatePaymentTeacherShare(
        amountPaise,
        effectiveAgreement,
        existingStudentPeriodAllocationsCount
      );

      setDemoData((prev) => {
        if (prev.payments.some((p) => p.id === paymentId || p.idempotencyKey === parsed.idempotencyKey)) {
          throw new Error('Duplicate payment submission prevented by atomic idempotency lock.');
        }

        const nextInvoices = prev.invoices.map((inv) =>
          inv.id === invoice.id
            ? {
                ...inv,
                paidAmountPaise: calcBody.updatedPaidPaise,
                balanceDuePaise: calcBody.updatedBalancePaise,
                status: calcBody.updatedStatus as InvoiceStatus,
                updatedAt: now,
              }
            : inv
        );

        const nextAllocations = [...prev.allocations];
        if (localShare.shouldCreateAllocation && effectiveAgreement && assignedTeacher) {
          nextAllocations.unshift({
            id: calcBody.deterministicAllocationDocId,
            agreementId: effectiveAgreement.id,
            modelTypeSnapshot: effectiveAgreement.modelType,
            rateSnapshotLabel: localShare.rateSnapshotLabel,
            teacherId: assignedTeacher.id,
            teacherUid: assignedTeacher.linkedUserUid,
            teacherName: assignedTeacher.fullName,
            paymentId,
            invoiceId: invoice.id,
            studentId: invoice.studentId,
            studentName: invoice.studentName,
            billingPeriod: periodFromDate(parsed.paymentDate),
            basisAmountPaise: amountPaise,
            allocatedAmountPaise: localShare.allocatedAmountPaise,
            status: AllocationStatus.ACCRUED,
            payoutId: '',
            financeViewerUids: viewerUids,
            createdBy: activeUserProfile!.uid,
            createdAt: now,
            updatedAt: now,
          });
        }

        return {
          ...prev,
          invoices: nextInvoices,
          payments: [createdPayment, ...prev.payments],
          allocations: nextAllocations,
        };
      });

      await appendAuditLog({
        entityType: 'PAYMENT',
        entityId: paymentId,
        action: 'RECORD_FEE_PAYMENT',
        summary: `Collected ${formatINR(amountPaise)} via ${parsed.paymentMethod} from ${invoice.studentName} (${receiptNumber})`,
        amountPaise,
      });

      return createdPayment;
    }

    // Production Atomic Firestore Transaction
    let committedPayment: Payment | null = null;
    try {
      await runTransaction(db, async (tx) => {
        const invRef = doc(db, 'invoices', invoice.id);
        const payRef = doc(db, 'payments', paymentId);

        const [invSnap, paySnap] = await Promise.all([tx.get(invRef), tx.get(payRef)]);
        if (!invSnap.exists()) {
          throw new Error('Invoice no longer exists.');
        }
        if (paySnap.exists()) {
          throw new Error('Duplicate payment submission prevented by idempotency guard.');
        }

        const liveInv = invSnap.data();
        const currentPaidPaise = liveInv.paidAmountPaise ?? 0;
        const grossPaise = liveInv.grossAmountPaise ?? 0;
        const discountPaise = liveInv.discountPaise ?? 0;
        const netDue = grossPaise - discountPaise;

        if (amountPaise > netDue - currentPaidPaise) {
          throw new Error('Payment amount exceeds remaining invoice balance.');
        }

        const reconciled = reconcileInvoiceState(
          grossPaise,
          discountPaise,
          currentPaidPaise + amountPaise,
          liveInv.dueDate,
          getTodayIST()
        );

        let allocRef = null;
        if (calcBody.shouldCreateAllocation && effectiveAgreement && assignedTeacher && calcBody.deterministicAllocationDocId) {
          allocRef = doc(db, 'teacher_share_allocations', calcBody.deterministicAllocationDocId);
          const allocSnap = await tx.get(allocRef);
          if (allocSnap.exists()) {
            allocRef = null; // Prevent duplicate share allocation
          }
        }

        tx.update(invRef, {
          paidAmountPaise: reconciled.paidAmountPaise,
          balanceDuePaise: reconciled.balanceDuePaise,
          status: reconciled.status,
          updatedAt: serverTimestamp(),
        });

        tx.set(payRef, {
          receiptNumber,
          idempotencyKey: parsed.idempotencyKey,
          invoiceId: invoice.id,
          studentId: invoice.studentId,
          studentName: invoice.studentName,
          courseId: invoice.courseId,
          courseName: invoice.courseName,
          billingPeriod: invoice.billingPeriod,
          amountPaise,
          paymentMethod: parsed.paymentMethod,
          paymentDate: parsed.paymentDate,
          referenceNote: parsed.referenceNote,
          status: PaymentStatus.COMPLETED,
          reversalReason: '',
          financeViewerUids: viewerUids,
          recordedBy: firebaseUser!.uid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        if (allocRef && effectiveAgreement && assignedTeacher) {
          tx.set(allocRef, {
            agreementId: effectiveAgreement.id,
            modelTypeSnapshot: effectiveAgreement.modelType,
            rateSnapshotLabel: calcBody.rateSnapshotLabel,
            teacherId: assignedTeacher.id,
            teacherUid: assignedTeacher.linkedUserUid ?? '',
            teacherName: assignedTeacher.fullName,
            paymentId,
            invoiceId: invoice.id,
            studentId: invoice.studentId,
            studentName: invoice.studentName,
            billingPeriod: periodFromDate(parsed.paymentDate),
            basisAmountPaise: amountPaise,
            allocatedAmountPaise: calcBody.allocatedSharePaise,
            status: AllocationStatus.ACCRUED,
            payoutId: '',
            financeViewerUids: viewerUids,
            createdBy: firebaseUser!.uid,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }

        const nowISO = new Date().toISOString();
        committedPayment = {
          id: paymentId,
          receiptNumber,
          idempotencyKey: parsed.idempotencyKey,
          invoiceId: invoice.id,
          studentId: invoice.studentId,
          studentName: invoice.studentName,
          courseId: invoice.courseId,
          courseName: invoice.courseName,
          billingPeriod: invoice.billingPeriod,
          amountPaise,
          paymentMethod: parsed.paymentMethod,
          paymentDate: parsed.paymentDate,
          referenceNote: parsed.referenceNote,
          status: PaymentStatus.COMPLETED,
          reversalReason: '',
          financeViewerUids: viewerUids,
          recordedBy: firebaseUser!.uid,
          createdAt: nowISO,
          updatedAt: nowISO,
        };
      });

      await appendAuditLog({
        entityType: 'PAYMENT',
        entityId: paymentId,
        action: 'RECORD_FEE_PAYMENT',
        summary: `Collected ${formatINR(amountPaise)} via ${parsed.paymentMethod} from ${invoice.studentName} (${receiptNumber})`,
        amountPaise,
      });

      return committedPayment!;
    } catch (err) {
      if (err instanceof Error && err.message.includes('Duplicate payment')) {
        throw err;
      }
      handleFirestoreError(err, OperationType.WRITE, `payments/${paymentId}`);
    }
  };

  // Payment Reversal (Never permanently deletes history)
  const reverseFeePayment: InstituteContextValue['reverseFeePayment'] = async (paymentId, reason) => {
    if (activeRole === UserRole.TEACHER) throw new Error('Unauthorized.');
    const cleanReason = reason.trim().slice(0, 200) || 'Administrative payment reversal';
    const payment = payments.find((p) => p.id === paymentId);
    if (!payment || payment.status === PaymentStatus.REVERSED) {
      throw new Error('Payment is already reversed or not found.');
    }

    if (isDemoMode) {
      const now = new Date().toISOString();
      setDemoData((prev) => {
        const inv = prev.invoices.find((i) => i.id === payment.invoiceId);
        const newPaid = inv ? Math.max(0, inv.paidAmountPaise - payment.amountPaise) : 0;
        const reconciled = inv
          ? reconcileInvoiceState(inv.grossAmountPaise, inv.discountPaise, newPaid, inv.dueDate, getTodayIST())
          : null;

        return {
          ...prev,
          payments: prev.payments.map((p) =>
            p.id === paymentId
              ? { ...p, status: PaymentStatus.REVERSED, reversalReason: cleanReason, updatedAt: now }
              : p
          ),
          invoices: prev.invoices.map((i) =>
            i.id === payment.invoiceId && reconciled
              ? {
                  ...i,
                  paidAmountPaise: reconciled.paidAmountPaise,
                  balanceDuePaise: reconciled.balanceDuePaise,
                  status: reconciled.status,
                  updatedAt: now,
                }
              : i
          ),
          allocations: prev.allocations.map((a) =>
            a.paymentId === paymentId ? { ...a, status: AllocationStatus.REVERSED, updatedAt: now } : a
          ),
        };
      });

      await appendAuditLog({
        entityType: 'PAYMENT',
        entityId: paymentId,
        action: 'REVERSE_FEE_PAYMENT',
        summary: `Reversed receipt ${payment.receiptNumber} (${formatINR(payment.amountPaise)}): ${cleanReason}`,
        amountPaise: payment.amountPaise,
      });
      return;
    }

    try {
      const linkedAllocation = allocations.find(
        (a) => a.paymentId === paymentId && a.status !== AllocationStatus.REVERSED
      );

      await runTransaction(db, async (tx) => {
        const payRef = doc(db, 'payments', paymentId);
        const invRef = doc(db, 'invoices', payment.invoiceId);
        const [paySnap, invSnap] = await Promise.all([tx.get(payRef), tx.get(invRef)]);

        if (!paySnap.exists() || paySnap.data().status === PaymentStatus.REVERSED) {
          throw new Error('Payment already reversed.');
        }

        tx.update(payRef, {
          status: PaymentStatus.REVERSED,
          reversalReason: cleanReason,
          updatedAt: serverTimestamp(),
        });

        if (invSnap.exists()) {
          const invData = invSnap.data();
          const updatedPaid = Math.max(0, (invData.paidAmountPaise ?? 0) - payment.amountPaise);
          const reconciled = reconcileInvoiceState(
            invData.grossAmountPaise ?? 0,
            invData.discountPaise ?? 0,
            updatedPaid,
            invData.dueDate,
            getTodayIST()
          );
          tx.update(invRef, {
            paidAmountPaise: reconciled.paidAmountPaise,
            balanceDuePaise: reconciled.balanceDuePaise,
            status: reconciled.status,
            updatedAt: serverTimestamp(),
          });
        }

        if (linkedAllocation) {
          tx.update(doc(db, 'teacher_share_allocations', linkedAllocation.id), {
            status: AllocationStatus.REVERSED,
            updatedAt: serverTimestamp(),
          });
        }
      });

      await appendAuditLog({
        entityType: 'PAYMENT',
        entityId: paymentId,
        action: 'REVERSE_FEE_PAYMENT',
        summary: `Reversed receipt ${payment.receiptNumber} (${formatINR(payment.amountPaise)}): ${cleanReason}`,
        amountPaise: payment.amountPaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `payments/${paymentId}`);
    }
  };

  // Atomic Payment Edit (recalculates parent invoice & linked teacher share allocation)
  const updateFeePayment: InstituteContextValue['updateFeePayment'] = async (paymentId, rawInput) => {
    if (activeRole === UserRole.TEACHER) throw new Error('Unauthorized to edit payments.');
    const parsed = paymentUpdateSchema.parse({
      ...rawInput,
      reversalReason: rawInput.reversalReason ?? '',
    });
    const payment = payments.find((p) => p.id === paymentId);
    if (!payment) throw new Error('Payment record not found.');

    const invoice = invoices.find((i) => i.id === payment.invoiceId);
    const newAmountPaise = toPaise(parsed.amountRupees);
    const otherCompletedPaidPaise = payments
      .filter(
        (p) =>
          p.invoiceId === payment.invoiceId &&
          p.id !== paymentId &&
          p.status === PaymentStatus.COMPLETED
      )
      .reduce((sum, p) => sum + p.amountPaise, 0);

    const newTotalPaidPaise =
      otherCompletedPaidPaise + (parsed.status === PaymentStatus.COMPLETED ? newAmountPaise : 0);

    if (invoice && invoice.status !== InvoiceStatus.CANCELLED && newTotalPaidPaise > invoice.netAmountDuePaise) {
      throw new Error(
        `Edited payment exceeds remaining invoice net due (${formatINR(invoice.netAmountDuePaise - otherCompletedPaidPaise)}).`
      );
    }

    const effectiveAgreement = invoice?.assignedTeacherId
      ? findEffectiveAgreement(agreements, invoice.assignedTeacherId, parsed.paymentDate)
      : null;
    const otherStudentPeriodAllocCount = invoice
      ? allocations.filter(
          (a) =>
            a.paymentId !== paymentId &&
            a.teacherId === invoice.assignedTeacherId &&
            a.studentId === invoice.studentId &&
            a.billingPeriod === invoice.billingPeriod &&
            a.status !== AllocationStatus.REVERSED
        ).length
      : 0;
    const shareCalc = calculatePaymentTeacherShare(
      newAmountPaise,
      effectiveAgreement,
      otherStudentPeriodAllocCount
    );

    if (isDemoMode) {
      const now = new Date().toISOString();
      setDemoData((prev) => {
        const inv = prev.invoices.find((i) => i.id === payment.invoiceId);
        const reconciled =
          inv && inv.status !== InvoiceStatus.CANCELLED
            ? reconcileInvoiceState(
                inv.grossAmountPaise,
                inv.discountPaise,
                newTotalPaidPaise,
                inv.dueDate,
                getTodayIST()
              )
            : null;

        return {
          ...prev,
          payments: prev.payments.map((p) =>
            p.id === paymentId
              ? {
                  ...p,
                  amountPaise: newAmountPaise,
                  paymentMethod: parsed.paymentMethod,
                  paymentDate: parsed.paymentDate,
                  referenceNote: parsed.referenceNote,
                  status: parsed.status,
                  reversalReason:
                    parsed.status === PaymentStatus.REVERSED
                      ? parsed.reversalReason || 'Administrative reversal'
                      : '',
                  updatedAt: now,
                }
              : p
          ),
          invoices: prev.invoices.map((i) =>
            i.id === payment.invoiceId && reconciled
              ? {
                  ...i,
                  paidAmountPaise: reconciled.paidAmountPaise,
                  balanceDuePaise: reconciled.balanceDuePaise,
                  status: reconciled.status,
                  updatedAt: now,
                }
              : i
          ),
          allocations: prev.allocations.map((a) => {
            if (a.paymentId !== paymentId) return a;
            if (parsed.status === PaymentStatus.REVERSED) {
              return { ...a, status: AllocationStatus.REVERSED, updatedAt: now };
            }
            return {
              ...a,
              billingPeriod: periodFromDate(parsed.paymentDate),
              basisAmountPaise: newAmountPaise,
              allocatedAmountPaise: effectiveAgreement
                ? shareCalc.allocatedAmountPaise
                : a.allocatedAmountPaise,
              rateSnapshotLabel: effectiveAgreement
                ? shareCalc.rateSnapshotLabel
                : a.rateSnapshotLabel,
              status: a.status === AllocationStatus.REVERSED ? AllocationStatus.ACCRUED : a.status,
              updatedAt: now,
            };
          }),
        };
      });

      await appendAuditLog({
        entityType: 'PAYMENT',
        entityId: paymentId,
        action: 'UPDATE_FEE_PAYMENT',
        summary: `Updated receipt ${payment.receiptNumber} to ${formatINR(newAmountPaise)} (${parsed.status})`,
        amountPaise: newAmountPaise,
      });
      return;
    }

    try {
      const linkedAllocations = allocations.filter((a) => a.paymentId === paymentId);

      await runTransaction(db, async (tx) => {
        const payRef = doc(db, 'payments', paymentId);
        const invRef = doc(db, 'invoices', payment.invoiceId);
        const [paySnap, invSnap] = await Promise.all([tx.get(payRef), tx.get(invRef)]);
        if (!paySnap.exists()) throw new Error('Payment no longer exists.');

        tx.update(payRef, {
          amountPaise: newAmountPaise,
          paymentMethod: parsed.paymentMethod,
          paymentDate: parsed.paymentDate,
          referenceNote: parsed.referenceNote,
          status: parsed.status,
          reversalReason:
            parsed.status === PaymentStatus.REVERSED
              ? parsed.reversalReason || 'Administrative reversal'
              : '',
          updatedAt: serverTimestamp(),
        });

        if (invSnap.exists()) {
          const invData = invSnap.data();
          if (invData.status !== InvoiceStatus.CANCELLED) {
            const reconciled = reconcileInvoiceState(
              invData.grossAmountPaise ?? 0,
              invData.discountPaise ?? 0,
              newTotalPaidPaise,
              invData.dueDate,
              getTodayIST()
            );
            tx.update(invRef, {
              paidAmountPaise: reconciled.paidAmountPaise,
              balanceDuePaise: reconciled.balanceDuePaise,
              status: reconciled.status,
              updatedAt: serverTimestamp(),
            });
          }
        }

        for (const alloc of linkedAllocations) {
          const allocRef = doc(db, 'teacher_share_allocations', alloc.id);
          if (parsed.status === PaymentStatus.REVERSED) {
            tx.update(allocRef, {
              status: AllocationStatus.REVERSED,
              updatedAt: serverTimestamp(),
            });
          } else {
            tx.update(allocRef, {
              billingPeriod: periodFromDate(parsed.paymentDate),
              basisAmountPaise: newAmountPaise,
              allocatedAmountPaise: effectiveAgreement
                ? shareCalc.allocatedAmountPaise
                : alloc.allocatedAmountPaise,
              rateSnapshotLabel: effectiveAgreement
                ? shareCalc.rateSnapshotLabel
                : alloc.rateSnapshotLabel,
              status:
                alloc.status === AllocationStatus.REVERSED ? AllocationStatus.ACCRUED : alloc.status,
              updatedAt: serverTimestamp(),
            });
          }
        }
      });

      await appendAuditLog({
        entityType: 'PAYMENT',
        entityId: paymentId,
        action: 'UPDATE_FEE_PAYMENT',
        summary: `Updated receipt ${payment.receiptNumber} to ${formatINR(newAmountPaise)} (${parsed.status})`,
        amountPaise: newAmountPaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `payments/${paymentId}`);
    }
  };

  // Atomic Payment Delete (restores parent invoice balance & deletes linked share allocations)
  const deleteFeePayment: InstituteContextValue['deleteFeePayment'] = async (paymentId) => {
    if (activeRole === UserRole.TEACHER) throw new Error('Unauthorized to delete payments.');
    const payment = payments.find((p) => p.id === paymentId);
    if (!payment) return;

    const remainingCompletedPaidPaise = payments
      .filter(
        (p) =>
          p.invoiceId === payment.invoiceId &&
          p.id !== paymentId &&
          p.status === PaymentStatus.COMPLETED
      )
      .reduce((sum, p) => sum + p.amountPaise, 0);

    if (isDemoMode) {
      const now = new Date().toISOString();
      setDemoData((prev) => {
        const inv = prev.invoices.find((i) => i.id === payment.invoiceId);
        const reconciled =
          inv && inv.status !== InvoiceStatus.CANCELLED
            ? reconcileInvoiceState(
                inv.grossAmountPaise,
                inv.discountPaise,
                remainingCompletedPaidPaise,
                inv.dueDate,
                getTodayIST()
              )
            : null;

        return {
          ...prev,
          payments: prev.payments.filter((p) => p.id !== paymentId),
          allocations: prev.allocations.filter((a) => a.paymentId !== paymentId),
          invoices: prev.invoices.map((i) =>
            i.id === payment.invoiceId && reconciled
              ? {
                  ...i,
                  paidAmountPaise: reconciled.paidAmountPaise,
                  balanceDuePaise: reconciled.balanceDuePaise,
                  status: reconciled.status,
                  updatedAt: now,
                }
              : i
          ),
        };
      });

      await appendAuditLog({
        entityType: 'PAYMENT',
        entityId: paymentId,
        action: 'DELETE_FEE_PAYMENT',
        summary: `Deleted receipt ${payment.receiptNumber} (${formatINR(payment.amountPaise)}) and reconciled invoice`,
        amountPaise: payment.amountPaise,
      });
      return;
    }

    try {
      const linkedAllocations = allocations.filter((a) => a.paymentId === paymentId);
      await runTransaction(db, async (tx) => {
        const invRef = doc(db, 'invoices', payment.invoiceId);
        const invSnap = await tx.get(invRef);
        tx.delete(doc(db, 'payments', paymentId));
        for (const alloc of linkedAllocations) {
          tx.delete(doc(db, 'teacher_share_allocations', alloc.id));
        }
        if (invSnap.exists()) {
          const invData = invSnap.data();
          if (invData.status !== InvoiceStatus.CANCELLED) {
            const reconciled = reconcileInvoiceState(
              invData.grossAmountPaise ?? 0,
              invData.discountPaise ?? 0,
              remainingCompletedPaidPaise,
              invData.dueDate,
              getTodayIST()
            );
            tx.update(invRef, {
              paidAmountPaise: reconciled.paidAmountPaise,
              balanceDuePaise: reconciled.balanceDuePaise,
              status: reconciled.status,
              updatedAt: serverTimestamp(),
            });
          }
        }
      });

      await appendAuditLog({
        entityType: 'PAYMENT',
        entityId: paymentId,
        action: 'DELETE_FEE_PAYMENT',
        summary: `Deleted receipt ${payment.receiptNumber} (${formatINR(payment.amountPaise)})`,
        amountPaise: payment.amountPaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `payments/${paymentId}`);
    }
  };

  // Teacher Payout Disbursement + Edit + Delete
  const recordTeacherPayout: InstituteContextValue['recordTeacherPayout'] = async (rawInput) => {
    if (activeRole === UserRole.TEACHER) {
      throw new Error('Teachers cannot disburse payouts.');
    }
    const parsed = teacherPayoutInputSchema.parse(rawInput);
    const teacher = teachers.find((t) => t.id === parsed.teacherId);
    if (!teacher) throw new Error('Teacher not found.');

    const amountPaise = toPaise(parsed.amountRupees);
    const id = generateCleanId('po');
    const payoutNumber = `${settings.receiptPrefix}-PAY-${Date.now().toString().slice(-6)}`;
    const viewerUids = getFinanceViewerUids();

    if (isDemoMode) {
      const now = new Date().toISOString();
      const newPayout: TeacherPayout = {
        id,
        payoutNumber,
        teacherId: teacher.id,
        teacherUid: teacher.linkedUserUid,
        teacherName: teacher.fullName,
        billingPeriod: parsed.billingPeriod,
        amountPaise,
        paymentMethod: parsed.paymentMethod,
        payoutDate: parsed.payoutDate,
        referenceNote: parsed.referenceNote,
        status: PayoutStatus.PAID,
        financeViewerUids: viewerUids,
        createdBy: activeUserProfile!.uid,
        createdAt: now,
        updatedAt: now,
      };
      setDemoData((prev) => ({
        ...prev,
        payouts: [newPayout, ...prev.payouts],
      }));
      await appendAuditLog({
        entityType: 'TEACHER_PAYOUT',
        entityId: id,
        action: 'DISBURSE_TEACHER_PAYOUT',
        summary: `Disbursed ${formatINR(amountPaise)} to ${teacher.fullName} for ${parsed.billingPeriod}`,
        amountPaise,
      });
      return;
    }

    try {
      await setDoc(doc(db, 'teacher_payouts', id), {
        payoutNumber,
        teacherId: teacher.id,
        teacherUid: teacher.linkedUserUid ?? '',
        teacherName: teacher.fullName,
        billingPeriod: parsed.billingPeriod,
        amountPaise,
        paymentMethod: parsed.paymentMethod,
        payoutDate: parsed.payoutDate,
        referenceNote: parsed.referenceNote,
        status: PayoutStatus.PAID,
        financeViewerUids: viewerUids,
        createdBy: firebaseUser!.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await appendAuditLog({
        entityType: 'TEACHER_PAYOUT',
        entityId: id,
        action: 'DISBURSE_TEACHER_PAYOUT',
        summary: `Disbursed ${formatINR(amountPaise)} to ${teacher.fullName} for ${parsed.billingPeriod}`,
        amountPaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `teacher_payouts/${id}`);
    }
  };

  const updateTeacherPayout: InstituteContextValue['updateTeacherPayout'] = async (
    payoutId,
    rawInput
  ) => {
    if (activeRole === UserRole.TEACHER) throw new Error('Unauthorized to edit payouts.');
    const parsed = teacherPayoutUpdateSchema.parse(rawInput);
    const existing = payouts.find((p) => p.id === payoutId);
    if (!existing) throw new Error('Payout record not found.');
    const teacher = teachers.find((t) => t.id === parsed.teacherId);
    if (!teacher) throw new Error('Teacher not found.');

    const amountPaise = toPaise(parsed.amountRupees);

    if (isDemoMode) {
      const now = new Date().toISOString();
      setDemoData((prev) => ({
        ...prev,
        payouts: prev.payouts.map((po) =>
          po.id === payoutId
            ? {
                ...po,
                teacherId: teacher.id,
                teacherUid: teacher.linkedUserUid,
                teacherName: teacher.fullName,
                billingPeriod: parsed.billingPeriod,
                amountPaise,
                paymentMethod: parsed.paymentMethod,
                payoutDate: parsed.payoutDate,
                referenceNote: parsed.referenceNote,
                status: parsed.status,
                updatedAt: now,
              }
            : po
        ),
      }));
      await appendAuditLog({
        entityType: 'TEACHER_PAYOUT',
        entityId: payoutId,
        action: 'UPDATE_TEACHER_PAYOUT',
        summary: `Updated payout ${existing.payoutNumber} (${formatINR(amountPaise)}, ${parsed.status})`,
        amountPaise,
      });
      return;
    }

    try {
      const updatePayload: Record<string, unknown> = {
        billingPeriod: parsed.billingPeriod,
        amountPaise,
        paymentMethod: parsed.paymentMethod,
        payoutDate: parsed.payoutDate,
        referenceNote: parsed.referenceNote,
        status: parsed.status,
        updatedAt: serverTimestamp(),
      };
      if (teacher.id !== existing.teacherId && activeRole === UserRole.ADMIN) {
        updatePayload.teacherId = teacher.id;
        updatePayload.teacherUid = teacher.linkedUserUid ?? '';
        updatePayload.teacherName = teacher.fullName;
      }

      await updateDoc(doc(db, 'teacher_payouts', payoutId), updatePayload);
      await appendAuditLog({
        entityType: 'TEACHER_PAYOUT',
        entityId: payoutId,
        action: 'UPDATE_TEACHER_PAYOUT',
        summary: `Updated payout ${existing.payoutNumber} (${formatINR(amountPaise)}, ${parsed.status})`,
        amountPaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `teacher_payouts/${payoutId}`);
    }
  };

  const deleteTeacherPayout: InstituteContextValue['deleteTeacherPayout'] = async (payoutId) => {
    if (activeRole === UserRole.TEACHER) throw new Error('Unauthorized to delete payouts.');
    const existing = payouts.find((p) => p.id === payoutId);
    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        payouts: prev.payouts.filter((p) => p.id !== payoutId),
      }));
      await appendAuditLog({
        entityType: 'TEACHER_PAYOUT',
        entityId: payoutId,
        action: 'DELETE_TEACHER_PAYOUT',
        summary: `Deleted payout ${existing?.payoutNumber ?? payoutId}`,
        amountPaise: existing?.amountPaise ?? 0,
      });
      return;
    }
    try {
      await deleteDoc(doc(db, 'teacher_payouts', payoutId));
      await appendAuditLog({
        entityType: 'TEACHER_PAYOUT',
        entityId: payoutId,
        action: 'DELETE_TEACHER_PAYOUT',
        summary: `Deleted payout ${existing?.payoutNumber ?? payoutId}`,
        amountPaise: existing?.amountPaise ?? 0,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `teacher_payouts/${payoutId}`);
    }
  };

  // Expenses
  const createExpense: InstituteContextValue['createExpense'] = async (rawInput) => {
    if (activeRole === UserRole.TEACHER) throw new Error('Unauthorized.');
    const parsed = expenseInputSchema.parse(rawInput);
    const amountPaise = toPaise(parsed.amountRupees);
    const billingPeriod = periodFromDate(parsed.expenseDate);
    const id = generateCleanId('exp');
    const viewerUids = getFinanceViewerUids();

    if (isDemoMode) {
      const now = new Date().toISOString();
      const newExp: Expense = {
        id,
        title: parsed.title,
        category: parsed.category,
        amountPaise,
        expenseDate: parsed.expenseDate,
        billingPeriod,
        paymentMethod: parsed.paymentMethod,
        vendorName: parsed.vendorName,
        notes: parsed.notes,
        status: 'RECORDED',
        financeViewerUids: viewerUids,
        createdBy: activeUserProfile!.uid,
        createdAt: now,
        updatedAt: now,
      };
      setDemoData((prev) => ({ ...prev, expenses: [newExp, ...prev.expenses] }));
      await appendAuditLog({
        entityType: 'EXPENSE',
        entityId: id,
        action: 'RECORD_EXPENSE',
        summary: `Recorded expense "${parsed.title}" (${parsed.category}): ${formatINR(amountPaise)}`,
        amountPaise,
      });
      return;
    }

    try {
      await setDoc(doc(db, 'expenses', id), {
        title: parsed.title,
        category: parsed.category,
        amountPaise,
        expenseDate: parsed.expenseDate,
        billingPeriod,
        paymentMethod: parsed.paymentMethod,
        vendorName: parsed.vendorName,
        notes: parsed.notes,
        status: 'RECORDED',
        financeViewerUids: viewerUids,
        createdBy: firebaseUser!.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await appendAuditLog({
        entityType: 'EXPENSE',
        entityId: id,
        action: 'RECORD_EXPENSE',
        summary: `Recorded expense "${parsed.title}" (${parsed.category}): ${formatINR(amountPaise)}`,
        amountPaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `expenses/${id}`);
    }
  };

  const updateExpense: InstituteContextValue['updateExpense'] = async (expenseId, rawInput) => {
    if (activeRole === UserRole.TEACHER) throw new Error('Unauthorized.');
    const parsed = expenseUpdateSchema.parse(rawInput);
    const amountPaise = toPaise(parsed.amountRupees);
    const billingPeriod = periodFromDate(parsed.expenseDate);

    if (isDemoMode) {
      const now = new Date().toISOString();
      setDemoData((prev) => ({
        ...prev,
        expenses: prev.expenses.map((ex) =>
          ex.id === expenseId
            ? {
                ...ex,
                title: parsed.title,
                category: parsed.category,
                amountPaise,
                expenseDate: parsed.expenseDate,
                billingPeriod,
                paymentMethod: parsed.paymentMethod,
                vendorName: parsed.vendorName,
                notes: parsed.notes,
                status: parsed.status,
                updatedAt: now,
              }
            : ex
        ),
      }));
      await appendAuditLog({
        entityType: 'EXPENSE',
        entityId: expenseId,
        action: 'UPDATE_EXPENSE',
        summary: `Updated expense "${parsed.title}" (${formatINR(amountPaise)}, ${parsed.status})`,
        amountPaise,
      });
      return;
    }

    try {
      await updateDoc(doc(db, 'expenses', expenseId), {
        title: parsed.title,
        category: parsed.category,
        amountPaise,
        expenseDate: parsed.expenseDate,
        billingPeriod,
        paymentMethod: parsed.paymentMethod,
        vendorName: parsed.vendorName,
        notes: parsed.notes,
        status: parsed.status,
        updatedAt: serverTimestamp(),
      });
      await appendAuditLog({
        entityType: 'EXPENSE',
        entityId: expenseId,
        action: 'UPDATE_EXPENSE',
        summary: `Updated expense "${parsed.title}" (${formatINR(amountPaise)}, ${parsed.status})`,
        amountPaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `expenses/${expenseId}`);
    }
  };

  const reverseExpense: InstituteContextValue['reverseExpense'] = async (expenseId, reason) => {
    if (activeRole === UserRole.TEACHER) throw new Error('Unauthorized.');
    const existing = expenses.find((e) => e.id === expenseId);
    if (!existing) return;

    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        expenses: prev.expenses.map((e) =>
          e.id === expenseId ? { ...e, status: 'REVERSED', notes: `${e.notes} [Reversed: ${reason}]`.slice(0, 240) } : e
        ),
      }));
      return;
    }

    try {
      await updateDoc(doc(db, 'expenses', expenseId), {
        status: 'REVERSED',
        notes: `${existing.notes} [Reversed: ${reason}]`.trim().slice(0, 240),
        updatedAt: serverTimestamp(),
      });
      await appendAuditLog({
        entityType: 'EXPENSE',
        entityId: expenseId,
        action: 'REVERSE_EXPENSE',
        summary: `Reversed expense "${existing.title}" (${formatINR(existing.amountPaise)})`,
        amountPaise: existing.amountPaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `expenses/${expenseId}`);
    }
  };

  const deleteExpense: InstituteContextValue['deleteExpense'] = async (expenseId) => {
    if (activeRole === UserRole.TEACHER) throw new Error('Unauthorized.');
    const existing = expenses.find((e) => e.id === expenseId);
    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        expenses: prev.expenses.filter((e) => e.id !== expenseId),
      }));
      await appendAuditLog({
        entityType: 'EXPENSE',
        entityId: expenseId,
        action: 'DELETE_EXPENSE',
        summary: `Deleted expense "${existing?.title ?? expenseId}"`,
        amountPaise: existing?.amountPaise ?? 0,
      });
      return;
    }

    try {
      await deleteDoc(doc(db, 'expenses', expenseId));
      await appendAuditLog({
        entityType: 'EXPENSE',
        entityId: expenseId,
        action: 'DELETE_EXPENSE',
        summary: `Deleted expense "${existing?.title ?? expenseId}"`,
        amountPaise: existing?.amountPaise ?? 0,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `expenses/${expenseId}`);
    }
  };

  // Student Performance Reports
  const submitStudentReport: InstituteContextValue['submitStudentReport'] = async (rawInput) => {
    if (activeRole === UserRole.ACCOUNTANT) {
      throw new Error('Accountants cannot submit academic performance reports.');
    }
    const parsed = studentReportInputSchema.parse(rawInput);
    const student = students.find((s) => s.id === parsed.studentId);
    if (!student) throw new Error('Assigned student not found.');

    if (
      activeRole === UserRole.TEACHER &&
      student.assignedTeacherUid !== activeUserProfile?.uid &&
      student.assignedTeacherId !== activeUserProfile?.teacherId
    ) {
      throw new Error('Teachers can only submit reports for students assigned to them.');
    }

    const id = generateCleanId('rep');
    const viewerUids = getFinanceViewerUids();

    if (isDemoMode) {
      const now = new Date().toISOString();
      const rep: StudentReport = {
        id,
        studentId: student.id,
        studentName: student.fullName,
        courseId: student.primaryCourseId,
        courseName: student.primaryCourseName,
        teacherId: student.assignedTeacherId,
        teacherUid: student.assignedTeacherUid || activeUserProfile!.uid,
        teacherName: student.assignedTeacherName,
        reportingPeriod: parsed.reportingPeriod,
        subject: parsed.subject,
        attendancePercent: parsed.attendancePercent,
        testMarks: parsed.testMarks,
        maxMarks: parsed.maxMarks,
        academicProgress: parsed.academicProgress,
        strengths: parsed.strengths,
        areasForImprovement: parsed.areasForImprovement,
        teacherComments: parsed.teacherComments,
        submissionDate: parsed.submissionDate,
        financeViewerUids: viewerUids,
        createdBy: activeUserProfile!.uid,
        createdAt: now,
        updatedAt: now,
      };
      setDemoData((prev) => ({ ...prev, reports: [rep, ...prev.reports] }));
      return;
    }

    try {
      await setDoc(doc(db, 'student_reports', id), {
        studentId: student.id,
        studentName: student.fullName,
        courseId: student.primaryCourseId,
        courseName: student.primaryCourseName,
        teacherId: student.assignedTeacherId,
        teacherUid:
          activeRole === UserRole.TEACHER ? firebaseUser!.uid : student.assignedTeacherUid ?? '',
        teacherName: student.assignedTeacherName,
        reportingPeriod: parsed.reportingPeriod,
        subject: parsed.subject,
        attendancePercent: parsed.attendancePercent,
        testMarks: parsed.testMarks,
        maxMarks: parsed.maxMarks,
        academicProgress: parsed.academicProgress,
        strengths: parsed.strengths,
        areasForImprovement: parsed.areasForImprovement,
        teacherComments: parsed.teacherComments,
        submissionDate: parsed.submissionDate,
        financeViewerUids: viewerUids,
        createdBy: firebaseUser!.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `student_reports/${id}`);
    }
  };

  const updateStudentReport: InstituteContextValue['updateStudentReport'] = async (reportId, rawInput) => {
    if (activeRole === UserRole.ACCOUNTANT) {
      throw new Error('Accountants cannot modify academic performance reports.');
    }
    const parsed = studentReportInputSchema.parse(rawInput);

    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        reports: prev.reports.map((r) =>
          r.id === reportId
            ? {
                ...r,
                reportingPeriod: parsed.reportingPeriod,
                subject: parsed.subject,
                attendancePercent: parsed.attendancePercent,
                testMarks: parsed.testMarks,
                maxMarks: parsed.maxMarks,
                academicProgress: parsed.academicProgress,
                strengths: parsed.strengths,
                areasForImprovement: parsed.areasForImprovement,
                teacherComments: parsed.teacherComments,
                submissionDate: parsed.submissionDate,
                updatedAt: new Date().toISOString(),
              }
            : r
        ),
      }));
      return;
    }

    try {
      await updateDoc(doc(db, 'student_reports', reportId), {
        reportingPeriod: parsed.reportingPeriod,
        subject: parsed.subject,
        attendancePercent: parsed.attendancePercent,
        testMarks: parsed.testMarks,
        maxMarks: parsed.maxMarks,
        academicProgress: parsed.academicProgress,
        strengths: parsed.strengths,
        areasForImprovement: parsed.areasForImprovement,
        teacherComments: parsed.teacherComments,
        submissionDate: parsed.submissionDate,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `student_reports/${reportId}`);
    }
  };

  const deleteStudentReport: InstituteContextValue['deleteStudentReport'] = async (reportId) => {
    if (activeRole === UserRole.ACCOUNTANT) {
      throw new Error('Accountants cannot delete academic performance reports.');
    }
    const existing = reports.find((r) => r.id === reportId);
    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        reports: prev.reports.filter((r) => r.id !== reportId),
      }));
      return;
    }
    try {
      await deleteDoc(doc(db, 'student_reports', reportId));
      await appendAuditLog({
        entityType: 'STUDENT_REPORT',
        entityId: reportId,
        action: 'DELETE_STUDENT_REPORT',
        summary: `Deleted performance report for ${existing?.studentName ?? reportId} (${existing?.subject ?? ''})`,
        amountPaise: 0,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `student_reports/${reportId}`);
    }
  };

  // Settings & RBAC
  const saveInstituteSettings: InstituteContextValue['saveInstituteSettings'] = async (rawInput) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can update institute settings.');
    const parsed = instituteSettingsInputSchema.parse(rawInput);

    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        settings: {
          ...prev.settings,
          ...parsed,
          updatedBy: activeUserProfile!.uid,
          updatedAt: new Date().toISOString(),
        },
      }));
      return;
    }

    const ref = doc(db, 'institute_settings', 'general');
    try {
      const snap = await getDoc(ref);
      if (!snap.exists()) {
        await setDoc(ref, {
          ...parsed,
          updatedBy: firebaseUser!.uid,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
      } else {
        await updateDoc(ref, {
          ...parsed,
          updatedBy: firebaseUser!.uid,
          updatedAt: serverTimestamp(),
        });
      }
      await appendAuditLog({
        entityType: 'SETTINGS',
        entityId: 'general',
        action: 'UPDATE_INSTITUTE_SETTINGS',
        summary: `Updated institute configuration for ${parsed.instituteName}`,
        amountPaise: 0,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, 'institute_settings/general');
    }
  };

  const resetInstituteSettings: InstituteContextValue['resetInstituteSettings'] = async () => {
    if (activeRole !== UserRole.ADMIN) {
      throw new Error('Only Administrators can reset institute settings.');
    }
    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        settings: {
          ...DEFAULT_SETTINGS,
          updatedBy: activeUserProfile!.uid,
          updatedAt: new Date().toISOString(),
        },
      }));
      return;
    }

    const ref = doc(db, 'institute_settings', 'general');
    try {
      const snap = await getDoc(ref);
      if (snap.exists()) {
        await deleteDoc(ref);
      }
      setLiveSettings(DEFAULT_SETTINGS);
      await appendAuditLog({
        entityType: 'SETTINGS',
        entityId: 'general',
        action: 'RESET_INSTITUTE_SETTINGS',
        summary: 'Reset institute configuration to default settings',
        amountPaise: 0,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, 'institute_settings/general');
    }
  };

  const updateUserRole: InstituteContextValue['updateUserRole'] = async (rawInput) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can assign user roles.');
    const parsed = roleUpdateSchema.parse(rawInput);

    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        users: prev.users.map((u) =>
          u.id === parsed.userId
            ? {
                ...u,
                displayName: parsed.displayName ?? u.displayName,
                email: parsed.email ?? u.email,
                role: parsed.role,
                teacherId: parsed.teacherId,
                status: parsed.status,
              }
            : u
        ),
      }));
      return;
    }

    try {
      const userPayload: Record<string, unknown> = {
        role: parsed.role,
        teacherId: parsed.teacherId,
        status: parsed.status,
        updatedAt: serverTimestamp(),
      };
      if (parsed.displayName) userPayload.displayName = parsed.displayName;
      if (parsed.email) userPayload.email = parsed.email;

      await updateDoc(doc(db, 'users', parsed.userId), userPayload);

      // If linked to a teacher record, keep teacher.linkedUserUid synchronized
      if (parsed.teacherId) {
        await updateDoc(doc(db, 'teachers', parsed.teacherId), {
          linkedUserUid: parsed.userId,
          updatedAt: serverTimestamp(),
        });
      }

      // Synchronize financeViewerUids across institute records when finance access changes
      const updatedFinanceUids = Array.from(
        new Set(
          users
            .map((u) => (u.id === parsed.userId ? { ...u, role: parsed.role, status: parsed.status } : u))
            .filter(
              (u) =>
                u.status === 'ACTIVE' &&
                (u.role === UserRole.ADMIN || u.role === UserRole.ACCOUNTANT)
            )
            .map((u) => u.uid)
            .concat(firebaseUser?.uid ? [firebaseUser.uid] : [])
        )
      ).slice(0, 10);

      const collectionsToSync = ['courses', 'batches', 'teachers', 'students', 'invoices', 'expenses'];
      for (const col of collectionsToSync) {
        const snap = await getDocs(collection(db, col));
        if (!snap.empty) {
          const syncBatch = writeBatch(db);
          snap.docs.forEach((dSnap) => {
            syncBatch.update(dSnap.ref, {
              financeViewerUids: updatedFinanceUids,
              updatedAt: serverTimestamp(),
            });
          });
          await syncBatch.commit();
        }
      }

      await appendAuditLog({
        entityType: 'USER_ROLE',
        entityId: parsed.userId,
        action: 'ASSIGN_ROLE',
        summary: `Assigned role ${parsed.role} (${parsed.status}) to user ${parsed.userId}`,
        amountPaise: 0,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `users/${parsed.userId}`);
    }
  };

  const deleteUserProfile: InstituteContextValue['deleteUserProfile'] = async (userId) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can delete user profiles.');
    if (userId === activeUserProfile?.uid || userId === firebaseUser?.uid) {
      throw new Error('You cannot delete your own active Administrator account.');
    }
    const existing = users.find((u) => u.id === userId);

    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        users: prev.users.filter((u) => u.id !== userId),
      }));
      return;
    }

    try {
      await deleteDoc(doc(db, 'users', userId));
      await appendAuditLog({
        entityType: 'USER_ROLE',
        entityId: userId,
        action: 'DELETE_USER',
        summary: `Deleted user profile ${existing?.email ?? userId}`,
        amountPaise: 0,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `users/${userId}`);
    }
  };

  // Audit Log Edit & Delete (Strictly Admin)
  const updateAuditLog: InstituteContextValue['updateAuditLog'] = async (logId, rawInput) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can edit audit logs.');
    const parsed = auditLogUpdateSchema.parse(rawInput);
    const amountPaise = toPaise(parsed.amountRupees);

    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        auditLogs: prev.auditLogs.map((l) =>
          l.id === logId
            ? {
                ...l,
                action: parsed.action,
                summary: parsed.summary,
                amountPaise,
              }
            : l
        ),
      }));
      return;
    }

    try {
      await updateDoc(doc(db, 'audit_logs', logId), {
        action: parsed.action,
        summary: parsed.summary,
        amountPaise,
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `audit_logs/${logId}`);
    }
  };

  const deleteAuditLog: InstituteContextValue['deleteAuditLog'] = async (logId) => {
    if (activeRole !== UserRole.ADMIN) throw new Error('Only Administrators can delete audit logs.');
    if (isDemoMode) {
      setDemoData((prev) => ({
        ...prev,
        auditLogs: prev.auditLogs.filter((l) => l.id !== logId),
      }));
      return;
    }
    try {
      await deleteDoc(doc(db, 'audit_logs', logId));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `audit_logs/${logId}`);
    }
  };

  const value: InstituteContextValue = {
    authReady,
    dataLoading,
    firebaseUser,
    currentUserProfile: activeUserProfile,
    activeRole,
    isDemoMode,
    selectedPeriod,
    setSelectedPeriod,
    signInWithGoogle,
    signOutUser,
    enterDemoSandbox,
    exitDemoSandbox,
    switchDemoRole,
    getAuthToken,
    users,
    settings,
    courses,
    batches,
    teachers,
    students,
    enrollments,
    invoices,
    payments,
    agreements,
    allocations,
    payouts,
    expenses,
    reports,
    auditLogs,
    createCourse,
    updateCourse,
    archiveCourse,
    deleteCourse,
    createBatch,
    updateBatch,
    deleteBatch,
    createTeacher,
    updateTeacher,
    deleteTeacher,
    saveTeacherAgreement,
    updateTeacherAgreement,
    deleteTeacherAgreement,
    accrueMonthlyFixedSalaries,
    updateTeacherAllocation,
    deleteTeacherAllocation,
    createStudent,
    updateStudent,
    archiveStudent,
    deleteStudent,
    createInvoice,
    updateInvoice,
    deleteInvoice,
    generateMonthlyInvoicesForActiveStudents,
    recordFeePayment,
    updateFeePayment,
    reverseFeePayment,
    deleteFeePayment,
    recordTeacherPayout,
    updateTeacherPayout,
    deleteTeacherPayout,
    createExpense,
    updateExpense,
    reverseExpense,
    deleteExpense,
    submitStudentReport,
    updateStudentReport,
    deleteStudentReport,
    saveInstituteSettings,
    resetInstituteSettings,
    updateUserRole,
    deleteUserProfile,
    updateAuditLog,
    deleteAuditLog,
  };

  return <InstituteContext.Provider value={value}>{children}</InstituteContext.Provider>;
}
