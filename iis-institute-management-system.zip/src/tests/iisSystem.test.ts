import fs from 'node:fs';
import path from 'node:path';
import { describe, expect, it } from 'vitest';
import {
  AcademicProgress,
  AllocationStatus,
  ExpenseCategory,
  InvoiceStatus,
  PaymentMethod,
  PaymentSchedule,
  PaymentStatus,
  PayoutStatus,
  TeacherAgreement,
  TeacherCompensationModel,
  UserRole,
} from '../shared/types';
import {
  calculateMoMGrowth,
  calculatePaymentTeacherShare,
  computeMonthlyPeriodMetrics,
  detectInstituteWeakPoints,
  findEffectiveAgreement,
  formatINR,
  reconcileInvoiceState,
  toPaise,
} from '../shared/finance';
import {
  auditLogUpdateSchema,
  expenseUpdateSchema,
  invoiceCreateSchema,
  invoiceUpdateSchema,
  paymentCreateSchema,
  paymentUpdateSchema,
  roleUpdateSchema,
  studentInputSchema,
  studentReportInputSchema,
  teacherAllocationUpdateSchema,
  teacherPayoutUpdateSchema,
} from '../shared/validation';
import { buildIsolatedDemoDataset } from '../lib/demoData';

describe('IIS Institute Management System — Core Financial, Validation & Security Suite', () => {
  it('1. Login & Role Access Control: validates strict role schemas and isolated sandbox role scoping', () => {
    const validAdminRole = roleUpdateSchema.safeParse({
      userId: 'usr_admin_01',
      displayName: 'Principal Deshmukh',
      email: 'admin@iisinstitute.in',
      role: UserRole.ADMIN,
      teacherId: '',
      status: 'ACTIVE',
    });
    expect(validAdminRole.success).toBe(true);

    const invalidRole = roleUpdateSchema.safeParse({
      userId: 'usr_rogue',
      role: 'SUPERUSER',
      teacherId: '',
      status: 'ACTIVE',
    });
    expect(invalidRole.success).toBe(false);

    const demo = buildIsolatedDemoDataset();
    const teacherProfile = demo.users.find((u) => u.role === UserRole.TEACHER);
    expect(teacherProfile).toBeDefined();
    expect(teacherProfile?.teacherId).toBeTruthy();
  });

  it('2. Student Creation & Validation: enforces required fields, multi-course bounds, and non-negative fees', () => {
    const validStudent = studentInputSchema.safeParse({
      studentCode: 'IIS-2026-101',
      fullName: 'Aarav Kulkarni',
      primaryCourseId: 'crs_jee',
      courseIds: ['crs_jee', 'crs_math'],
      batchId: 'bat_morning',
      enrollmentDate: '2026-10-05',
      monthlyFeeRupees: 4500,
      paymentSchedule: PaymentSchedule.MONTHLY,
      status: 'ACTIVE',
      guardianName: 'Rajesh Kulkarni',
      guardianPhone: '+91 98220 11223',
      assignedTeacherId: 'tch_01',
    });
    expect(validStudent.success).toBe(true);

    const negativeFeeStudent = studentInputSchema.safeParse({
      studentCode: 'IIS-2026-102',
      fullName: 'Invalid Fee Student',
      primaryCourseId: 'crs_jee',
      courseIds: ['crs_jee'],
      batchId: 'bat_morning',
      enrollmentDate: '2026-10-05',
      monthlyFeeRupees: -500,
      paymentSchedule: PaymentSchedule.MONTHLY,
      status: 'ACTIVE',
      assignedTeacherId: 'tch_01',
    });
    expect(negativeFeeStudent.success).toBe(false);
  });

  it('3. Fee Payment Submission & Full Settlement: marks invoice PAID only when verified payments cover net due', () => {
    const invCheck = invoiceCreateSchema.safeParse({
      studentId: 'stu_01',
      courseId: 'crs_01',
      billingPeriod: '2026-10',
      grossAmountRupees: 5000,
      discountRupees: 500,
      dueDate: '2026-10-10',
      notes: 'Merit scholarship ₹500',
    });
    expect(invCheck.success).toBe(true);

    const state = reconcileInvoiceState(
      toPaise(5000),
      toPaise(500),
      toPaise(4500),
      '2026-10-10',
      '2026-10-08'
    );
    expect(state.netAmountDuePaise).toBe(450000);
    expect(state.paidAmountPaise).toBe(450000);
    expect(state.balanceDuePaise).toBe(0);
    expect(state.status).toBe(InvoiceStatus.PAID);
  });

  it('4. Partial Payment Balance Updates: never marks invoice PAID prematurely and transitions to OVERDUE past due date', () => {
    const beforeDue = reconcileInvoiceState(
      toPaise(4000),
      0,
      toPaise(1500),
      '2026-10-10',
      '2026-10-06'
    );
    expect(beforeDue.balanceDuePaise).toBe(toPaise(2500));
    expect(beforeDue.status).toBe(InvoiceStatus.PARTIAL);

    const afterDue = reconcileInvoiceState(
      toPaise(4000),
      0,
      toPaise(1500),
      '2026-10-10',
      '2026-10-18'
    );
    expect(afterDue.balanceDuePaise).toBe(toPaise(2500));
    expect(afterDue.status).toBe(InvoiceStatus.OVERDUE);
  });

  it('5. Duplicate Payment & Share Allocation Prevention: enforces idempotency keys and single per-student period share', () => {
    const shortKey = paymentCreateSchema.safeParse({
      invoiceId: 'inv_01',
      idempotencyKey: 'abc',
      amountRupees: 2000,
      paymentMethod: PaymentMethod.UPI,
      paymentDate: '2026-10-08',
    });
    expect(shortKey.success).toBe(false);

    const validKey = paymentCreateSchema.safeParse({
      invoiceId: 'inv_01',
      idempotencyKey: 'idem_20261008_inv01_first',
      amountRupees: 2000,
      paymentMethod: PaymentMethod.UPI,
      paymentDate: '2026-10-08',
    });
    expect(validKey.success).toBe(true);

    const perStudentAgreement: TeacherAgreement = {
      id: 'ag_per_stu',
      teacherId: 'tch_1',
      teacherUid: 'uid_tch_1',
      teacherName: 'Prof. Sharma',
      modelType: TeacherCompensationModel.PER_STUDENT,
      fixedMonthlyPaise: 0,
      shareBasisPoints: 0,
      perStudentPaise: toPaise(900),
      effectiveFrom: '2026-01-01',
      effectiveTo: '',
      notes: '',
      status: 'ACTIVE',
      financeViewerUids: [],
      createdBy: 'admin',
      createdAt: '2026-01-01T00:00:00Z',
      updatedAt: '2026-01-01T00:00:00Z',
    };

    const firstInstallmentShare = calculatePaymentTeacherShare(toPaise(1000), perStudentAgreement, 0);
    expect(firstInstallmentShare.shouldCreateAllocation).toBe(true);
    expect(firstInstallmentShare.allocatedAmountPaise).toBe(toPaise(900));

    // Second installment in same billing period for same student must NOT duplicate per-student allocation
    const secondInstallmentShare = calculatePaymentTeacherShare(toPaise(1000), perStudentAgreement, 1);
    expect(secondInstallmentShare.shouldCreateAllocation).toBe(false);
    expect(secondInstallmentShare.allocatedAmountPaise).toBe(0);
  });

  it('6. Teacher Share Calculation & Historical Agreement Preservation: ₹2,000 at 40% = ₹800 and preserves prior period rates', () => {
    const agreements: TeacherAgreement[] = [
      {
        id: 'ag_hist_40',
        teacherId: 'tch_physics',
        teacherUid: 'uid_phy',
        teacherName: 'Dr. Verma',
        modelType: TeacherCompensationModel.PERCENTAGE,
        fixedMonthlyPaise: 0,
        shareBasisPoints: 4000, // 40.00%
        perStudentPaise: 0,
        effectiveFrom: '2026-01-01',
        effectiveTo: '2026-09-30',
        notes: 'Initial 40% share',
        status: 'SUPERSEDED',
        financeViewerUids: [],
        createdBy: 'admin',
        createdAt: '2026-01-01T00:00:00Z',
        updatedAt: '2026-09-30T00:00:00Z',
      },
      {
        id: 'ag_new_50',
        teacherId: 'tch_physics',
        teacherUid: 'uid_phy',
        teacherName: 'Dr. Verma',
        modelType: TeacherCompensationModel.PERCENTAGE,
        fixedMonthlyPaise: 0,
        shareBasisPoints: 5000, // 50.00%
        perStudentPaise: 0,
        effectiveFrom: '2026-10-01',
        effectiveTo: '',
        notes: 'Revised 50% share from Oct',
        status: 'ACTIVE',
        financeViewerUids: [],
        createdBy: 'admin',
        createdAt: '2026-10-01T00:00:00Z',
        updatedAt: '2026-10-01T00:00:00Z',
      },
    ];

    const septAgreement = findEffectiveAgreement(agreements, 'tch_physics', '2026-09-15');
    expect(septAgreement?.id).toBe('ag_hist_40');

    const septCalc = calculatePaymentTeacherShare(toPaise(2000), septAgreement);
    expect(septCalc.allocatedAmountPaise).toBe(toPaise(800));
    expect(formatINR(septCalc.allocatedAmountPaise)).toBe('₹800');

    const octAgreement = findEffectiveAgreement(agreements, 'tch_physics', '2026-10-12');
    expect(octAgreement?.id).toBe('ag_new_50');
    const octCalc = calculatePaymentTeacherShare(toPaise(2000), octAgreement);
    expect(octCalc.allocatedAmountPaise).toBe(toPaise(1000));
  });

  it('7 & 8. Monthly Revenue Totals & Net Operating Income: separates invoiced vs collected and accrued share vs cash payout', () => {
    const metrics = computeMonthlyPeriodMetrics({
      period: '2026-10',
      todayIST: '2026-10-20',
      students: [
        {
          id: 's1',
          studentCode: 'IIS-1',
          fullName: 'Riya Sen',
          primaryCourseId: 'c1',
          primaryCourseName: 'NEET Biology',
          courseIds: ['c1'],
          batchId: 'b1',
          batchName: 'Batch A',
          enrollmentDate: '2026-06-01',
          monthlyFeePaise: toPaise(10000),
          paymentSchedule: PaymentSchedule.MONTHLY,
          status: 'ACTIVE',
          guardianName: 'Amit Sen',
          guardianPhone: '9999999999',
          assignedTeacherId: 't1',
          assignedTeacherUid: 'u_t1',
          assignedTeacherName: 'Dr. Rao',
          financeViewerUids: [],
          createdBy: 'admin',
          createdAt: '',
          updatedAt: '',
        },
      ],
      invoices: [
        {
          id: 'i1',
          invoiceNumber: 'INV-1',
          studentId: 's1',
          studentName: 'Riya Sen',
          courseId: 'c1',
          courseName: 'NEET Biology',
          batchId: 'b1',
          billingPeriod: '2026-10',
          grossAmountPaise: toPaise(10000),
          discountPaise: toPaise(1000),
          netAmountDuePaise: toPaise(9000),
          paidAmountPaise: toPaise(6000),
          balanceDuePaise: toPaise(3000),
          dueDate: '2026-10-10',
          status: InvoiceStatus.OVERDUE,
          assignedTeacherId: 't1',
          notes: '',
          financeViewerUids: [],
          createdBy: 'admin',
          createdAt: '',
          updatedAt: '',
        },
      ],
      payments: [
        {
          id: 'p1',
          receiptNumber: 'IIS-1',
          idempotencyKey: 'idem_p1',
          invoiceId: 'i1',
          studentId: 's1',
          studentName: 'Riya Sen',
          courseId: 'c1',
          courseName: 'NEET Biology',
          billingPeriod: '2026-10',
          amountPaise: toPaise(6000),
          paymentMethod: PaymentMethod.UPI,
          paymentDate: '2026-10-05',
          referenceNote: '',
          status: PaymentStatus.COMPLETED,
          reversalReason: '',
          financeViewerUids: [],
          recordedBy: 'admin',
          createdAt: '',
          updatedAt: '',
        },
        {
          id: 'p2_rev',
          receiptNumber: 'IIS-2',
          idempotencyKey: 'idem_p2',
          invoiceId: 'i1',
          studentId: 's1',
          studentName: 'Riya Sen',
          courseId: 'c1',
          courseName: 'NEET Biology',
          billingPeriod: '2026-10',
          amountPaise: toPaise(3000),
          paymentMethod: PaymentMethod.CASH,
          paymentDate: '2026-10-06',
          referenceNote: '',
          status: PaymentStatus.REVERSED,
          reversalReason: 'Entered in error',
          financeViewerUids: [],
          recordedBy: 'admin',
          createdAt: '',
          updatedAt: '',
        },
      ],
      allocations: [
        {
          id: 'al1',
          agreementId: 'ag1',
          modelTypeSnapshot: TeacherCompensationModel.PERCENTAGE,
          rateSnapshotLabel: '40% of collected fee',
          teacherId: 't1',
          teacherUid: 'u_t1',
          teacherName: 'Dr. Rao',
          paymentId: 'p1',
          invoiceId: 'i1',
          studentId: 's1',
          studentName: 'Riya Sen',
          billingPeriod: '2026-10',
          basisAmountPaise: toPaise(6000),
          allocatedAmountPaise: toPaise(2400),
          status: AllocationStatus.ACCRUED,
          payoutId: '',
          financeViewerUids: [],
          createdBy: 'admin',
          createdAt: '',
          updatedAt: '',
        },
      ],
      payouts: [
        {
          id: 'po1',
          payoutNumber: 'PO-1',
          teacherId: 't1',
          teacherUid: 'u_t1',
          teacherName: 'Dr. Rao',
          billingPeriod: '2026-10',
          amountPaise: toPaise(1000),
          paymentMethod: PaymentMethod.BANK_TRANSFER,
          payoutDate: '2026-10-15',
          referenceNote: 'Partial advance',
          status: PayoutStatus.PAID,
          financeViewerUids: [],
          createdBy: 'admin',
          createdAt: '',
          updatedAt: '',
        },
      ],
      expenses: [
        {
          id: 'ex1',
          title: 'Campus Electricity',
          category: ExpenseCategory.UTILITIES,
          amountPaise: toPaise(1100),
          expenseDate: '2026-10-12',
          billingPeriod: '2026-10',
          paymentMethod: PaymentMethod.UPI,
          vendorName: 'MSEDCL',
          notes: '',
          status: 'RECORDED',
          financeViewerUids: [],
          createdBy: 'admin',
          createdAt: '',
          updatedAt: '',
        },
      ],
    });

    expect(metrics.invoicedNetPaise).toBe(toPaise(9000));
    expect(metrics.collectedFeePaise).toBe(toPaise(6000)); // Reversed p2_rev excluded!
    expect(metrics.pendingBalancePaise).toBe(toPaise(3000));
    expect(metrics.accruedTeacherSharePaise).toBe(toPaise(2400));
    expect(metrics.paidTeacherPayoutPaise).toBe(toPaise(1000));
    expect(metrics.unpaidTeacherLiabilityPaise).toBe(toPaise(1400));
    // Net Operating Income = 6000 - 2400 (accrued share) - 1100 (expenses) = 2500
    expect(metrics.netOperatingIncomePaise).toBe(toPaise(2500));
    // Cash Net Surplus = 6000 - 1000 (cash payout) - 1100 (expenses) = 3900
    expect(metrics.cashNetSurplusPaise).toBe(toPaise(3900));
  });

  it('9 & 10. Month-over-Month Growth & Zero-Value Previous Month Handling: computes exact % and returns N/A on 0 base', () => {
    const normalGrowth = calculateMoMGrowth(toPaise(125000), toPaise(100000));
    expect(normalGrowth.growthPercent).toBe(25);
    expect(normalGrowth.formattedPercent).toBe('+25.0%');
    expect(normalGrowth.direction).toBe('up');
    expect(normalGrowth.isZeroBase).toBe(false);

    const zeroBaseGrowth = calculateMoMGrowth(toPaise(85000), 0);
    expect(zeroBaseGrowth.growthPercent).toBeNull();
    expect(zeroBaseGrowth.formattedPercent).toBe('N/A');
    expect(zeroBaseGrowth.isZeroBase).toBe(true);
    expect(zeroBaseGrowth.absoluteDiff).toBe(toPaise(85000));
  });

  it('11. Student Performance Report Validation: rejects scored marks exceeding maximum marks', () => {
    const validReport = studentReportInputSchema.safeParse({
      studentId: 'stu_01',
      reportingPeriod: '2026-10',
      subject: 'Organic Chemistry',
      attendancePercent: 94,
      testMarks: 88,
      maxMarks: 100,
      academicProgress: AcademicProgress.EXCELLENT,
      strengths: 'Reaction mechanisms',
      areasForImprovement: 'Stereochemistry speed',
      teacherComments: 'Consistent top-decile work',
      submissionDate: '2026-10-25',
    });
    expect(validReport.success).toBe(true);

    const impossibleScore = studentReportInputSchema.safeParse({
      studentId: 'stu_01',
      reportingPeriod: '2026-10',
      subject: 'Organic Chemistry',
      attendancePercent: 94,
      testMarks: 105,
      maxMarks: 100,
      academicProgress: AcademicProgress.EXCELLENT,
      submissionDate: '2026-10-25',
    });
    expect(impossibleScore.success).toBe(false);
  });

  it('12. Weak-Point Detection Logic: flags margin compression when revenue grows but rising expenses reduce profit', () => {
    const prev = computeMonthlyPeriodMetrics({
      period: '2026-09',
      students: [],
      invoices: [],
      payments: [
        {
          id: 'p_sep',
          receiptNumber: 'R-SEP',
          idempotencyKey: 'k_sep',
          invoiceId: 'i_sep',
          studentId: 's1',
          studentName: 'Stu',
          courseId: 'c1',
          courseName: 'JEE',
          billingPeriod: '2026-09',
          amountPaise: toPaise(100000),
          paymentMethod: PaymentMethod.UPI,
          paymentDate: '2026-09-10',
          referenceNote: '',
          status: PaymentStatus.COMPLETED,
          reversalReason: '',
          financeViewerUids: [],
          recordedBy: 'admin',
          createdAt: '',
          updatedAt: '',
        },
      ],
      allocations: [],
      payouts: [],
      expenses: [
        {
          id: 'e_sep',
          title: 'Rent',
          category: ExpenseCategory.RENT,
          amountPaise: toPaise(30000),
          expenseDate: '2026-09-05',
          billingPeriod: '2026-09',
          paymentMethod: PaymentMethod.BANK_TRANSFER,
          vendorName: '',
          notes: '',
          status: 'RECORDED',
          financeViewerUids: [],
          createdBy: 'admin',
          createdAt: '',
          updatedAt: '',
        },
      ],
    });

    const curr = computeMonthlyPeriodMetrics({
      period: '2026-10',
      students: [],
      invoices: [],
      payments: [
        {
          id: 'p_oct',
          receiptNumber: 'R-OCT',
          idempotencyKey: 'k_oct',
          invoiceId: 'i_oct',
          studentId: 's1',
          studentName: 'Stu',
          courseId: 'c1',
          courseName: 'JEE',
          billingPeriod: '2026-10',
          amountPaise: toPaise(110000), // Revenue rose +10%!
          paymentMethod: PaymentMethod.UPI,
          paymentDate: '2026-10-10',
          referenceNote: '',
          status: PaymentStatus.COMPLETED,
          reversalReason: '',
          financeViewerUids: [],
          recordedBy: 'admin',
          createdAt: '',
          updatedAt: '',
        },
      ],
      allocations: [],
      payouts: [],
      expenses: [
        {
          id: 'e_oct',
          title: 'Rent + Heavy Marketing Campaign',
          category: ExpenseCategory.MARKETING,
          amountPaise: toPaise(60000), // Expenses doubled, dropping profit from ₹70k to ₹50k!
          expenseDate: '2026-10-05',
          billingPeriod: '2026-10',
          paymentMethod: PaymentMethod.BANK_TRANSFER,
          vendorName: '',
          notes: '',
          status: 'RECORDED',
          financeViewerUids: [],
          createdBy: 'admin',
          createdAt: '',
          updatedAt: '',
        },
      ],
    });

    expect(curr.collectedFeePaise).toBeGreaterThan(prev.collectedFeePaise);
    expect(curr.netOperatingIncomePaise).toBeLessThan(prev.netOperatingIncomePaise);

    const findings = detectInstituteWeakPoints({
      current: curr,
      previous: prev,
      payments: [],
      invoices: [],
    });

    const marginAlert = findings.find((f) => f.id === 'wp-margin-compression');
    const expenseAlert = findings.find((f) => f.id === 'wp-rising-expenses');
    expect(marginAlert).toBeDefined();
    expect(marginAlert?.reason).toContain('compressed net profit');
    expect(expenseAlert).toBeDefined();
  });

  it('13. Firestore Security Rules Hardening: verifies role-scoped edit & delete rules and schema key allowlists', () => {
    const rulesPath = path.resolve(process.cwd(), 'firestore.rules');
    const rulesContent = fs.readFileSync(rulesPath, 'utf-8');

    // Never permit public open read/write or unauthenticated delete
    expect(rulesContent).not.toContain('allow read, write: if true');
    expect(rulesContent).not.toContain('allow delete: if true');
    expect(rulesContent).not.toContain('allow delete: if false;');

    // Role-scoped verified delete rules exist across collections
    expect(rulesContent).toContain('allow delete: if isVerified()');
    // Strict schema allowlisting via hasOnly
    expect(rulesContent).toContain('.keys().hasOnly(');
    // Bootstrapped owner email check uses token email_verified
    expect(rulesContent).toContain('request.auth.token.email_verified == true');
  });

  it('14. Full Edit & Delete Update Schemas & Relational Balance Recalculation: validates edits across all ledgers', () => {
    const validInvoiceEdit = invoiceUpdateSchema.safeParse({
      courseId: 'crs_01',
      billingPeriod: '2026-10',
      grossAmountRupees: 4800,
      discountRupees: 300,
      dueDate: '2026-10-12',
      notes: 'Updated scholarship concession',
      isCancelled: false,
    });
    expect(validInvoiceEdit.success).toBe(true);

    const invalidInvoiceEdit = invoiceUpdateSchema.safeParse({
      courseId: 'crs_01',
      billingPeriod: '2026-10',
      grossAmountRupees: 2000,
      discountRupees: 2500, // Discount > Gross rejected
      dueDate: '2026-10-12',
    });
    expect(invalidInvoiceEdit.success).toBe(false);

    const validPaymentEdit = paymentUpdateSchema.safeParse({
      amountRupees: 3000,
      paymentMethod: PaymentMethod.BANK_TRANSFER,
      paymentDate: '2026-10-09',
      referenceNote: 'Adjusted UTR',
      status: PaymentStatus.COMPLETED,
      reversalReason: '',
    });
    expect(validPaymentEdit.success).toBe(true);

    // Editing or deleting a payment recalculates parent invoice state accurately
    const afterPaymentEdited = reconcileInvoiceState(
      toPaise(4800),
      toPaise(300),
      toPaise(3000),
      '2026-10-12',
      '2026-10-09'
    );
    expect(afterPaymentEdited.netAmountDuePaise).toBe(toPaise(4500));
    expect(afterPaymentEdited.balanceDuePaise).toBe(toPaise(1500));
    expect(afterPaymentEdited.status).toBe(InvoiceStatus.PARTIAL);

    const afterPaymentDeleted = reconcileInvoiceState(
      toPaise(4800),
      toPaise(300),
      0,
      '2026-10-12',
      '2026-10-09'
    );
    expect(afterPaymentDeleted.balanceDuePaise).toBe(toPaise(4500));
    expect(afterPaymentDeleted.status).toBe(InvoiceStatus.PENDING);

    expect(
      teacherAllocationUpdateSchema.safeParse({
        billingPeriod: '2026-10',
        basisAmountRupees: 3000,
        allocatedAmountRupees: 1200,
        rateSnapshotLabel: '40% of collected fee',
        status: AllocationStatus.ACCRUED,
      }).success
    ).toBe(true);

    expect(
      teacherPayoutUpdateSchema.safeParse({
        teacherId: 'tch_01',
        billingPeriod: '2026-10',
        amountRupees: 1200,
        paymentMethod: PaymentMethod.UPI,
        payoutDate: '2026-10-15',
        referenceNote: 'Updated UPI ref',
        status: PayoutStatus.PAID,
      }).success
    ).toBe(true);

    expect(
      expenseUpdateSchema.safeParse({
        title: 'Classroom Electricity',
        category: ExpenseCategory.UTILITIES,
        amountRupees: 2800,
        expenseDate: '2026-10-14',
        paymentMethod: PaymentMethod.UPI,
        vendorName: 'MSEDCL',
        notes: 'Corrected meter bill',
        status: 'RECORDED',
      }).success
    ).toBe(true);

    expect(
      auditLogUpdateSchema.safeParse({
        action: 'PAYMENT_UPDATED',
        summary: 'Corrected receipt UTR and amount',
        amountRupees: 3000,
      }).success
    ).toBe(true);
  });
});
