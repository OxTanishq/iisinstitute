import React, { useMemo, useState } from 'react';
import {
  Line,
  LineChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { Plus, Search, Edit2, Archive, Download, ArrowLeft, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { useInstitute } from '../context/InstituteContext';
import {
  AcademicProgress,
  Invoice,
  InvoiceStatus,
  NavPageId,
  Payment,
  PaymentMethod,
  PaymentSchedule,
  PaymentStatus,
  Student,
  StudentReport,
  UserRole,
} from '../shared/types';
import { formatINR, getTodayIST } from '../shared/finance';
import { generatePaymentReceiptPDF } from '../lib/pdfExport';
import {
  Button,
  ConfirmDeleteDialog,
  Dialog,
  DialogContent,
  EmptyState,
  Input,
  Label,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  StatusText,
  Switch,
  Textarea,
} from '../components/ui/primitives';

export function StudentsPage({
  onSelectStudentProfile,
  onNavigate,
}: {
  onSelectStudentProfile: (studentId: string) => void;
  onNavigate: (page: NavPageId) => void;
}) {
  const {
    activeRole,
    students,
    courses,
    batches,
    teachers,
    invoices,
    createStudent,
    updateStudent,
    archiveStudent,
    deleteStudent,
    createCourse,
    createTeacher,
  } = useInstitute();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'INACTIVE' | 'ARCHIVED'>('ACTIVE');
  const [courseFilter, setCourseFilter] = useState<string>('ALL');

  const [modalOpen, setModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [deleteTargetStudent, setDeleteTargetStudent] = useState<Student | null>(null);
  const [quickSetupOpen, setQuickSetupOpen] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  // Student Form State
  const [studentCode, setStudentCode] = useState('');
  const [fullName, setFullName] = useState('');
  const [primaryCourseId, setPrimaryCourseId] = useState('');
  const [extraCourseIds, setExtraCourseIds] = useState<string[]>([]);
  const [batchId, setBatchId] = useState('');
  const [assignedTeacherId, setAssignedTeacherId] = useState('');
  const [enrollmentDate, setEnrollmentDate] = useState(getTodayIST());
  const [monthlyFeeRupees, setMonthlyFeeRupees] = useState('2500');
  const [paymentSchedule, setPaymentSchedule] = useState<PaymentSchedule>(PaymentSchedule.MONTHLY);
  const [status, setStatus] = useState<'ACTIVE' | 'INACTIVE' | 'ARCHIVED'>('ACTIVE');
  const [guardianName, setGuardianName] = useState('');
  const [guardianPhone, setGuardianPhone] = useState('');

  // Quick Setup State (when fresh DB has no courses/teachers/batches yet)
  const [qsCourseName, setQsCourseName] = useState('JEE Physics & Mathematics');
  const [qsCourseCode, setQsCourseCode] = useState('JEE-ADV');
  const [qsCourseFee, setQsCourseFee] = useState('4500');
  const [qsTeacherName, setQsTeacherName] = useState('');
  const [qsTeacherEmail, setQsTeacherEmail] = useState('');

  const activeCourses = courses.filter((c) => c.status === 'ACTIVE');
  const activeBatches = batches.filter((b) => b.status === 'ACTIVE');
  const activeTeachers = teachers.filter((t) => t.status === 'ACTIVE');

  const selectableCourses = useMemo(
    () =>
      courses.filter(
        (c) =>
          c.status === 'ACTIVE' ||
          c.id === primaryCourseId ||
          extraCourseIds.includes(c.id)
      ),
    [courses, primaryCourseId, extraCourseIds]
  );

  const selectableBatches = useMemo(
    () => batches.filter((b) => b.status === 'ACTIVE' || b.id === batchId),
    [batches, batchId]
  );

  const selectableTeachers = useMemo(
    () => teachers.filter((t) => t.status === 'ACTIVE' || t.id === assignedTeacherId),
    [teachers, assignedTeacherId]
  );

  const openAddModal = () => {
    setEditingStudent(null);
    const nextNum = String(students.length + 1).padStart(3, '0');
    setStudentCode(`IIS-${getTodayIST().slice(0, 4)}-${nextNum}`);
    setFullName('');
    const defaultCourse = activeCourses[0];
    setPrimaryCourseId(defaultCourse?.id ?? '');
    setExtraCourseIds([]);
    const matchingBatch =
      activeBatches.find((b) => b.courseId === defaultCourse?.id) ?? activeBatches[0];
    setBatchId(matchingBatch?.id ?? '');
    setAssignedTeacherId(matchingBatch?.teacherId ?? activeTeachers[0]?.id ?? '');
    setEnrollmentDate(getTodayIST());
    setMonthlyFeeRupees(
      defaultCourse ? String(Math.round(defaultCourse.defaultMonthlyFeePaise / 100)) : '2500'
    );
    setPaymentSchedule(PaymentSchedule.MONTHLY);
    setStatus('ACTIVE');
    setGuardianName('');
    setGuardianPhone('');
    setModalOpen(true);
  };

  const openEditModal = (stu: Student) => {
    setEditingStudent(stu);
    setStudentCode(stu.studentCode);
    setFullName(stu.fullName);
    setPrimaryCourseId(stu.primaryCourseId);
    setExtraCourseIds(stu.courseIds.filter((id) => id !== stu.primaryCourseId));
    setBatchId(stu.batchId);
    setAssignedTeacherId(stu.assignedTeacherId);
    setEnrollmentDate(stu.enrollmentDate);
    setMonthlyFeeRupees(String(stu.monthlyFeePaise / 100));
    setPaymentSchedule(stu.paymentSchedule);
    setStatus(stu.status);
    setGuardianName(stu.guardianName);
    setGuardianPhone(stu.guardianPhone);
    setModalOpen(true);
  };

  const handleSaveStudent = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const allCourses = Array.from(new Set([primaryCourseId, ...extraCourseIds].filter(Boolean)));
      const payload = {
        studentCode,
        fullName,
        primaryCourseId,
        courseIds: allCourses,
        batchId,
        enrollmentDate,
        monthlyFeeRupees: Number(monthlyFeeRupees),
        paymentSchedule,
        status,
        guardianName,
        guardianPhone,
        assignedTeacherId,
      };
      if (editingStudent) {
        await updateStudent(editingStudent.id, payload);
        toast.success(`Updated student ${fullName}`);
      } else {
        await createStudent(payload);
        toast.success(`Enrolled student ${fullName}`);
      }
      setModalOpen(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to save student');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDeleteStudent = async () => {
    if (!deleteTargetStudent) return;
    setSubmitting(true);
    try {
      const targetName = deleteTargetStudent.fullName;
      await deleteStudent(deleteTargetStudent.id);
      toast.success(`Deleted student ${targetName} and linked records.`);
      setDeleteTargetStudent(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete student');
    } finally {
      setSubmitting(false);
    }
  };

  const handleQuickBootstrap = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!qsTeacherName.trim() || !qsTeacherEmail.trim()) {
      toast.error('Please enter faculty name and email.');
      return;
    }
    setSubmitting(true);
    try {
      await createCourse({
        code: qsCourseCode,
        name: qsCourseName,
        subjectCategory: 'Core Academic',
        defaultMonthlyFeeRupees: Number(qsCourseFee) || 3000,
        durationMonths: 12,
      });
      await createTeacher({
        teacherCode: 'FAC-101',
        fullName: qsTeacherName,
        email: qsTeacherEmail,
        phone: '',
        specialization: qsCourseName,
        subjects: [qsCourseName],
        linkedUserUid: '',
        joinedDate: getTodayIST(),
      });
      toast.success('Course and Teacher created. Now create your Batch in Settings or Teachers.');
      setQuickSetupOpen(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Setup failed');
    } finally {
      setSubmitting(false);
    }
  };

  const studentOutstandingMap = useMemo(() => {
    const map = new Map<string, number>();
    invoices.forEach((inv) => {
      if (inv.status !== InvoiceStatus.CANCELLED && inv.balanceDuePaise > 0) {
        map.set(inv.studentId, (map.get(inv.studentId) ?? 0) + inv.balanceDuePaise);
      }
    });
    return map;
  }, [invoices]);

  const filteredStudents = useMemo(() => {
    return students.filter((s) => {
      if (statusFilter !== 'ALL' && s.status !== statusFilter) return false;
      if (courseFilter !== 'ALL' && !s.courseIds.includes(courseFilter)) return false;
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase();
        return (
          s.fullName.toLowerCase().includes(q) ||
          s.studentCode.toLowerCase().includes(q) ||
          s.guardianName.toLowerCase().includes(q) ||
          s.primaryCourseName.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [students, statusFilter, courseFilter, searchTerm]);

  const prerequisitesMissing =
    activeRole === UserRole.ADMIN &&
    (activeCourses.length === 0 || activeTeachers.length === 0 || activeBatches.length === 0);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-blue-600 mb-1">Student Roster & Admissions</p>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Students</h1>
        </div>

        {activeRole === UserRole.ADMIN && (
          <div className="flex items-center gap-2.5">
            {prerequisitesMissing ? (
              <Button size="sm" onClick={() => onNavigate('settings')}>
                Configure Courses & Batches First
              </Button>
            ) : (
              <Button size="sm" onClick={openAddModal}>
                <Plus className="h-4 w-4" />
                <span>Enroll Student</span>
              </Button>
            )}
          </div>
        )}
      </div>

      {prerequisitesMissing && (
        <div className="bg-blue-50/70 border border-blue-200 rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-bold text-slate-900">
              Set up your first Course, Faculty Member, and Batch
            </h3>
            <p className="text-xs text-slate-600 mt-1">
              Students link to an active Course, Batch, and Assigned Teacher. Create them in
              Settings &amp; Teachers before enrolling your first student.
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="secondary" size="sm" onClick={() => setQuickSetupOpen(true)}>
              Quick Setup Course & Teacher
            </Button>
            <Button size="sm" onClick={() => onNavigate('settings')}>
              Open Catalog Settings
            </Button>
          </div>
        </div>
      )}

      {/* Search & Filters */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="h-4 w-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <Input
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by name, student ID, guardian, or course..."
            className="pl-9"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {courses.length > 0 && (
            <div className="w-48">
              <Select value={courseFilter} onValueChange={setCourseFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All Courses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All Courses</SelectItem>
                  {courses.map((c) => (
                    <SelectItem key={c.id} value={c.id}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
            {(['ALL', 'ACTIVE', 'INACTIVE', 'ARCHIVED'] as const).map((st) => (
              <button
                key={st}
                type="button"
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                  statusFilter === st
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {st === 'ALL' ? 'All' : st.charAt(0) + st.slice(1).toLowerCase()}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Roster Table */}
      <div className="bg-white border border-slate-200/90 rounded-xl overflow-hidden">
        {filteredStudents.length === 0 ? (
          <div className="p-6">
            <EmptyState
              title="No matching students found"
              description={
                students.length === 0
                  ? 'Your institute student roster is currently empty. Enroll your first student to begin tracking tuition fees and performance reports.'
                  : 'Adjust your search query or status filter to locate student records.'
              }
              actionLabel={
                activeRole === UserRole.ADMIN && !prerequisitesMissing ? 'Enroll Student' : undefined
              }
              onAction={
                activeRole === UserRole.ADMIN && !prerequisitesMissing ? openAddModal : undefined
              }
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-500">
                  <th className="py-3 px-4">Student ID</th>
                  <th className="py-3 px-4">Student & Guardian</th>
                  <th className="py-3 px-4">Course & Batch</th>
                  <th className="py-3 px-4">Assigned Teacher</th>
                  <th className="py-3 px-4 text-right">Monthly Fee</th>
                  {activeRole !== UserRole.TEACHER && (
                    <th className="py-3 px-4 text-right">Pending Due</th>
                  )}
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredStudents.map((stu) => {
                  const due = studentOutstandingMap.get(stu.id) ?? 0;
                  return (
                    <tr key={stu.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 px-4 font-mono text-xs text-slate-600 whitespace-nowrap">
                        {stu.studentCode}
                      </td>
                      <td className="py-3 px-4">
                        <button
                          type="button"
                          onClick={() => {
                            onSelectStudentProfile(stu.id);
                            onNavigate('student-profiles');
                          }}
                          className="font-semibold text-slate-900 hover:text-blue-600 transition-colors cursor-pointer text-left"
                        >
                          {stu.fullName}
                        </button>
                        {stu.guardianName && (
                          <div className="text-xs text-slate-500">
                            {stu.guardianName}
                            {stu.guardianPhone ? ` · ${stu.guardianPhone}` : ''}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <div className="text-slate-800 font-medium">{stu.primaryCourseName}</div>
                        <div className="text-xs text-slate-500">
                          {stu.batchName}
                          {stu.courseIds.length > 1 ? ` · +${stu.courseIds.length - 1} course` : ''}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-600">{stu.assignedTeacherName}</td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums font-medium text-slate-900">
                        {formatINR(stu.monthlyFeePaise)}
                      </td>
                      {activeRole !== UserRole.TEACHER && (
                        <td className="py-3 px-4 text-right font-mono tabular-nums">
                          <span className={due > 0 ? 'text-amber-700 font-semibold' : 'text-slate-400'}>
                            {formatINR(due)}
                          </span>
                        </td>
                      )}
                      <td className="py-3 px-4">
                        <StatusText
                          tone={
                            stu.status === 'ACTIVE'
                              ? 'positive'
                              : stu.status === 'INACTIVE'
                              ? 'warning'
                              : 'neutral'
                          }
                          label={stu.status}
                        />
                      </td>
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => {
                              onSelectStudentProfile(stu.id);
                              onNavigate('student-profiles');
                            }}
                          >
                            Profile
                          </Button>
                          {activeRole === UserRole.ADMIN && (
                            <>
                              <button
                                type="button"
                                onClick={() => openEditModal(stu)}
                                title="Edit student"
                                className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                              >
                                <Edit2 className="h-3.5 w-3.5" />
                              </button>
                              {stu.status !== 'ARCHIVED' && (
                                <button
                                  type="button"
                                  onClick={async () => {
                                    try {
                                      await archiveStudent(stu.id);
                                      toast.success(`Archived ${stu.fullName}`);
                                    } catch (e) {
                                      toast.error(e instanceof Error ? e.message : 'Archive failed');
                                    }
                                  }}
                                  title="Archive student"
                                  className="p-1.5 rounded-md text-slate-400 hover:text-amber-700 hover:bg-amber-50 cursor-pointer"
                                >
                                  <Archive className="h-3.5 w-3.5" />
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => setDeleteTargetStudent(stu)}
                                title="Delete student permanently"
                                className="p-1.5 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Student Dialog */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent
          title={editingStudent ? 'Edit Student Record' : 'Enroll New Student'}
          description="All tuition figures are stored in exact integer paise with full enrollment history."
          maxWidthClass="max-w-2xl"
        >
          <form onSubmit={handleSaveStudent} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="stu-code">Unique Student ID</Label>
                <Input
                  id="stu-code"
                  value={studentCode}
                  onChange={(e) => setStudentCode(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="stu-name">Full Name</Label>
                <Input
                  id="stu-name"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g., Aarav Kulkarni"
                  required
                />
              </div>

              <div>
                <Label>Primary Course</Label>
                <Select
                  value={primaryCourseId}
                  onValueChange={(val) => {
                    setPrimaryCourseId(val);
                    const crs = courses.find((c) => c.id === val);
                    if (crs && !editingStudent) {
                      setMonthlyFeeRupees(String(Math.round(crs.defaultMonthlyFeePaise / 100)));
                    }
                    const b = activeBatches.find((bat) => bat.courseId === val);
                    if (b) {
                      setBatchId(b.id);
                      setAssignedTeacherId(b.teacherId);
                    }
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select course" />
                  </SelectTrigger>
                  <SelectContent>
                    {selectableCourses.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name} ({formatINR(c.defaultMonthlyFeePaise)}/mo)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Instructional Batch</Label>
                <Select
                  value={batchId}
                  onValueChange={(val) => {
                    setBatchId(val);
                    const b = batches.find((bat) => bat.id === val);
                    if (b) setAssignedTeacherId(b.teacherId);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select batch" />
                  </SelectTrigger>
                  <SelectContent>
                    {selectableBatches.map((b) => (
                      <SelectItem key={b.id} value={b.id}>
                        {b.name} ({b.code})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Assigned Teacher</Label>
                <Select value={assignedTeacherId} onValueChange={setAssignedTeacherId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select faculty" />
                  </SelectTrigger>
                  <SelectContent>
                    {selectableTeachers.map((t) => (
                      <SelectItem key={t.id} value={t.id}>
                        {t.fullName} ({t.teacherCode})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="stu-enroll-date">Enrollment Date (IST)</Label>
                <Input
                  id="stu-enroll-date"
                  type="date"
                  value={enrollmentDate}
                  onChange={(e) => setEnrollmentDate(e.target.value)}
                  required
                />
              </div>

              <div>
                <Label htmlFor="stu-fee">Agreed Monthly Fee (INR ₹)</Label>
                <Input
                  id="stu-fee"
                  type="number"
                  min="0"
                  step="1"
                  value={monthlyFeeRupees}
                  onChange={(e) => setMonthlyFeeRupees(e.target.value)}
                  required
                />
              </div>

              <div>
                <Label>Payment Schedule</Label>
                <Select
                  value={paymentSchedule}
                  onValueChange={(v) => setPaymentSchedule(v as PaymentSchedule)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={PaymentSchedule.MONTHLY}>Monthly</SelectItem>
                    <SelectItem value={PaymentSchedule.QUARTERLY}>Quarterly</SelectItem>
                    <SelectItem value={PaymentSchedule.CUSTOM}>Custom Installments</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Student Status</Label>
                <Select
                  value={status}
                  onValueChange={(v) => setStatus(v as 'ACTIVE' | 'INACTIVE' | 'ARCHIVED')}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ACTIVE">ACTIVE</SelectItem>
                    <SelectItem value="INACTIVE">INACTIVE</SelectItem>
                    <SelectItem value="ARCHIVED">ARCHIVED</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="stu-guardian">Parent / Guardian Name (Optional)</Label>
                <Input
                  id="stu-guardian"
                  value={guardianName}
                  onChange={(e) => setGuardianName(e.target.value)}
                  placeholder="Guardian full name"
                />
              </div>

              <div className="sm:col-span-2">
                <Label htmlFor="stu-phone">Guardian Contact Number (Optional)</Label>
                <Input
                  id="stu-phone"
                  value={guardianPhone}
                  onChange={(e) => setGuardianPhone(e.target.value)}
                  placeholder="+91 98XXXXXXXX"
                />
              </div>
            </div>

            {/* Optional Multi-Course Assignment */}
            {selectableCourses.length > 1 && (
              <div>
                <Label>Additional Enrolled Courses (Optional)</Label>
                <div className="flex flex-wrap gap-2 mt-1">
                  {selectableCourses
                    .filter((c) => c.id !== primaryCourseId)
                    .map((c) => {
                      const checked = extraCourseIds.includes(c.id);
                      return (
                        <button
                          key={c.id}
                          type="button"
                          onClick={() =>
                            setExtraCourseIds((prev) =>
                              checked ? prev.filter((id) => id !== c.id) : [...prev, c.id]
                            )
                          }
                          className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-colors cursor-pointer ${
                            checked
                              ? 'border-blue-600 bg-blue-50 text-blue-800'
                              : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                          }`}
                        >
                          {checked ? '✓ ' : '+ '}
                          {c.name}
                        </button>
                      );
                    })}
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100">
              <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? 'Saving...' : editingStudent ? 'Save Changes' : 'Complete Enrollment'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Student Confirmation */}
      <ConfirmDeleteDialog
        open={Boolean(deleteTargetStudent)}
        onOpenChange={(open) => !open && setDeleteTargetStudent(null)}
        title="Delete Student Record"
        description={
          deleteTargetStudent
            ? `Permanently delete "${deleteTargetStudent.fullName}" (${deleteTargetStudent.studentCode}) along with all linked course enrollments, invoices, fee payments, teacher share allocations, and performance reports? This action cannot be undone.`
            : ''
        }
        loading={submitting}
        onConfirm={handleConfirmDeleteStudent}
      />

      {/* Quick Bootstrap Modal */}
      <Dialog open={quickSetupOpen} onOpenChange={setQuickSetupOpen}>
        <DialogContent
          title="Quick Setup — First Course & Faculty"
          description="Creates your initial course and faculty record in Cloud Firestore."
        >
          <form onSubmit={handleQuickBootstrap} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Course Code</Label>
                <Input value={qsCourseCode} onChange={(e) => setQsCourseCode(e.target.value)} required />
              </div>
              <div>
                <Label>Monthly Fee (₹)</Label>
                <Input
                  type="number"
                  value={qsCourseFee}
                  onChange={(e) => setQsCourseFee(e.target.value)}
                  required
                />
              </div>
            </div>
            <div>
              <Label>Course Name</Label>
              <Input value={qsCourseName} onChange={(e) => setQsCourseName(e.target.value)} required />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Faculty Full Name</Label>
                <Input
                  value={qsTeacherName}
                  onChange={(e) => setQsTeacherName(e.target.value)}
                  placeholder="Dr. Ananya Verma"
                  required
                />
              </div>
              <div>
                <Label>Faculty Email</Label>
                <Input
                  type="email"
                  value={qsTeacherEmail}
                  onChange={(e) => setQsTeacherEmail(e.target.value)}
                  placeholder="faculty@iisinstitute.edu.in"
                  required
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-3">
              <Button type="button" variant="secondary" onClick={() => setQuickSetupOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? 'Creating...' : 'Create Records'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Page 3: Student Profiles (360° Student Dossier)
export function StudentProfilesPage({
  selectedStudentId,
  onSelectStudentId,
  onNavigate,
}: {
  selectedStudentId: string | null;
  onSelectStudentId: (id: string) => void;
  onNavigate: (page: NavPageId) => void;
}) {
  const {
    activeRole,
    students,
    courses,
    batches,
    teachers,
    enrollments,
    invoices,
    payments,
    reports,
    settings,
    updateStudent,
    deleteStudent,
    updateInvoice,
    deleteInvoice,
    updateFeePayment,
    deleteFeePayment,
    updateStudentReport,
    deleteStudentReport,
  } = useInstitute();

  const [submitting, setSubmitting] = useState(false);

  // Edit / Delete Student Profile State
  const [editStudentOpen, setEditStudentOpen] = useState(false);
  const [deleteStudentOpen, setDeleteStudentOpen] = useState(false);
  const [stuCode, setStuCode] = useState('');
  const [stuName, setStuName] = useState('');
  const [stuCourseId, setStuCourseId] = useState('');
  const [stuBatchId, setStuBatchId] = useState('');
  const [stuTeacherId, setStuTeacherId] = useState('');
  const [stuEnrollDate, setStuEnrollDate] = useState('');
  const [stuFeeRupees, setStuFeeRupees] = useState('');
  const [stuSchedule, setStuSchedule] = useState<PaymentSchedule>(PaymentSchedule.MONTHLY);
  const [stuStatus, setStuStatus] = useState<'ACTIVE' | 'INACTIVE' | 'ARCHIVED'>('ACTIVE');
  const [stuGuardian, setStuGuardian] = useState('');
  const [stuPhone, setStuPhone] = useState('');

  // Edit / Delete Invoice State
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  const [deleteTargetInvoice, setDeleteTargetInvoice] = useState<Invoice | null>(null);
  const [invCourseId, setInvCourseId] = useState('');
  const [invBillingPeriod, setInvBillingPeriod] = useState('');
  const [invGrossRupees, setInvGrossRupees] = useState('');
  const [invDiscountRupees, setInvDiscountRupees] = useState('0');
  const [invDueDate, setInvDueDate] = useState('');
  const [invNotes, setInvNotes] = useState('');
  const [invCancelled, setInvCancelled] = useState(false);

  // Edit / Delete Payment State
  const [editingPayment, setEditingPayment] = useState<Payment | null>(null);
  const [deleteTargetPayment, setDeleteTargetPayment] = useState<Payment | null>(null);
  const [payAmountRupees, setPayAmountRupees] = useState('');
  const [payMethod, setPayMethod] = useState<PaymentMethod>(PaymentMethod.UPI);
  const [payDate, setPayDate] = useState('');
  const [payRefNote, setPayRefNote] = useState('');
  const [payStatus, setPayStatus] = useState<PaymentStatus>(PaymentStatus.COMPLETED);
  const [payReversalReason, setPayReversalReason] = useState('');

  // Edit / Delete Report State
  const [editingReport, setEditingReport] = useState<StudentReport | null>(null);
  const [deleteTargetReport, setDeleteTargetReport] = useState<StudentReport | null>(null);
  const [repPeriod, setRepPeriod] = useState('');
  const [repSubject, setRepSubject] = useState('');
  const [repAttendance, setRepAttendance] = useState('90');
  const [repMarks, setRepMarks] = useState('80');
  const [repMaxMarks, setRepMaxMarks] = useState('100');
  const [repProgress, setRepProgress] = useState<AcademicProgress>(AcademicProgress.GOOD);
  const [repStrengths, setRepStrengths] = useState('');
  const [repImprove, setRepImprove] = useState('');
  const [repComments, setRepComments] = useState('');
  const [repDate, setRepDate] = useState('');

  const activeStudent = useMemo(() => {
    if (selectedStudentId) {
      const found = students.find((s) => s.id === selectedStudentId);
      if (found) return found;
    }
    return students[0] ?? null;
  }, [students, selectedStudentId]);

  if (!activeStudent) {
    return (
      <div className="space-y-6">
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Student Profiles</h1>
        <EmptyState
          title="No student profiles available"
          description="Enroll students first to inspect individual payment histories, outstanding fee ledgers, and academic performance trajectories."
          actionLabel={activeRole === UserRole.ADMIN ? 'Go to Students' : undefined}
          onAction={activeRole === UserRole.ADMIN ? () => onNavigate('students') : undefined}
        />
      </div>
    );
  }

  const openStudentEdit = () => {
    setStuCode(activeStudent.studentCode);
    setStuName(activeStudent.fullName);
    setStuCourseId(activeStudent.primaryCourseId);
    setStuBatchId(activeStudent.batchId);
    setStuTeacherId(activeStudent.assignedTeacherId);
    setStuEnrollDate(activeStudent.enrollmentDate);
    setStuFeeRupees(String(activeStudent.monthlyFeePaise / 100));
    setStuSchedule(activeStudent.paymentSchedule);
    setStuStatus(activeStudent.status);
    setStuGuardian(activeStudent.guardianName);
    setStuPhone(activeStudent.guardianPhone);
    setEditStudentOpen(true);
  };

  const handleSaveStudentProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const courseIds = Array.from(new Set([stuCourseId, ...activeStudent.courseIds].filter(Boolean)));
      await updateStudent(activeStudent.id, {
        studentCode: stuCode,
        fullName: stuName,
        primaryCourseId: stuCourseId,
        courseIds,
        batchId: stuBatchId,
        enrollmentDate: stuEnrollDate,
        monthlyFeeRupees: Number(stuFeeRupees),
        paymentSchedule: stuSchedule,
        status: stuStatus,
        guardianName: stuGuardian,
        guardianPhone: stuPhone,
        assignedTeacherId: stuTeacherId,
      });
      toast.success('Student profile updated');
      setEditStudentOpen(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to update profile');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteActiveStudent = async () => {
    setSubmitting(true);
    try {
      const nextStu = students.find((s) => s.id !== activeStudent.id);
      await deleteStudent(activeStudent.id);
      toast.success(`Deleted student ${activeStudent.fullName}`);
      setDeleteStudentOpen(false);
      if (nextStu) {
        onSelectStudentId(nextStu.id);
      } else {
        onNavigate('students');
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete student');
    } finally {
      setSubmitting(false);
    }
  };

  const openInvoiceEdit = (inv: Invoice) => {
    setEditingInvoice(inv);
    setInvCourseId(inv.courseId);
    setInvBillingPeriod(inv.billingPeriod);
    setInvGrossRupees(String(inv.grossAmountPaise / 100));
    setInvDiscountRupees(String(inv.discountPaise / 100));
    setInvDueDate(inv.dueDate);
    setInvNotes(inv.notes);
    setInvCancelled(inv.status === InvoiceStatus.CANCELLED);
  };

  const handleSaveInvoiceEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingInvoice) return;
    setSubmitting(true);
    try {
      await updateInvoice(editingInvoice.id, {
        courseId: invCourseId,
        billingPeriod: invBillingPeriod,
        grossAmountRupees: Number(invGrossRupees),
        discountRupees: Number(invDiscountRupees) || 0,
        dueDate: invDueDate,
        notes: invNotes,
        isCancelled: invCancelled,
      });
      toast.success('Invoice updated');
      setEditingInvoice(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to update invoice');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDeleteInvoice = async () => {
    if (!deleteTargetInvoice) return;
    setSubmitting(true);
    try {
      await deleteInvoice(deleteTargetInvoice.id);
      toast.success('Invoice deleted');
      setDeleteTargetInvoice(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete invoice');
    } finally {
      setSubmitting(false);
    }
  };

  const openPaymentEdit = (pay: Payment) => {
    setEditingPayment(pay);
    setPayAmountRupees(String(pay.amountPaise / 100));
    setPayMethod(pay.paymentMethod);
    setPayDate(pay.paymentDate);
    setPayRefNote(pay.referenceNote);
    setPayStatus(pay.status);
    setPayReversalReason(pay.reversalReason);
  };

  const handleSavePaymentEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPayment) return;
    setSubmitting(true);
    try {
      await updateFeePayment(editingPayment.id, {
        amountRupees: Number(payAmountRupees),
        paymentMethod: payMethod,
        paymentDate: payDate,
        referenceNote: payRefNote,
        status: payStatus,
        reversalReason: payReversalReason,
      });
      toast.success('Payment updated and invoice balance reconciled');
      setEditingPayment(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to update payment');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDeletePayment = async () => {
    if (!deleteTargetPayment) return;
    setSubmitting(true);
    try {
      await deleteFeePayment(deleteTargetPayment.id);
      toast.success('Payment deleted and invoice balance recalculated');
      setDeleteTargetPayment(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete payment');
    } finally {
      setSubmitting(false);
    }
  };

  const openReportEdit = (rep: StudentReport) => {
    setEditingReport(rep);
    setRepPeriod(rep.reportingPeriod);
    setRepSubject(rep.subject);
    setRepAttendance(String(rep.attendancePercent));
    setRepMarks(String(rep.testMarks));
    setRepMaxMarks(String(rep.maxMarks));
    setRepProgress(rep.academicProgress);
    setRepStrengths(rep.strengths);
    setRepImprove(rep.areasForImprovement);
    setRepComments(rep.teacherComments);
    setRepDate(rep.submissionDate);
  };

  const handleSaveReportEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingReport) return;
    setSubmitting(true);
    try {
      await updateStudentReport(editingReport.id, {
        studentId: editingReport.studentId,
        reportingPeriod: repPeriod,
        subject: repSubject.trim(),
        attendancePercent: Math.round(Number(repAttendance)),
        testMarks: Math.round(Number(repMarks)),
        maxMarks: Math.round(Number(repMaxMarks)),
        academicProgress: repProgress,
        strengths: repStrengths.trim(),
        areasForImprovement: repImprove.trim(),
        teacherComments: repComments.trim(),
        submissionDate: repDate,
      });
      toast.success('Performance report updated');
      setEditingReport(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to update report');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDeleteReport = async () => {
    if (!deleteTargetReport) return;
    setSubmitting(true);
    try {
      await deleteStudentReport(deleteTargetReport.id);
      toast.success('Performance report deleted');
      setDeleteTargetReport(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete report');
    } finally {
      setSubmitting(false);
    }
  };

  const stuEnrollments = enrollments.filter((e) => e.studentId === activeStudent.id);
  const stuInvoices = invoices
    .filter((i) => i.studentId === activeStudent.id)
    .sort((a, b) => b.billingPeriod.localeCompare(a.billingPeriod));
  const stuPayments = payments
    .filter((p) => p.studentId === activeStudent.id)
    .sort((a, b) => b.paymentDate.localeCompare(a.paymentDate));
  const stuReports = reports
    .filter((r) => r.studentId === activeStudent.id)
    .sort((a, b) => a.reportingPeriod.localeCompare(b.reportingPeriod));

  const totalBilledPaise = stuInvoices
    .filter((i) => i.status !== InvoiceStatus.CANCELLED)
    .reduce((s, i) => s + i.netAmountDuePaise, 0);
  const totalPaidPaise = stuPayments
    .filter((p) => p.status === PaymentStatus.COMPLETED)
    .reduce((s, p) => s + p.amountPaise, 0);
  const totalPendingPaise = stuInvoices
    .filter((i) => i.status !== InvoiceStatus.CANCELLED)
    .reduce((s, i) => s + i.balanceDuePaise, 0);

  const reportChartData = stuReports.map((r) => ({
    period: r.reportingPeriod,
    scorePct: Math.round((r.testMarks / Math.max(1, r.maxMarks)) * 100),
    attendance: r.attendancePercent,
  }));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Button variant="secondary" size="sm" onClick={() => onNavigate('students')}>
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>Roster</span>
          </Button>
          <div>
            <p className="text-xs text-slate-500">
              {activeStudent.studentCode} · Enrolled {activeStudent.enrollmentDate}
            </p>
            <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              {activeStudent.fullName}
            </h1>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {activeRole === UserRole.ADMIN && (
            <>
              <Button variant="secondary" size="sm" onClick={openStudentEdit}>
                <Edit2 className="h-3.5 w-3.5" />
                <span>Edit Student</span>
              </Button>
              <Button
                variant="outlineDanger"
                size="sm"
                onClick={() => setDeleteStudentOpen(true)}
              >
                <Trash2 className="h-3.5 w-3.5" />
                <span>Delete</span>
              </Button>
            </>
          )}
          <div className="w-64">
            <Select value={activeStudent.id} onValueChange={onSelectStudentId}>
              <SelectTrigger>
                <SelectValue placeholder="Switch student" />
              </SelectTrigger>
              <SelectContent>
                {students.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.fullName} ({s.studentCode})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Summary Metadata Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="text-xs text-slate-500">Course & Batch</div>
          <div className="text-sm font-bold text-slate-900 mt-1.5">
            {activeStudent.primaryCourseName}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            {activeStudent.batchName} · {activeStudent.assignedTeacherName}
          </div>
          {stuEnrollments.length > 1 && (
            <div className="text-[11px] text-blue-700 mt-1.5 font-medium">
              Enrolled in {stuEnrollments.length} active courses
            </div>
          )}
        </div>

        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="text-xs text-slate-500">Guardian & Schedule</div>
          <div className="text-sm font-bold text-slate-900 mt-1.5">
            {activeStudent.guardianName || 'No guardian listed'}
          </div>
          <div className="text-xs text-slate-500 mt-1 font-mono">
            {activeStudent.guardianPhone || 'No phone'} · {activeStudent.paymentSchedule}
          </div>
        </div>

        {activeRole !== UserRole.TEACHER ? (
          <>
            <div className="bg-white border border-slate-200/90 rounded-xl p-5">
              <div className="text-xs text-slate-500">Cumulative Paid</div>
              <div className="text-2xl font-extrabold font-mono tabular-nums text-emerald-700 mt-1.5">
                {formatINR(totalPaidPaise)}
              </div>
              <div className="text-xs text-slate-500 mt-1 font-mono">
                Of {formatINR(totalBilledPaise)} net billed
              </div>
            </div>

            <div className="bg-white border border-slate-200/90 rounded-xl p-5">
              <div className="text-xs text-slate-500">Current Outstanding Fee</div>
              <div
                className={`text-2xl font-extrabold font-mono tabular-nums mt-1.5 ${
                  totalPendingPaise > 0 ? 'text-amber-700' : 'text-slate-900'
                }`}
              >
                {formatINR(totalPendingPaise)}
              </div>
              <div className="text-xs text-slate-500 mt-1 font-mono">
                Standard fee: {formatINR(activeStudent.monthlyFeePaise)}/mo
              </div>
            </div>
          </>
        ) : (
          <div className="md:col-span-2 bg-white border border-slate-200/90 rounded-xl p-5">
            <div className="text-xs text-slate-500">Academic Evaluations Submitted</div>
            <div className="text-2xl font-extrabold font-mono tabular-nums text-slate-900 mt-1.5">
              {stuReports.length} Reports
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Latest status: {activeStudent.status}
            </div>
          </div>
        )}
      </div>

      {/* Invoices & Payment History (Finance Staff Only) */}
      {activeRole !== UserRole.TEACHER && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-6 bg-white border border-slate-200/90 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-bold text-slate-900">Invoices & Outstanding Balances</h2>
              <Button variant="ghost" size="sm" onClick={() => onNavigate('fee-collection')}>
                Collect Fee
              </Button>
            </div>
            {stuInvoices.length === 0 ? (
              <EmptyState
                title="No invoices issued"
                description="Create an invoice in Fee Collection to track monthly tuition."
              />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500 font-semibold">
                      <th className="py-2 pr-2">Period</th>
                      <th className="py-2 px-2 text-right">Net Due</th>
                      <th className="py-2 px-2 text-right">Paid</th>
                      <th className="py-2 px-2 text-right">Balance</th>
                      <th className="py-2 px-2">Status</th>
                      <th className="py-2 pl-2 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-mono tabular-nums">
                    {stuInvoices.map((inv) => (
                      <tr key={inv.id}>
                        <td className="py-2.5 pr-2 font-sans font-medium text-slate-800">
                          {inv.billingPeriod}
                        </td>
                        <td className="py-2.5 px-2 text-right">{formatINR(inv.netAmountDuePaise)}</td>
                        <td className="py-2.5 px-2 text-right text-emerald-700">
                          {formatINR(inv.paidAmountPaise)}
                        </td>
                        <td className="py-2.5 px-2 text-right font-semibold">
                          {formatINR(inv.balanceDuePaise)}
                        </td>
                        <td className="py-2.5 px-2 font-sans">
                          <StatusText
                            tone={
                              inv.status === InvoiceStatus.PAID
                                ? 'positive'
                                : inv.status === InvoiceStatus.CANCELLED
                                ? 'neutral'
                                : inv.status === InvoiceStatus.OVERDUE
                                ? 'danger'
                                : 'warning'
                            }
                            label={inv.status}
                          />
                        </td>
                        <td className="py-2.5 pl-2 text-right font-sans whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => openInvoiceEdit(inv)}
                              title="Edit invoice"
                              className="p-1 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                            >
                              <Edit2 className="h-3.5 w-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeleteTargetInvoice(inv)}
                              title="Delete invoice"
                              className="p-1 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          <div className="lg:col-span-6 bg-white border border-slate-200/90 rounded-xl p-6">
            <h2 className="text-base font-bold text-slate-900 mb-4">Payment Receipt History</h2>
            {stuPayments.length === 0 ? (
              <EmptyState
                title="No payments recorded"
                description="Verified Cash, UPI, and Bank Transfer payments will appear here."
              />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs text-left">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500 font-semibold">
                      <th className="py-2 pr-2">Receipt</th>
                      <th className="py-2 px-2">Date · Mode</th>
                      <th className="py-2 px-2 text-right">Amount</th>
                      <th className="py-2 pl-2 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {stuPayments.map((pay) => (
                      <tr key={pay.id}>
                        <td className="py-2.5 pr-2 font-mono text-slate-700">{pay.receiptNumber}</td>
                        <td className="py-2.5 px-2 font-mono text-slate-600">
                          {pay.paymentDate} · {pay.paymentMethod === PaymentMethod.BANK_TRANSFER ? 'BANK' : pay.paymentMethod}
                        </td>
                        <td className="py-2.5 px-2 text-right font-mono tabular-nums font-semibold">
                          {pay.status === PaymentStatus.REVERSED ? (
                            <span className="line-through text-slate-400">
                              {formatINR(pay.amountPaise)}
                            </span>
                          ) : (
                            formatINR(pay.amountPaise)
                          )}
                        </td>
                        <td className="py-2.5 pl-2 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() =>
                                generatePaymentReceiptPDF({
                                  payment: pay,
                                  invoice: invoices.find((i) => i.id === pay.invoiceId),
                                  settings,
                                })
                              }
                              className="inline-flex items-center gap-1 text-blue-600 hover:underline font-semibold cursor-pointer mr-1"
                            >
                              <Download className="h-3.5 w-3.5" />
                              <span>PDF</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => openPaymentEdit(pay)}
                              title="Edit payment"
                              className="p-1 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                            >
                              <Edit2 className="h-3.5 w-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeleteTargetPayment(pay)}
                              title="Delete payment"
                              className="p-1 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Academic Performance Trajectory & Teacher Reports */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-6 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Teacher Performance Reports & Score Progression
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Test score percentage and attendance recorded by assigned faculty
            </p>
          </div>
          {(activeRole === UserRole.ADMIN || activeRole === UserRole.TEACHER) && (
            <Button variant="secondary" size="sm" onClick={() => onNavigate('performance-reports')}>
              Submit Evaluation
            </Button>
          )}
        </div>

        {stuReports.length === 0 ? (
          <EmptyState
            title="No academic performance reports yet"
            description="Assigned teachers can submit monthly test marks, attendance, strengths, and improvement plans."
          />
        ) : (
          <>
            {reportChartData.length > 0 && (
              <div className="h-56 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={reportChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis dataKey="period" tick={{ fontSize: 11, fill: '#64748b' }} />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#64748b' }} unit="%" />
                    <Tooltip />
                    <Line
                      type="monotone"
                      dataKey="scorePct"
                      name="Test Score %"
                      stroke="#2563eb"
                      strokeWidth={2.4}
                    />
                    <Line
                      type="monotone"
                      dataKey="attendance"
                      name="Attendance %"
                      stroke="#0d9488"
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}

            <div className="space-y-3">
              {[...stuReports].reverse().map((rep) => (
                <div
                  key={rep.id}
                  className="p-4 rounded-xl border border-slate-200/80 bg-slate-50/40 space-y-2"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="font-bold text-sm text-slate-900">
                      {rep.subject} · {rep.reportingPeriod}
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-xs font-mono tabular-nums text-slate-700">
                        Marks: <strong>{rep.testMarks}/{rep.maxMarks}</strong> (
                        {Math.round((rep.testMarks / Math.max(1, rep.maxMarks)) * 100)}%) · Attendance:{' '}
                        <strong>{rep.attendancePercent}%</strong> · {rep.academicProgress.replace('_', ' ')}
                      </div>
                      {(activeRole === UserRole.ADMIN || activeRole === UserRole.TEACHER) && (
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => openReportEdit(rep)}
                            title="Edit report"
                            className="p-1 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-200/70 cursor-pointer"
                          >
                            <Edit2 className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteTargetReport(rep)}
                            title="Delete report"
                            className="p-1 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-slate-600">
                    <div>
                      <span className="font-semibold text-slate-800">Strengths: </span>
                      {rep.strengths || '—'}
                    </div>
                    <div>
                      <span className="font-semibold text-slate-800">Areas for Improvement: </span>
                      {rep.areasForImprovement || '—'}
                    </div>
                  </div>
                  {rep.teacherComments && (
                    <p className="text-xs text-slate-600 pt-1 border-t border-slate-200/60">
                      <span className="font-semibold text-slate-800">
                        {rep.teacherName} ({rep.submissionDate}):{' '}
                      </span>
                      {rep.teacherComments}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Edit Student Profile Dialog */}
      <Dialog open={editStudentOpen} onOpenChange={setEditStudentOpen}>
        <DialogContent
          title="Edit Student Profile"
          description="Update enrollment details, monthly tuition, schedule, or status."
          maxWidthClass="max-w-2xl"
        >
          <form onSubmit={handleSaveStudentProfile} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label>Student ID</Label>
                <Input value={stuCode} onChange={(e) => setStuCode(e.target.value)} required />
              </div>
              <div>
                <Label>Full Name</Label>
                <Input value={stuName} onChange={(e) => setStuName(e.target.value)} required />
              </div>
              <div>
                <Label>Primary Course</Label>
                <Select value={stuCourseId} onValueChange={setStuCourseId}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {courses.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Batch</Label>
                <Select value={stuBatchId} onValueChange={setStuBatchId}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {batches.map((b) => (
                      <SelectItem key={b.id} value={b.id}>
                        {b.name} ({b.code})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Assigned Teacher</Label>
                <Select value={stuTeacherId} onValueChange={setStuTeacherId}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {teachers.map((t) => (
                      <SelectItem key={t.id} value={t.id}>
                        {t.fullName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Enrollment Date</Label>
                <Input
                  type="date"
                  value={stuEnrollDate}
                  onChange={(e) => setStuEnrollDate(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Monthly Fee (₹)</Label>
                <Input
                  type="number"
                  min={0}
                  value={stuFeeRupees}
                  onChange={(e) => setStuFeeRupees(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Payment Schedule</Label>
                <Select
                  value={stuSchedule}
                  onValueChange={(v) => setStuSchedule(v as PaymentSchedule)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={PaymentSchedule.MONTHLY}>Monthly</SelectItem>
                    <SelectItem value={PaymentSchedule.QUARTERLY}>Quarterly</SelectItem>
                    <SelectItem value={PaymentSchedule.CUSTOM}>Custom Installments</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Status</Label>
                <Select
                  value={stuStatus}
                  onValueChange={(v) => setStuStatus(v as 'ACTIVE' | 'INACTIVE' | 'ARCHIVED')}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ACTIVE">ACTIVE</SelectItem>
                    <SelectItem value="INACTIVE">INACTIVE</SelectItem>
                    <SelectItem value="ARCHIVED">ARCHIVED</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Guardian Name</Label>
                <Input value={stuGuardian} onChange={(e) => setStuGuardian(e.target.value)} />
              </div>
              <div className="sm:col-span-2">
                <Label>Guardian Phone</Label>
                <Input value={stuPhone} onChange={(e) => setStuPhone(e.target.value)} />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <Button type="button" variant="secondary" onClick={() => setEditStudentOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? 'Saving...' : 'Save Changes'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Invoice Dialog */}
      <Dialog open={Boolean(editingInvoice)} onOpenChange={(o) => !o && setEditingInvoice(null)}>
        <DialogContent
          title="Edit Student Invoice"
          description="Updates gross tuition, discount, due date, or cancellation state and reconciles balance."
        >
          <form onSubmit={handleSaveInvoiceEdit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Course</Label>
                <Select value={invCourseId} onValueChange={setInvCourseId}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {courses.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Billing Period (YYYY-MM)</Label>
                <Input
                  type="month"
                  value={invBillingPeriod}
                  onChange={(e) => setInvBillingPeriod(e.target.value)}
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Gross Amount (₹)</Label>
                <Input
                  type="number"
                  min={0}
                  step="1"
                  value={invGrossRupees}
                  onChange={(e) => setInvGrossRupees(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Discount (₹)</Label>
                <Input
                  type="number"
                  min={0}
                  step="1"
                  value={invDiscountRupees}
                  onChange={(e) => setInvDiscountRupees(e.target.value)}
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3 items-center">
              <div>
                <Label>Due Date</Label>
                <Input
                  type="date"
                  value={invDueDate}
                  onChange={(e) => setInvDueDate(e.target.value)}
                  required
                />
              </div>
              <div className="flex items-center gap-2.5 pt-5">
                <Switch checked={invCancelled} onCheckedChange={setInvCancelled} />
                <span className="text-xs font-semibold text-slate-700">Mark Invoice Cancelled</span>
              </div>
            </div>
            <div>
              <Label>Notes</Label>
              <Input value={invNotes} onChange={(e) => setInvNotes(e.target.value)} />
            </div>
            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <Button type="button" variant="secondary" onClick={() => setEditingInvoice(null)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? 'Saving...' : 'Save Invoice'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Payment Dialog */}
      <Dialog open={Boolean(editingPayment)} onOpenChange={(o) => !o && setEditingPayment(null)}>
        <DialogContent
          title="Edit Fee Payment Receipt"
          description="Atomically updates receipt details, linked invoice balance, and accrued teacher share."
        >
          <form onSubmit={handleSavePaymentEdit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Amount (INR ₹)</Label>
                <Input
                  type="number"
                  min="1"
                  step="0.01"
                  value={payAmountRupees}
                  onChange={(e) => setPayAmountRupees(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Payment Method</Label>
                <Select value={payMethod} onValueChange={(v) => setPayMethod(v as PaymentMethod)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={PaymentMethod.UPI}>UPI</SelectItem>
                    <SelectItem value={PaymentMethod.CASH}>Cash</SelectItem>
                    <SelectItem value={PaymentMethod.BANK_TRANSFER}>Bank Transfer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Payment Date</Label>
                <Input
                  type="date"
                  value={payDate}
                  onChange={(e) => setPayDate(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Status</Label>
                <Select value={payStatus} onValueChange={(v) => setPayStatus(v as PaymentStatus)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={PaymentStatus.COMPLETED}>COMPLETED</SelectItem>
                    <SelectItem value={PaymentStatus.REVERSED}>REVERSED</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>Reference Note</Label>
              <Input value={payRefNote} onChange={(e) => setPayRefNote(e.target.value)} />
            </div>
            {payStatus === PaymentStatus.REVERSED && (
              <div>
                <Label>Reversal Reason</Label>
                <Input
                  value={payReversalReason}
                  onChange={(e) => setPayReversalReason(e.target.value)}
                />
              </div>
            )}
            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <Button type="button" variant="secondary" onClick={() => setEditingPayment(null)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? 'Updating...' : 'Save Payment'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Performance Report Dialog */}
      <Dialog open={Boolean(editingReport)} onOpenChange={(o) => !o && setEditingReport(null)}>
        <DialogContent
          title="Edit Performance Report"
          description="Update subject marks, attendance, progress standing, or comments."
          maxWidthClass="max-w-2xl"
        >
          <form onSubmit={handleSaveReportEdit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <Label>Reporting Period (YYYY-MM)</Label>
                <Input
                  type="month"
                  value={repPeriod}
                  onChange={(e) => setRepPeriod(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Subject</Label>
                <Input
                  value={repSubject}
                  onChange={(e) => setRepSubject(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Academic Standing</Label>
                <Select
                  value={repProgress}
                  onValueChange={(v) => setRepProgress(v as AcademicProgress)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={AcademicProgress.EXCELLENT}>Excellent</SelectItem>
                    <SelectItem value={AcademicProgress.GOOD}>Good</SelectItem>
                    <SelectItem value={AcademicProgress.SATISFACTORY}>Satisfactory</SelectItem>
                    <SelectItem value={AcademicProgress.NEEDS_ATTENTION}>Needs Attention</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div>
                <Label>Attendance (%)</Label>
                <Input
                  type="number"
                  min={0}
                  max={100}
                  value={repAttendance}
                  onChange={(e) => setRepAttendance(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Test Marks</Label>
                <Input
                  type="number"
                  min={0}
                  value={repMarks}
                  onChange={(e) => setRepMarks(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Max Marks</Label>
                <Input
                  type="number"
                  min={1}
                  value={repMaxMarks}
                  onChange={(e) => setRepMaxMarks(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Submission Date</Label>
                <Input
                  type="date"
                  value={repDate}
                  onChange={(e) => setRepDate(e.target.value)}
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <Label>Strengths</Label>
                <Textarea
                  value={repStrengths}
                  onChange={(e) => setRepStrengths(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Areas for Improvement</Label>
                <Textarea
                  value={repImprove}
                  onChange={(e) => setRepImprove(e.target.value)}
                  required
                />
              </div>
            </div>
            <div>
              <Label>Teacher Comments</Label>
              <Textarea value={repComments} onChange={(e) => setRepComments(e.target.value)} />
            </div>
            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <Button type="button" variant="secondary" onClick={() => setEditingReport(null)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? 'Saving...' : 'Update Report'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmations on Student Profile */}
      <ConfirmDeleteDialog
        open={deleteStudentOpen}
        onOpenChange={setDeleteStudentOpen}
        title="Delete Student Profile"
        description={`Permanently delete "${activeStudent.fullName}" (${activeStudent.studentCode}) along with all linked enrollments, invoices, payments, teacher share allocations, and academic reports?`}
        loading={submitting}
        onConfirm={handleDeleteActiveStudent}
      />

      <ConfirmDeleteDialog
        open={Boolean(deleteTargetInvoice)}
        onOpenChange={(o) => !o && setDeleteTargetInvoice(null)}
        title="Delete Invoice"
        description={
          deleteTargetInvoice
            ? `Permanently delete invoice ${deleteTargetInvoice.invoiceNumber} (${deleteTargetInvoice.billingPeriod}) and any linked fee receipts and teacher share allocations?`
            : ''
        }
        loading={submitting}
        onConfirm={handleConfirmDeleteInvoice}
      />

      <ConfirmDeleteDialog
        open={Boolean(deleteTargetPayment)}
        onOpenChange={(o) => !o && setDeleteTargetPayment(null)}
        title="Delete Payment Receipt"
        description={
          deleteTargetPayment
            ? `Permanently delete receipt ${deleteTargetPayment.receiptNumber} (${formatINR(deleteTargetPayment.amountPaise)})? The linked invoice balance and teacher share allocation will be recalculated automatically.`
            : ''
        }
        loading={submitting}
        onConfirm={handleConfirmDeletePayment}
      />

      <ConfirmDeleteDialog
        open={Boolean(deleteTargetReport)}
        onOpenChange={(o) => !o && setDeleteTargetReport(null)}
        title="Delete Performance Report"
        description={
          deleteTargetReport
            ? `Permanently delete the ${deleteTargetReport.subject} evaluation (${deleteTargetReport.reportingPeriod}) for ${deleteTargetReport.studentName}?`
            : ''
        }
        loading={submitting}
        onConfirm={handleConfirmDeleteReport}
      />
    </div>
  );
}
