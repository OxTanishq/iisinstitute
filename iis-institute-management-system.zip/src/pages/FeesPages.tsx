import React, { useMemo, useState } from 'react';
import {
  Plus,
  Download,
  RotateCcw,
  Search,
  Sparkles,
  ShieldAlert,
  Edit2,
  Trash2,
} from 'lucide-react';
import { toast } from 'sonner';
import { useInstitute } from '../context/InstituteContext';
import {
  Invoice,
  InvoiceStatus,
  Payment,
  PaymentMethod,
  PaymentStatus,
  UserRole,
} from '../shared/types';
import {
  calculatePaymentTeacherShare,
  findEffectiveAgreement,
  formatINR,
  formatPeriodLabel,
  getTodayIST,
  toPaise,
} from '../shared/finance';
import { generateCleanId } from '../lib/firebase';
import { downloadServerCSV, generatePaymentReceiptPDF } from '../lib/pdfExport';
import {
  Button,
  ConfirmDeleteDialog,
  Dialog,
  DialogContent,
  EmptyState,
  Input,
  Label,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  StatusText,
  Switch,
} from '../components/ui/primitives';

export function RestrictedFinanceNotice() {
  return (
    <div className="bg-white border border-slate-200 rounded-xl p-10 text-center max-w-lg mx-auto my-10">
      <ShieldAlert className="h-8 w-8 text-amber-600 mx-auto mb-3" />
      <h2 className="text-lg font-bold text-slate-900">Restricted Financial Ledger</h2>
      <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
        Institute-wide fee collections, invoices, and operating expenses are restricted to
        Administrators and authorized Accountants. Faculty members can view their personal payout
        statements under <strong>Teacher Payouts</strong>.
      </p>
    </div>
  );
}

// Page 4: Fee Collection
export function FeeCollectionPage({
  preselectedInvoiceId,
  onClearPreselectedInvoice,
}: {
  preselectedInvoiceId: string | null;
  onClearPreselectedInvoice: () => void;
}) {
  const {
    activeRole,
    selectedPeriod,
    settings,
    students,
    courses,
    invoices,
    payments,
    agreements,
    allocations,
    createInvoice,
    updateInvoice,
    deleteInvoice,
    generateMonthlyInvoicesForActiveStudents,
    recordFeePayment,
    updateFeePayment,
    reverseFeePayment,
    deleteFeePayment,
  } = useInstitute();

  const [searchTerm, setSearchTerm] = useState('');
  const [invoiceModalOpen, setInvoiceModalOpen] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  const [deleteTargetInvoice, setDeleteTargetInvoice] = useState<Invoice | null>(null);

  const [payModalOpen, setPayModalOpen] = useState(Boolean(preselectedInvoiceId));
  const [editingPayment, setEditingPayment] = useState<Payment | null>(null);
  const [deleteTargetPayment, setDeleteTargetPayment] = useState<Payment | null>(null);
  const [reverseModalPaymentId, setReverseModalPaymentId] = useState<string | null>(null);
  const [reversalReason, setReversalReason] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Create / Edit Invoice Form State
  const [invStudentId, setInvStudentId] = useState('');
  const [invCourseId, setInvCourseId] = useState('');
  const [invBillingPeriod, setInvBillingPeriod] = useState(selectedPeriod);
  const [invGrossRupees, setInvGrossRupees] = useState('2500');
  const [invDiscountRupees, setInvDiscountRupees] = useState('0');
  const [invDueDate, setInvDueDate] = useState(`${selectedPeriod}-10`);
  const [invNotes, setInvNotes] = useState('');
  const [invCancelled, setInvCancelled] = useState(false);

  // Collect Payment Form State
  const [payInvoiceId, setPayInvoiceId] = useState(preselectedInvoiceId ?? '');
  const [payAmountRupees, setPayAmountRupees] = useState('');
  const [payMethod, setPayMethod] = useState<PaymentMethod>(PaymentMethod.UPI);
  const [payDate, setPayDate] = useState(getTodayIST());
  const [payRefNote, setPayRefNote] = useState('');
  const [idempotencyKey, setIdempotencyKey] = useState(() => generateCleanId('idem'));

  // Edit Payment Form State
  const [editPayAmountRupees, setEditPayAmountRupees] = useState('');
  const [editPayMethod, setEditPayMethod] = useState<PaymentMethod>(PaymentMethod.UPI);
  const [editPayDate, setEditPayDate] = useState(getTodayIST());
  const [editPayRefNote, setEditPayRefNote] = useState('');
  const [editPayStatus, setEditPayStatus] = useState<PaymentStatus>(PaymentStatus.COMPLETED);
  const [editPayReversalReason, setEditPayReversalReason] = useState('');

  React.useEffect(() => {
    if (preselectedInvoiceId) {
      const inv = invoices.find((i) => i.id === preselectedInvoiceId);
      if (inv) {
        setPayInvoiceId(inv.id);
        setPayAmountRupees(String(inv.balanceDuePaise / 100));
        setIdempotencyKey(generateCleanId('idem'));
        setPayModalOpen(true);
      }
      onClearPreselectedInvoice();
    }
  }, [preselectedInvoiceId, invoices, onClearPreselectedInvoice]);

  if (activeRole === UserRole.TEACHER) {
    return <RestrictedFinanceNotice />;
  }

  const unpaidInvoices = invoices.filter(
    (i) => i.status !== InvoiceStatus.PAID && i.status !== InvoiceStatus.CANCELLED && i.balanceDuePaise > 0
  );

  const selectedInvoiceObj: Invoice | undefined = invoices.find((i) => i.id === payInvoiceId);

  // Live preview of teacher share & post-payment invoice status
  const paymentPreview = useMemo(() => {
    if (!selectedInvoiceObj) return null;
    const enteredPaise = toPaise(Number(payAmountRupees) || 0);
    const remainingAfter = Math.max(0, selectedInvoiceObj.balanceDuePaise - enteredPaise);
    const effAg = selectedInvoiceObj.assignedTeacherId
      ? findEffectiveAgreement(agreements, selectedInvoiceObj.assignedTeacherId, payDate)
      : null;
    const existingAllocCount = allocations.filter(
      (a) =>
        a.teacherId === selectedInvoiceObj.assignedTeacherId &&
        a.studentId === selectedInvoiceObj.studentId &&
        a.billingPeriod === selectedInvoiceObj.billingPeriod
    ).length;
    const shareCalc = calculatePaymentTeacherShare(enteredPaise, effAg, existingAllocCount);
    return {
      enteredPaise,
      remainingAfter,
      willBeFullyPaid: enteredPaise >= selectedInvoiceObj.balanceDuePaise && enteredPaise > 0,
      shareCalc,
      teacherName: effAg?.teacherName ?? 'Assigned Teacher',
    };
  }, [selectedInvoiceObj, payAmountRupees, agreements, allocations, payDate]);

  const openCollectModal = (inv?: Invoice) => {
    const target = inv ?? unpaidInvoices[0];
    setPayInvoiceId(target?.id ?? '');
    setPayAmountRupees(target ? String(target.balanceDuePaise / 100) : '');
    setPayMethod(PaymentMethod.UPI);
    setPayDate(getTodayIST());
    setPayRefNote('');
    setIdempotencyKey(generateCleanId('idem'));
    setPayModalOpen(true);
  };

  const openNewInvoiceModal = () => {
    setEditingInvoice(null);
    const firstStu = students.find((s) => s.status === 'ACTIVE') ?? students[0];
    setInvStudentId(firstStu?.id ?? '');
    setInvCourseId(firstStu?.primaryCourseId ?? courses[0]?.id ?? '');
    setInvBillingPeriod(selectedPeriod);
    setInvGrossRupees(firstStu ? String(firstStu.monthlyFeePaise / 100) : '2500');
    setInvDiscountRupees('0');
    const dd = String(settings.defaultDueDay || 10).padStart(2, '0');
    setInvDueDate(`${selectedPeriod}-${dd}`);
    setInvNotes('');
    setInvCancelled(false);
    setInvoiceModalOpen(true);
  };

  const openEditInvoiceModal = (inv: Invoice) => {
    setEditingInvoice(inv);
    setInvStudentId(inv.studentId);
    setInvCourseId(inv.courseId);
    setInvBillingPeriod(inv.billingPeriod);
    setInvGrossRupees(String(inv.grossAmountPaise / 100));
    setInvDiscountRupees(String(inv.discountPaise / 100));
    setInvDueDate(inv.dueDate);
    setInvNotes(inv.notes);
    setInvCancelled(inv.status === InvoiceStatus.CANCELLED);
    setInvoiceModalOpen(true);
  };

  const handleSaveInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      if (editingInvoice) {
        await updateInvoice(editingInvoice.id, {
          courseId: invCourseId,
          billingPeriod: invBillingPeriod,
          grossAmountRupees: Number(invGrossRupees),
          discountRupees: Number(invDiscountRupees) || 0,
          dueDate: invDueDate,
          notes: invNotes,
          isCancelled: invCancelled,
        });
        toast.success(`Invoice ${editingInvoice.invoiceNumber} updated`);
      } else {
        await createInvoice({
          studentId: invStudentId,
          courseId: invCourseId,
          billingPeriod: invBillingPeriod,
          grossAmountRupees: Number(invGrossRupees),
          discountRupees: Number(invDiscountRupees) || 0,
          dueDate: invDueDate,
          notes: invNotes,
        });
        toast.success('Invoice issued');
      }
      setInvoiceModalOpen(false);
      setEditingInvoice(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to save invoice');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDeleteInvoice = async () => {
    if (!deleteTargetInvoice) return;
    setSubmitting(true);
    try {
      await deleteInvoice(deleteTargetInvoice.id);
      toast.success(`Deleted invoice ${deleteTargetInvoice.invoiceNumber}`);
      setDeleteTargetInvoice(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete invoice');
    } finally {
      setSubmitting(false);
    }
  };

  const handleBulkGenerateInvoices = async () => {
    setSubmitting(true);
    try {
      const count = await generateMonthlyInvoicesForActiveStudents(selectedPeriod);
      if (count === 0) {
        toast.info(`All active students are already billed for ${formatPeriodLabel(selectedPeriod)}.`);
      } else {
        toast.success(`Generated ${count} monthly invoices for ${formatPeriodLabel(selectedPeriod)}.`);
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Batch billing failed');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRecordPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const created = await recordFeePayment({
        invoiceId: payInvoiceId,
        idempotencyKey,
        amountRupees: Number(payAmountRupees),
        paymentMethod: payMethod,
        paymentDate: payDate,
        referenceNote: payRefNote,
      });
      toast.success(`Receipt ${created.receiptNumber} recorded atomically`);
      setPayModalOpen(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Payment submission failed');
    } finally {
      setSubmitting(false);
    }
  };

  const openEditPaymentModal = (pay: Payment) => {
    setEditingPayment(pay);
    setEditPayAmountRupees(String(pay.amountPaise / 100));
    setEditPayMethod(pay.paymentMethod);
    setEditPayDate(pay.paymentDate);
    setEditPayRefNote(pay.referenceNote);
    setEditPayStatus(pay.status);
    setEditPayReversalReason(pay.reversalReason);
  };

  const handleSavePaymentEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPayment) return;
    setSubmitting(true);
    try {
      await updateFeePayment(editingPayment.id, {
        amountRupees: Number(editPayAmountRupees),
        paymentMethod: editPayMethod,
        paymentDate: editPayDate,
        referenceNote: editPayRefNote,
        status: editPayStatus,
        reversalReason: editPayReversalReason,
      });
      toast.success(`Updated receipt ${editingPayment.receiptNumber}`);
      setEditingPayment(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to update payment');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDeletePayment = async () => {
    if (!deleteTargetPayment) return;
    setSubmitting(true);
    try {
      await deleteFeePayment(deleteTargetPayment.id);
      toast.success(`Deleted receipt ${deleteTargetPayment.receiptNumber} and recalculated invoice`);
      setDeleteTargetPayment(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete payment');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmReversal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reverseModalPaymentId) return;
    setSubmitting(true);
    try {
      await reverseFeePayment(reverseModalPaymentId, reversalReason || 'Administrative reversal');
      toast.success('Payment reversed and invoice balance restored');
      setReverseModalPaymentId(null);
      setReversalReason('');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Reversal failed');
    } finally {
      setSubmitting(false);
    }
  };

  const filteredInvoices = invoices.filter((inv) => {
    if (inv.billingPeriod !== selectedPeriod) return false;
    if (!searchTerm.trim()) return true;
    const q = searchTerm.toLowerCase();
    return (
      inv.studentName.toLowerCase().includes(q) ||
      inv.invoiceNumber.toLowerCase().includes(q) ||
      inv.courseName.toLowerCase().includes(q)
    );
  });

  const filteredPayments = payments.filter((p) => {
    if (!searchTerm.trim()) return true;
    const q = searchTerm.toLowerCase();
    return (
      p.studentName.toLowerCase().includes(q) ||
      p.receiptNumber.toLowerCase().includes(q) ||
      p.courseName.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-blue-600 mb-1">
            Atomic Tuition Billing & Receipts · {formatPeriodLabel(selectedPeriod)}
          </p>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Fee Collection</h1>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <Button
            variant="secondary"
            size="sm"
            disabled={submitting || students.length === 0}
            onClick={handleBulkGenerateInvoices}
          >
            <Sparkles className="h-3.5 w-3.5 text-blue-600" />
            <span>Issue {formatPeriodLabel(selectedPeriod)} Batch Invoices</span>
          </Button>
          <Button
            variant="secondary"
            size="sm"
            disabled={students.length === 0}
            onClick={openNewInvoiceModal}
          >
            <Plus className="h-3.5 w-3.5" />
            <span>Custom Invoice</span>
          </Button>
          <Button
            size="sm"
            disabled={unpaidInvoices.length === 0}
            onClick={() => openCollectModal()}
          >
            Record Payment
          </Button>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative max-w-md">
        <Search className="h-4 w-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
        <Input
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Search student, invoice no., or receipt no..."
          className="pl-9 bg-white"
        />
      </div>

      {/* Period Invoices Table */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Invoices for {formatPeriodLabel(selectedPeriod)}
            </h2>
            <p className="text-xs text-slate-500">
              Invoices are marked PAID strictly when verified payments cover the full net due amount.
            </p>
          </div>
        </div>

        {filteredInvoices.length === 0 ? (
          <EmptyState
            title={`No invoices issued for ${formatPeriodLabel(selectedPeriod)}`}
            description="Click 'Issue Batch Invoices' above to automatically bill all active enrolled students, or create a custom invoice with discounts."
            actionLabel={students.length > 0 ? 'Issue Batch Invoices' : undefined}
            onAction={students.length > 0 ? handleBulkGenerateInvoices : undefined}
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-semibold text-slate-500">
                  <th className="py-2.5 pr-3">Invoice</th>
                  <th className="py-2.5 px-3">Student & Course</th>
                  <th className="py-2.5 px-3">Due Date</th>
                  <th className="py-2.5 px-3 text-right">Gross / Disc.</th>
                  <th className="py-2.5 px-3 text-right">Net Due</th>
                  <th className="py-2.5 px-3 text-right">Verified Paid</th>
                  <th className="py-2.5 px-3 text-right">Balance</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 pl-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredInvoices.map((inv) => (
                  <tr key={inv.id} className="hover:bg-slate-50/80">
                    <td className="py-3 pr-3 font-mono text-xs text-slate-600">
                      {inv.invoiceNumber}
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-semibold text-slate-900">{inv.studentName}</div>
                      <div className="text-xs text-slate-500">{inv.courseName}</div>
                    </td>
                    <td className="py-3 px-3 font-mono text-xs text-slate-600">{inv.dueDate}</td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-xs text-slate-600">
                      {formatINR(inv.grossAmountPaise)}
                      {inv.discountPaise > 0 ? ` (−${formatINR(inv.discountPaise)})` : ''}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums font-medium">
                      {formatINR(inv.netAmountDuePaise)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-emerald-700 font-medium">
                      {formatINR(inv.paidAmountPaise)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums font-bold text-slate-900">
                      {formatINR(inv.balanceDuePaise)}
                    </td>
                    <td className="py-3 px-3">
                      <StatusText
                        tone={
                          inv.status === InvoiceStatus.PAID
                            ? 'positive'
                            : inv.status === InvoiceStatus.CANCELLED
                            ? 'neutral'
                            : inv.status === InvoiceStatus.OVERDUE
                            ? 'danger'
                            : 'warning'
                        }
                        label={inv.status}
                      />
                    </td>
                    <td className="py-3 pl-3 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5">
                        {inv.balanceDuePaise > 0 && inv.status !== InvoiceStatus.CANCELLED ? (
                          <Button size="sm" variant="secondary" onClick={() => openCollectModal(inv)}>
                            Collect
                          </Button>
                        ) : (
                          <span className="text-xs text-slate-400 mr-1">Settled</span>
                        )}
                        <button
                          type="button"
                          onClick={() => openEditInvoiceModal(inv)}
                          title="Edit invoice"
                          className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                        >
                          <Edit2 className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteTargetInvoice(inv)}
                          title="Delete invoice"
                          className="p-1.5 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Verified Payment Receipt Ledger */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-6 space-y-4">
        <h2 className="text-base font-bold text-slate-900">Payment Receipt History & PDF Export</h2>
        {filteredPayments.length === 0 ? (
          <EmptyState
            title="No payments recorded yet"
            description="Collected Cash, UPI, and Bank Transfer installments appear here with downloadable PDF receipts."
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-semibold text-slate-500">
                  <th className="py-2.5 pr-3">Receipt No</th>
                  <th className="py-2.5 px-3">Student & Course</th>
                  <th className="py-2.5 px-3">Date · Method</th>
                  <th className="py-2.5 px-3 text-right">Amount</th>
                  <th className="py-2.5 px-3">State</th>
                  <th className="py-2.5 pl-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredPayments.slice(0, 50).map((pay) => (
                  <tr key={pay.id} className="hover:bg-slate-50/80">
                    <td className="py-3 pr-3 font-mono text-xs text-slate-700">
                      {pay.receiptNumber}
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-semibold text-slate-900">{pay.studentName}</div>
                      <div className="text-xs text-slate-500">{pay.courseName}</div>
                    </td>
                    <td className="py-3 px-3 font-mono text-xs text-slate-600">
                      {pay.paymentDate} · {pay.paymentMethod.replace('_', ' ')}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums font-bold">
                      {pay.status === PaymentStatus.REVERSED ? (
                        <span className="line-through text-slate-400">
                          {formatINR(pay.amountPaise)}
                        </span>
                      ) : (
                        formatINR(pay.amountPaise)
                      )}
                    </td>
                    <td className="py-3 px-3">
                      <StatusText
                        tone={pay.status === PaymentStatus.COMPLETED ? 'positive' : 'danger'}
                        label={pay.status}
                      />
                    </td>
                    <td className="py-3 pl-3 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() =>
                            generatePaymentReceiptPDF({
                              payment: pay,
                              invoice: invoices.find((i) => i.id === pay.invoiceId),
                              settings,
                            })
                          }
                        >
                          <Download className="h-3.5 w-3.5" />
                          <span>PDF Receipt</span>
                        </Button>
                        <button
                          type="button"
                          onClick={() => openEditPaymentModal(pay)}
                          title="Edit payment entry"
                          className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                        >
                          <Edit2 className="h-3.5 w-3.5" />
                        </button>
                        {pay.status === PaymentStatus.COMPLETED && (
                          <button
                            type="button"
                            onClick={() => {
                              setReverseModalPaymentId(pay.id);
                              setReversalReason('');
                            }}
                            title="Reverse payment entry"
                            className="p-1.5 rounded-md text-slate-400 hover:text-amber-700 hover:bg-amber-50 cursor-pointer"
                          >
                            <RotateCcw className="h-3.5 w-3.5" />
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setDeleteTargetPayment(pay)}
                          title="Delete payment entry"
                          className="p-1.5 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Create / Edit Invoice Dialog */}
      <Dialog
        open={invoiceModalOpen}
        onOpenChange={(o) => {
          setInvoiceModalOpen(o);
          if (!o) setEditingInvoice(null);
        }}
      >
        <DialogContent
          title={editingInvoice ? 'Edit Student Fee Invoice' : 'Issue Student Fee Invoice'}
          description="Supports standard monthly fees, custom installment amounts, and scholarship discounts."
        >
          <form onSubmit={handleSaveInvoice} className="space-y-4">
            {!editingInvoice ? (
              <div>
                <Label>Student</Label>
                <Select
                  value={invStudentId}
                  onValueChange={(val) => {
                    setInvStudentId(val);
                    const st = students.find((s) => s.id === val);
                    if (st) {
                      setInvCourseId(st.primaryCourseId);
                      setInvGrossRupees(String(st.monthlyFeePaise / 100));
                    }
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose student" />
                  </SelectTrigger>
                  <SelectContent>
                    {students
                      .filter((s) => s.status !== 'ARCHIVED')
                      .map((s) => (
                        <SelectItem key={s.id} value={s.id}>
                          {s.fullName} ({s.studentCode})
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            ) : (
              <div>
                <Label>Course</Label>
                <Select value={invCourseId} onValueChange={setInvCourseId}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {courses.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Billing Month (YYYY-MM)</Label>
                <Input
                  type="month"
                  value={invBillingPeriod}
                  onChange={(e) => setInvBillingPeriod(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Due Date</Label>
                <Input
                  type="date"
                  value={invDueDate}
                  onChange={(e) => setInvDueDate(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Gross Tuition Amount (₹)</Label>
                <Input
                  type="number"
                  min="0"
                  step="1"
                  value={invGrossRupees}
                  onChange={(e) => setInvGrossRupees(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Discount / Scholarship (₹)</Label>
                <Input
                  type="number"
                  min="0"
                  step="1"
                  value={invDiscountRupees}
                  onChange={(e) => setInvDiscountRupees(e.target.value)}
                />
              </div>
            </div>

            <div>
              <Label>Adjustment Notes (Optional)</Label>
              <Input
                value={invNotes}
                onChange={(e) => setInvNotes(e.target.value)}
                placeholder="e.g., Sibling concession or custom installment plan"
              />
            </div>

            {editingInvoice && (
              <div className="flex items-center gap-2.5 pt-1">
                <Switch checked={invCancelled} onCheckedChange={setInvCancelled} />
                <span className="text-xs font-semibold text-slate-700">
                  Mark Invoice as CANCELLED
                </span>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <Button
                type="button"
                variant="secondary"
                onClick={() => {
                  setInvoiceModalOpen(false);
                  setEditingInvoice(null);
                }}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting
                  ? 'Saving...'
                  : editingInvoice
                  ? 'Save Invoice Changes'
                  : 'Issue Invoice'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Collect Fee Payment Dialog */}
      <Dialog open={payModalOpen} onOpenChange={setPayModalOpen}>
        <DialogContent
          title="Record Fee Payment (Full or Installment)"
          description="Validated server-side in integer paise and committed via an atomic Firestore transaction."
        >
          <form onSubmit={handleRecordPayment} className="space-y-4">
            <div>
              <Label>Select Unpaid / Partial Invoice</Label>
              <Select
                value={payInvoiceId}
                onValueChange={(val) => {
                  setPayInvoiceId(val);
                  const found = invoices.find((i) => i.id === val);
                  if (found) setPayAmountRupees(String(found.balanceDuePaise / 100));
                }}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Choose invoice" />
                </SelectTrigger>
                <SelectContent>
                  {unpaidInvoices.map((inv) => (
                    <SelectItem key={inv.id} value={inv.id}>
                      {inv.studentName} · {inv.billingPeriod} · Due {formatINR(inv.balanceDuePaise)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Amount Received (INR ₹)</Label>
                <Input
                  type="number"
                  min="1"
                  step="0.01"
                  value={payAmountRupees}
                  onChange={(e) => setPayAmountRupees(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Payment Method</Label>
                <Select value={payMethod} onValueChange={(v) => setPayMethod(v as PaymentMethod)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={PaymentMethod.UPI}>UPI</SelectItem>
                    <SelectItem value={PaymentMethod.CASH}>Cash</SelectItem>
                    <SelectItem value={PaymentMethod.BANK_TRANSFER}>Bank Transfer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Payment Date (IST)</Label>
                <Input
                  type="date"
                  value={payDate}
                  onChange={(e) => setPayDate(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Idempotency Lock Key</Label>
                <Input value={idempotencyKey} readOnly className="bg-slate-50 font-mono text-xs" />
              </div>
            </div>

            <div>
              <Label>UTR / Reference Remarks</Label>
              <Input
                value={payRefNote}
                onChange={(e) => setPayRefNote(e.target.value)}
                placeholder="e.g., UPI Ref 429812098412"
              />
            </div>

            {/* Live Calculation Preview */}
            {paymentPreview && selectedInvoiceObj && (
              <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200 text-xs space-y-1.5 font-mono tabular-nums">
                <div className="flex justify-between">
                  <span className="font-sans text-slate-600">Current Invoice Balance:</span>
                  <span>{formatINR(selectedInvoiceObj.balanceDuePaise)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="font-sans text-slate-600">Remaining Balance After Payment:</span>
                  <span className="font-bold text-slate-900">
                    {formatINR(paymentPreview.remainingAfter)} (
                    {paymentPreview.willBeFullyPaid ? 'Marks PAID' : 'Marks PARTIAL'})
                  </span>
                </div>
                <div className="flex justify-between pt-1 border-t border-slate-200/80">
                  <span className="font-sans text-slate-600">
                    Auto Teacher Share ({paymentPreview.teacherName}):
                  </span>
                  <span className="text-blue-700 font-semibold">
                    {formatINR(paymentPreview.shareCalc.allocatedAmountPaise)} (
                    {paymentPreview.shareCalc.rateSnapshotLabel})
                  </span>
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <Button type="button" variant="secondary" onClick={() => setPayModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting || !payInvoiceId}>
                {submitting ? 'Committing...' : 'Confirm & Issue Receipt'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Fee Payment Dialog */}
      <Dialog open={Boolean(editingPayment)} onOpenChange={(o) => !o && setEditingPayment(null)}>
        <DialogContent
          title="Edit Fee Payment Receipt"
          description="Atomically updates the receipt, recalculates the parent invoice balance, and syncs teacher share allocations."
        >
          <form onSubmit={handleSavePaymentEdit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Amount (INR ₹)</Label>
                <Input
                  type="number"
                  min="1"
                  step="0.01"
                  value={editPayAmountRupees}
                  onChange={(e) => setEditPayAmountRupees(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Payment Method</Label>
                <Select
                  value={editPayMethod}
                  onValueChange={(v) => setEditPayMethod(v as PaymentMethod)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={PaymentMethod.UPI}>UPI</SelectItem>
                    <SelectItem value={PaymentMethod.CASH}>Cash</SelectItem>
                    <SelectItem value={PaymentMethod.BANK_TRANSFER}>Bank Transfer</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Payment Date (IST)</Label>
                <Input
                  type="date"
                  value={editPayDate}
                  onChange={(e) => setEditPayDate(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Receipt Status</Label>
                <Select
                  value={editPayStatus}
                  onValueChange={(v) => setEditPayStatus(v as PaymentStatus)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={PaymentStatus.COMPLETED}>COMPLETED</SelectItem>
                    <SelectItem value={PaymentStatus.REVERSED}>REVERSED</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>UTR / Reference Remarks</Label>
              <Input
                value={editPayRefNote}
                onChange={(e) => setEditPayRefNote(e.target.value)}
              />
            </div>

            {editPayStatus === PaymentStatus.REVERSED && (
              <div>
                <Label>Reversal Reason</Label>
                <Input
                  value={editPayReversalReason}
                  onChange={(e) => setEditPayReversalReason(e.target.value)}
                />
              </div>
            )}

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <Button type="button" variant="secondary" onClick={() => setEditingPayment(null)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? 'Saving...' : 'Save Payment Changes'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Reverse Payment Dialog */}
      <Dialog
        open={Boolean(reverseModalPaymentId)}
        onOpenChange={(o) => !o && setReverseModalPaymentId(null)}
      >
        <DialogContent
          title="Reverse Fee Payment"
          description="Marks this receipt REVERSED while keeping it visible on the ledger, restores invoice balance, and reverses linked teacher share allocations."
        >
          <form onSubmit={handleConfirmReversal} className="space-y-4">
            <div>
              <Label>Reason for Reversal</Label>
              <Input
                value={reversalReason}
                onChange={(e) => setReversalReason(e.target.value)}
                placeholder="e.g., Dishonored bank transfer / Wrong student selected"
                required
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button
                type="button"
                variant="secondary"
                onClick={() => setReverseModalPaymentId(null)}
              >
                Cancel
              </Button>
              <Button type="submit" variant="danger" disabled={submitting}>
                {submitting ? 'Reversing...' : 'Confirm Reversal'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Delete Invoice Confirmation */}
      <ConfirmDeleteDialog
        open={Boolean(deleteTargetInvoice)}
        onOpenChange={(o) => !o && setDeleteTargetInvoice(null)}
        title="Delete Invoice"
        description={
          deleteTargetInvoice
            ? `Permanently delete invoice ${deleteTargetInvoice.invoiceNumber} for ${deleteTargetInvoice.studentName} along with any linked fee payment receipts and teacher share allocations?`
            : ''
        }
        loading={submitting}
        onConfirm={handleConfirmDeleteInvoice}
      />

      {/* Delete Payment Confirmation */}
      <ConfirmDeleteDialog
        open={Boolean(deleteTargetPayment)}
        onOpenChange={(o) => !o && setDeleteTargetPayment(null)}
        title="Delete Payment Receipt"
        description={
          deleteTargetPayment
            ? `Permanently delete payment receipt ${deleteTargetPayment.receiptNumber} (${formatINR(deleteTargetPayment.amountPaise)})? The parent invoice balance and linked teacher share allocation will be recalculated atomically.`
            : ''
        }
        loading={submitting}
        onConfirm={handleConfirmDeletePayment}
      />
    </div>
  );
}

// Page 5: Outstanding Fees
export function OutstandingFeesPage({
  onCollectForInvoice,
}: {
  onCollectForInvoice: (invoiceId: string) => void;
}) {
  const {
    activeRole,
    invoices,
    students,
    courses,
    updateInvoice,
    deleteInvoice,
    getAuthToken,
    isDemoMode,
  } = useInstitute();
  const [filterMode, setFilterMode] = useState<'ALL_UNPAID' | 'OVERDUE_ONLY' | 'PARTIAL_ONLY'>(
    'ALL_UNPAID'
  );
  const [search, setSearch] = useState('');
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  const [deleteTargetInvoice, setDeleteTargetInvoice] = useState<Invoice | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const [invCourseId, setInvCourseId] = useState('');
  const [invBillingPeriod, setInvBillingPeriod] = useState('');
  const [invGrossRupees, setInvGrossRupees] = useState('');
  const [invDiscountRupees, setInvDiscountRupees] = useState('0');
  const [invDueDate, setInvDueDate] = useState('');
  const [invNotes, setInvNotes] = useState('');
  const [invCancelled, setInvCancelled] = useState(false);

  if (activeRole === UserRole.TEACHER) {
    return <RestrictedFinanceNotice />;
  }

  const todayIST = getTodayIST();

  const receivables = useMemo(() => {
    return invoices
      .filter((inv) => inv.status !== InvoiceStatus.CANCELLED && inv.balanceDuePaise > 0)
      .map((inv) => {
        const isOverdue = inv.dueDate < todayIST;
        const dueMs = new Date(`${inv.dueDate}T00:00:00Z`).getTime();
        const todayMs = new Date(`${todayIST}T00:00:00Z`).getTime();
        const daysOverdue = isOverdue ? Math.max(1, Math.round((todayMs - dueMs) / 86400000)) : 0;
        const student = students.find((s) => s.id === inv.studentId);
        return {
          ...inv,
          isOverdue,
          daysOverdue,
          guardianPhone: student?.guardianPhone ?? '',
        };
      })
      .filter((item) => {
        if (filterMode === 'OVERDUE_ONLY' && !item.isOverdue) return false;
        if (filterMode === 'PARTIAL_ONLY' && item.paidAmountPaise <= 0) return false;
        if (search.trim()) {
          const q = search.toLowerCase();
          return (
            item.studentName.toLowerCase().includes(q) ||
            item.courseName.toLowerCase().includes(q) ||
            item.invoiceNumber.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => b.daysOverdue - a.daysOverdue || b.balanceDuePaise - a.balanceDuePaise);
  }, [invoices, students, todayIST, filterMode, search]);

  const totalPendingPaise = receivables.reduce((s, r) => s + r.balanceDuePaise, 0);
  const totalOverduePaise = receivables
    .filter((r) => r.isOverdue)
    .reduce((s, r) => s + r.balanceDuePaise, 0);

  const openEditReceivable = (inv: Invoice) => {
    setEditingInvoice(inv);
    setInvCourseId(inv.courseId);
    setInvBillingPeriod(inv.billingPeriod);
    setInvGrossRupees(String(inv.grossAmountPaise / 100));
    setInvDiscountRupees(String(inv.discountPaise / 100));
    setInvDueDate(inv.dueDate);
    setInvNotes(inv.notes);
    setInvCancelled(inv.status === InvoiceStatus.CANCELLED);
  };

  const handleSaveReceivableEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingInvoice) return;
    setSubmitting(true);
    try {
      await updateInvoice(editingInvoice.id, {
        courseId: invCourseId,
        billingPeriod: invBillingPeriod,
        grossAmountRupees: Number(invGrossRupees),
        discountRupees: Number(invDiscountRupees) || 0,
        dueDate: invDueDate,
        notes: invNotes,
        isCancelled: invCancelled,
      });
      toast.success(`Updated invoice ${editingInvoice.invoiceNumber}`);
      setEditingInvoice(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to update invoice');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDeleteReceivable = async () => {
    if (!deleteTargetInvoice) return;
    setSubmitting(true);
    try {
      await deleteInvoice(deleteTargetInvoice.id);
      toast.success(`Deleted invoice ${deleteTargetInvoice.invoiceNumber}`);
      setDeleteTargetInvoice(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete invoice');
    } finally {
      setSubmitting(false);
    }
  };

  const handleExportReceivablesCSV = async () => {
    try {
      const token = await getAuthToken();
      await downloadServerCSV({
        filename: `IIS_Outstanding_Fees_${todayIST}.csv`,
        headers: [
          'Invoice No',
          'Student Name',
          'Course',
          'Billing Month',
          'Due Date',
          'Days Overdue',
          'Net Due (INR)',
          'Paid (INR)',
          'Balance Due (INR)',
          'Guardian Phone',
        ],
        rows: receivables.map((r) => [
          r.invoiceNumber,
          r.studentName,
          r.courseName,
          r.billingPeriod,
          r.dueDate,
          r.daysOverdue,
          r.netAmountDuePaise / 100,
          r.paidAmountPaise / 100,
          r.balanceDuePaise / 100,
          r.guardianPhone,
        ]),
        idToken: token,
        isDemoMode,
      });
      toast.success('Exported Outstanding Fees CSV');
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Export failed');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-amber-700 mb-1">
            Receivables & Aging Control · Asia/Kolkata ({todayIST})
          </p>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Outstanding Fees
          </h1>
        </div>
        <Button
          variant="secondary"
          size="sm"
          disabled={receivables.length === 0}
          onClick={handleExportReceivablesCSV}
        >
          <Download className="h-3.5 w-3.5" />
          <span>Export CSV</span>
        </Button>
      </div>

      {/* KPI Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="text-xs text-slate-500">Filtered Pending Receivables</div>
          <div className="text-2xl font-extrabold font-mono tabular-nums text-slate-900 mt-1.5">
            {formatINR(totalPendingPaise)}
          </div>
          <div className="text-xs text-slate-500 mt-1">{receivables.length} open invoices</div>
        </div>
        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="text-xs text-slate-500">Past-Due Overdue Balance</div>
          <div className="text-2xl font-extrabold font-mono tabular-nums text-red-700 mt-1.5">
            {formatINR(totalOverduePaise)}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            {receivables.filter((r) => r.isOverdue).length} overdue accounts
          </div>
        </div>
        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="text-xs text-slate-500">Partial Installment Accounts</div>
          <div className="text-2xl font-extrabold font-mono tabular-nums text-blue-700 mt-1.5">
            {receivables.filter((r) => r.paidAmountPaise > 0).length}
          </div>
          <div className="text-xs text-slate-500 mt-1">Awaiting remaining installment</div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="h-4 w-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter by student, course, or invoice..."
            className="pl-9"
          />
        </div>

        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
          {(
            [
              ['ALL_UNPAID', 'All Unpaid'],
              ['OVERDUE_ONLY', 'Overdue Only'],
              ['PARTIAL_ONLY', 'Partial Installments'],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              type="button"
              onClick={() => setFilterMode(id)}
              className={`px-3 py-1.5 rounded-md text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                filterMode === id
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-white border border-slate-200/90 rounded-xl overflow-hidden">
        {receivables.length === 0 ? (
          <div className="p-6">
            <EmptyState
              title="Zero pending fee balances match your filter"
              description="All issued student invoices in this view are settled."
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-500">
                  <th className="py-3 px-4">Student & Contact</th>
                  <th className="py-3 px-4">Course · Period</th>
                  <th className="py-3 px-4">Due Date · Aging</th>
                  <th className="py-3 px-4 text-right">Net Due</th>
                  <th className="py-3 px-4 text-right">Paid</th>
                  <th className="py-3 px-4 text-right">Balance Due</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {receivables.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/80">
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">{r.studentName}</div>
                      <div className="text-xs text-slate-500 font-mono">
                        {r.invoiceNumber}
                        {r.guardianPhone ? ` · ${r.guardianPhone}` : ''}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="text-slate-800">{r.courseName}</div>
                      <div className="text-xs text-slate-500 font-mono">{r.billingPeriod}</div>
                    </td>
                    <td className="py-3 px-4 font-mono text-xs">
                      <div>{r.dueDate}</div>
                      {r.isOverdue ? (
                        <StatusText tone="danger" label={`${r.daysOverdue}d overdue`} />
                      ) : (
                        <StatusText tone="warning" label="Upcoming due" />
                      )}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums">
                      {formatINR(r.netAmountDuePaise)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-emerald-700">
                      {formatINR(r.paidAmountPaise)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums font-extrabold text-slate-900">
                      {formatINR(r.balanceDuePaise)}
                    </td>
                    <td className="py-3 px-4 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1.5">
                        <Button size="sm" onClick={() => onCollectForInvoice(r.id)}>
                          Collect Due
                        </Button>
                        <button
                          type="button"
                          onClick={() => openEditReceivable(r)}
                          title="Edit invoice"
                          className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                        >
                          <Edit2 className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setDeleteTargetInvoice(r)}
                          title="Delete invoice"
                          className="p-1.5 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Edit Receivable Invoice Modal */}
      <Dialog open={Boolean(editingInvoice)} onOpenChange={(o) => !o && setEditingInvoice(null)}>
        <DialogContent
          title="Edit Outstanding Invoice"
          description="Adjust gross fee, scholarship discount, due date, or cancellation state."
        >
          <form onSubmit={handleSaveReceivableEdit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Course</Label>
                <Select value={invCourseId} onValueChange={setInvCourseId}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {courses.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Billing Month (YYYY-MM)</Label>
                <Input
                  type="month"
                  value={invBillingPeriod}
                  onChange={(e) => setInvBillingPeriod(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Gross Amount (₹)</Label>
                <Input
                  type="number"
                  min={0}
                  step="1"
                  value={invGrossRupees}
                  onChange={(e) => setInvGrossRupees(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Discount (₹)</Label>
                <Input
                  type="number"
                  min={0}
                  step="1"
                  value={invDiscountRupees}
                  onChange={(e) => setInvDiscountRupees(e.target.value)}
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 items-center">
              <div>
                <Label>Due Date</Label>
                <Input
                  type="date"
                  value={invDueDate}
                  onChange={(e) => setInvDueDate(e.target.value)}
                  required
                />
              </div>
              <div className="flex items-center gap-2.5 pt-5">
                <Switch checked={invCancelled} onCheckedChange={setInvCancelled} />
                <span className="text-xs font-semibold text-slate-700">Mark Cancelled</span>
              </div>
            </div>

            <div>
              <Label>Notes</Label>
              <Input value={invNotes} onChange={(e) => setInvNotes(e.target.value)} />
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <Button type="button" variant="secondary" onClick={() => setEditingInvoice(null)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? 'Saving...' : 'Save Invoice'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDeleteDialog
        open={Boolean(deleteTargetInvoice)}
        onOpenChange={(o) => !o && setDeleteTargetInvoice(null)}
        title="Delete Outstanding Invoice"
        description={
          deleteTargetInvoice
            ? `Permanently delete invoice ${deleteTargetInvoice.invoiceNumber} (${deleteTargetInvoice.studentName}) and any linked receipts or share allocations?`
            : ''
        }
        loading={submitting}
        onConfirm={handleConfirmDeleteReceivable}
      />
    </div>
  );
}
