import React, { useMemo } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { ArrowUpRight, ArrowDownRight, Plus, FileText } from 'lucide-react';
import { useInstitute } from '../context/InstituteContext';
import {
  calculateMoMGrowth,
  computeMonthlyPeriodMetrics,
  detectInstituteWeakPoints,
  formatINR,
  getTrailingPeriods,
  periodFromDate,
  shiftPeriod,
  toRupees,
} from '../shared/finance';
import { AllocationStatus, NavPageId, PaymentStatus, PayoutStatus, UserRole } from '../shared/types';
import { Button, EmptyState, Skeleton, StatusText } from '../components/ui/primitives';

export function OverviewPage({
  onNavigate,
  onInspectStudent,
}: {
  onNavigate: (page: NavPageId) => void;
  onInspectStudent: (studentId: string) => void;
}) {
  const {
    dataLoading,
    activeRole,
    selectedPeriod,
    students,
    invoices,
    payments,
    allocations,
    payouts,
    expenses,
    reports,
  } = useInstitute();

  const previousPeriod = useMemo(() => shiftPeriod(selectedPeriod, -1), [selectedPeriod]);
  const trailing12 = useMemo(() => getTrailingPeriods(selectedPeriod, 12), [selectedPeriod]);

  const currentMetrics = useMemo(
    () =>
      computeMonthlyPeriodMetrics({
        period: selectedPeriod,
        students,
        invoices,
        payments,
        allocations,
        payouts,
        expenses,
      }),
    [selectedPeriod, students, invoices, payments, allocations, payouts, expenses]
  );

  const previousMetrics = useMemo(
    () =>
      computeMonthlyPeriodMetrics({
        period: previousPeriod,
        students,
        invoices,
        payments,
        allocations,
        payouts,
        expenses,
      }),
    [previousPeriod, students, invoices, payments, allocations, payouts, expenses]
  );

  const trailingSeries = useMemo(
    () =>
      trailing12.map((period) =>
        computeMonthlyPeriodMetrics({
          period,
          students,
          invoices,
          payments,
          allocations,
          payouts,
          expenses,
        })
      ),
    [trailing12, students, invoices, payments, allocations, payouts, expenses]
  );

  const revenueGrowth = useMemo(
    () => calculateMoMGrowth(currentMetrics.collectedFeePaise, previousMetrics.collectedFeePaise),
    [currentMetrics.collectedFeePaise, previousMetrics.collectedFeePaise]
  );

  const netIncomeGrowth = useMemo(
    () =>
      calculateMoMGrowth(
        currentMetrics.netOperatingIncomePaise,
        previousMetrics.netOperatingIncomePaise
      ),
    [currentMetrics.netOperatingIncomePaise, previousMetrics.netOperatingIncomePaise]
  );

  const weakPoints = useMemo(
    () =>
      detectInstituteWeakPoints({
        current: currentMetrics,
        previous: previousMetrics,
        payments,
        invoices,
      }),
    [currentMetrics, previousMetrics, payments, invoices]
  );

  const courseBreakdown = useMemo(() => {
    const map = new Map<string, { name: string; collectedRupees: number }>();
    payments
      .filter(
        (p) => p.status === PaymentStatus.COMPLETED && periodFromDate(p.paymentDate) === selectedPeriod
      )
      .forEach((p) => {
        const entry = map.get(p.courseId) ?? { name: p.courseName, collectedRupees: 0 };
        entry.collectedRupees += toRupees(p.amountPaise);
        map.set(p.courseId, entry);
      });
    return Array.from(map.values()).sort((a, b) => b.collectedRupees - a.collectedRupees);
  }, [payments, selectedPeriod]);

  if (dataLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-20 w-full" />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
          <Skeleton className="h-32" />
        </div>
        <Skeleton className="h-80 w-full" />
      </div>
    );
  }

  // Scoped Teacher Portal Overview (No institute-wide financial exposure)
  if (activeRole === UserRole.TEACHER) {
    const periodAccrued = allocations
      .filter((a) => a.billingPeriod === selectedPeriod && a.status !== AllocationStatus.REVERSED)
      .reduce((s, a) => s + a.allocatedAmountPaise, 0);
    const periodPaid = payouts
      .filter((p) => p.billingPeriod === selectedPeriod && p.status === PayoutStatus.PAID)
      .reduce((s, p) => s + p.amountPaise, 0);
    const periodDue = Math.max(0, periodAccrued - periodPaid);
    const periodReports = reports.filter((r) => r.reportingPeriod === selectedPeriod);

    return (
      <div className="space-y-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-xs font-semibold text-blue-600 mb-1">
              Faculty Workspace · {currentMetrics.label}
            </p>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Assigned Students & Earnings Summary
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="secondary" size="sm" onClick={() => onNavigate('teacher-payouts')}>
              My Payout Ledger
            </Button>
            <Button size="sm" onClick={() => onNavigate('performance-reports')}>
              <Plus className="h-4 w-4" />
              <span>Submit Student Report</span>
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-white border border-slate-200/90 rounded-xl p-5">
            <p className="text-xs font-medium text-slate-500">Assigned Active Students</p>
            <p className="text-2xl font-extrabold font-mono tabular-nums text-slate-900 mt-2">
              {students.filter((s) => s.status === 'ACTIVE').length}
            </p>
            <p className="text-xs text-slate-500 mt-2">Scoped strictly to your batches</p>
          </div>

          <div className="bg-white border border-slate-200/90 rounded-xl p-5">
            <p className="text-xs font-medium text-slate-500">
              Accrued Share ({currentMetrics.label})
            </p>
            <p className="text-2xl font-extrabold font-mono tabular-nums text-slate-900 mt-2">
              {formatINR(periodAccrued)}
            </p>
            <p className="text-xs text-slate-500 mt-2">Verified fee share + retainer</p>
          </div>

          <div className="bg-white border border-slate-200/90 rounded-xl p-5">
            <p className="text-xs font-medium text-slate-500">Disbursed Payouts</p>
            <p className="text-2xl font-extrabold font-mono tabular-nums text-emerald-700 mt-2">
              {formatINR(periodPaid)}
            </p>
            <p className="text-xs text-slate-500 mt-2">Remaining due: {formatINR(periodDue)}</p>
          </div>

          <div className="bg-white border border-slate-200/90 rounded-xl p-5">
            <p className="text-xs font-medium text-slate-500">Reports Submitted</p>
            <p className="text-2xl font-extrabold font-mono tabular-nums text-slate-900 mt-2">
              {periodReports.length}
            </p>
            <p className="text-xs text-slate-500 mt-2">Period: {currentMetrics.label}</p>
          </div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-slate-900">Your Assigned Students</h2>
            <Button variant="ghost" size="sm" onClick={() => onNavigate('students')}>
              View Full Roster
            </Button>
          </div>

          {students.length === 0 ? (
            <EmptyState
              title="No students assigned yet"
              description="Once an institute administrator assigns students to your faculty profile, their academic roster will appear here."
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead>
                  <tr className="border-b border-slate-200 text-xs font-semibold text-slate-500">
                    <th className="py-2.5 pr-4">Student ID</th>
                    <th className="py-2.5 px-4">Full Name</th>
                    <th className="py-2.5 px-4">Course · Batch</th>
                    <th className="py-2.5 px-4">Status</th>
                    <th className="py-2.5 pl-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {students.slice(0, 8).map((stu) => (
                    <tr key={stu.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="py-3 pr-4 font-mono text-xs text-slate-600">
                        {stu.studentCode}
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-900">{stu.fullName}</td>
                      <td className="py-3 px-4 text-slate-600">
                        {stu.primaryCourseName} · {stu.batchName}
                      </td>
                      <td className="py-3 px-4">
                        <StatusText
                          tone={stu.status === 'ACTIVE' ? 'positive' : 'neutral'}
                          label={stu.status}
                        />
                      </td>
                      <td className="py-3 pl-4 text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            onInspectStudent(stu.id);
                            onNavigate('student-profiles');
                          }}
                        >
                          Profile
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Executive Financial Dashboard (Admin & Accountant)
  const financialHealthStatus =
    currentMetrics.netOperatingIncomePaise < 0
      ? { tone: 'danger' as const, text: 'Deficit Alert — Operating costs exceed collected revenue' }
      : currentMetrics.collectionRatePercent >= 80
      ? { tone: 'positive' as const, text: 'Healthy Realization — Positive operating margin' }
      : { tone: 'warning' as const, text: 'Receivables Watch — Follow up pending invoices' };

  const chartData = trailingSeries.map((m) => ({
    month: m.label,
    collected: toRupees(m.collectedFeePaise),
    netIncome: toRupees(m.netOperatingIncomePaise),
    payoutsAndExpenses: toRupees(m.accruedTeacherSharePaise + m.operatingExpensesPaise),
  }));

  return (
    <div className="space-y-8">
      {/* Header Row */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
            <span>Executive Financial Overview</span>
            <span aria-hidden="true">·</span>
            <span>{currentMetrics.label} vs {previousMetrics.label}</span>
            <span aria-hidden="true">·</span>
            <StatusText tone={financialHealthStatus.tone} label={financialHealthStatus.text} />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Institute Performance & Cash Realization
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {activeRole === UserRole.ADMIN && (
            <Button variant="secondary" size="sm" onClick={() => onNavigate('students')}>
              <Plus className="h-3.5 w-3.5" />
              <span>Enroll Student</span>
            </Button>
          )}
          <Button variant="secondary" size="sm" onClick={() => onNavigate('financial-reports')}>
            <FileText className="h-3.5 w-3.5" />
            <span>Financial Statement</span>
          </Button>
        </div>
      </div>

      {/* Primary 4-Column Financial KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {/* 1. Collected Fees This Month vs Last Month */}
        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-medium">Fees Collected ({currentMetrics.label})</span>
            <span
              className={`inline-flex items-center gap-0.5 font-mono font-semibold ${
                revenueGrowth.direction === 'up'
                  ? 'text-emerald-700'
                  : revenueGrowth.direction === 'down'
                  ? 'text-red-700'
                  : 'text-slate-600'
              }`}
            >
              {revenueGrowth.direction === 'up' && <ArrowUpRight className="h-3.5 w-3.5" />}
              {revenueGrowth.direction === 'down' && <ArrowDownRight className="h-3.5 w-3.5" />}
              {revenueGrowth.formattedPercent}
            </span>
          </div>
          <div className="text-2xl font-extrabold font-mono tabular-nums text-slate-900 mt-2">
            {formatINR(currentMetrics.collectedFeePaise)}
          </div>
          <div className="text-xs text-slate-500 mt-2 flex items-center justify-between font-mono tabular-nums">
            <span>Last mo ({previousMetrics.label}): {formatINR(previousMetrics.collectedFeePaise)}</span>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono tabular-nums">
            Invoiced net: {formatINR(currentMetrics.invoicedNetPaise)}
          </div>
        </div>

        {/* 2. Net Operating Income */}
        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-medium">Net Operating Income</span>
            <span
              className={`inline-flex items-center gap-0.5 font-mono font-semibold ${
                netIncomeGrowth.direction === 'up'
                  ? 'text-emerald-700'
                  : netIncomeGrowth.direction === 'down'
                  ? 'text-red-700'
                  : 'text-slate-600'
              }`}
            >
              {netIncomeGrowth.direction === 'up' && <ArrowUpRight className="h-3.5 w-3.5" />}
              {netIncomeGrowth.direction === 'down' && <ArrowDownRight className="h-3.5 w-3.5" />}
              {netIncomeGrowth.formattedPercent}
            </span>
          </div>
          <div
            className={`text-2xl font-extrabold font-mono tabular-nums mt-2 ${
              currentMetrics.netOperatingIncomePaise < 0 ? 'text-red-700' : 'text-slate-900'
            }`}
          >
            {formatINR(currentMetrics.netOperatingIncomePaise)}
          </div>
          <div className="text-xs text-slate-500 mt-2 font-mono tabular-nums">
            Operating margin: {currentMetrics.netMarginPercent.toFixed(1)}%
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono tabular-nums">
            Cash surplus after payouts: {formatINR(currentMetrics.cashNetSurplusPaise)}
          </div>
        </div>

        {/* 3. Pending Fees & Collection Rate */}
        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-medium">Pending Receivables</span>
            <span className="font-mono font-semibold text-blue-700">
              {currentMetrics.collectionRatePercent.toFixed(1)}% collected
            </span>
          </div>
          <div className="text-2xl font-extrabold font-mono tabular-nums text-slate-900 mt-2">
            {formatINR(currentMetrics.pendingBalancePaise)}
          </div>
          <div className="text-xs text-slate-500 mt-2 font-mono tabular-nums">
            Overdue balance:{' '}
            <span className={currentMetrics.overdueBalancePaise > 0 ? 'text-red-700 font-semibold' : ''}>
              {formatINR(currentMetrics.overdueBalancePaise)}
            </span>
          </div>
          <div className="w-full h-1.5 bg-slate-100 rounded-full mt-2.5 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-blue-600 to-cyan-500 rounded-full"
              style={{ width: `${Math.min(100, currentMetrics.collectionRatePercent)}%` }}
            />
          </div>
        </div>

        {/* 4. Teacher Shares & Operating Expenses */}
        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="flex items-center justify-between text-xs text-slate-500">
            <span className="font-medium">Teacher Shares & Expenses</span>
            <span className="font-mono font-semibold text-slate-700">
              {currentMetrics.teacherPayoutRatioPercent.toFixed(1)}% share ratio
            </span>
          </div>
          <div className="text-2xl font-extrabold font-mono tabular-nums text-slate-900 mt-2">
            {formatINR(currentMetrics.accruedTeacherSharePaise + currentMetrics.operatingExpensesPaise)}
          </div>
          <div className="text-xs text-slate-500 mt-2 font-mono tabular-nums">
            Accrued shares: {formatINR(currentMetrics.accruedTeacherSharePaise)} · Paid:{' '}
            {formatINR(currentMetrics.paidTeacherPayoutPaise)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 font-mono tabular-nums">
            Other expenses: {formatINR(currentMetrics.operatingExpensesPaise)} · Liability due:{' '}
            {formatINR(currentMetrics.unpaidTeacherLiabilityPaise)}
          </div>
        </div>
      </div>

      {/* Secondary Operational Metrics Bar */}
      <div className="bg-white border border-slate-200/90 rounded-xl px-6 py-4 grid grid-cols-2 md:grid-cols-4 gap-6 divide-y md:divide-y-0 md:divide-x divide-slate-100">
        <div className="pt-2 md:pt-0">
          <div className="text-xs text-slate-500">Active Students</div>
          <div className="text-lg font-extrabold font-mono tabular-nums text-slate-900 mt-0.5">
            {currentMetrics.activeStudentsCount}
          </div>
        </div>
        <div className="pt-2 md:pt-0 md:pl-6">
          <div className="text-xs text-slate-500">New Enrollments ({currentMetrics.label})</div>
          <div className="text-lg font-extrabold font-mono tabular-nums text-blue-700 mt-0.5">
            +{currentMetrics.newEnrollmentsCount}
          </div>
        </div>
        <div className="pt-2 md:pt-0 md:pl-6">
          <div className="text-xs text-slate-500">Disbursed Teacher Payouts</div>
          <div className="text-lg font-extrabold font-mono tabular-nums text-slate-900 mt-0.5">
            {formatINR(currentMetrics.paidTeacherPayoutPaise)}
          </div>
        </div>
        <div className="pt-2 md:pt-0 md:pl-6">
          <div className="text-xs text-slate-500">Active Risk Alerts</div>
          <div className="mt-0.5 flex items-center gap-2">
            <span className="text-lg font-extrabold font-mono tabular-nums text-slate-900">
              {weakPoints.length}
            </span>
            {weakPoints.length > 0 && (
              <button
                type="button"
                onClick={() => onNavigate('growth-insights')}
                className="text-xs font-semibold text-blue-600 hover:underline cursor-pointer"
              >
                Inspect Insights
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Charts Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* 12-Month Collected Revenue vs Net Income */}
        <div className="lg:col-span-8 bg-white border border-slate-200/90 rounded-xl p-6">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-5">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                12-Month Collected Revenue vs Net Operating Income
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Verified cash collections compared against post-payout, post-expense operating profit
              </p>
            </div>
            <Button variant="ghost" size="sm" onClick={() => onNavigate('revenue-analytics')}>
              Full Analytics
            </Button>
          </div>

          {payments.length === 0 && expenses.length === 0 ? (
            <EmptyState
              title="No financial transactions recorded yet"
              description="Issue student invoices and record fee collections to populate real-time 12-month revenue and operating income trajectories."
              actionLabel="Go to Fee Collection"
              onAction={() => onNavigate('fee-collection')}
            />
          ) : (
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 10, right: 12, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="overviewCollectedGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2563eb" stopOpacity={0.28} />
                      <stop offset="95%" stopColor="#2563eb" stopOpacity={0.01} />
                    </linearGradient>
                    <linearGradient id="overviewNetGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#0d9488" stopOpacity={0.26} />
                      <stop offset="95%" stopColor="#0d9488" stopOpacity={0.01} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    tickFormatter={(v) => `₹${Number(v).toLocaleString('en-IN')}`}
                  />
                  <Tooltip
                    formatter={(value: unknown, name: unknown) => [
                      `₹${Number(value).toLocaleString('en-IN')}`,
                      name === 'collected' ? 'Collected Fees' : 'Net Operating Income',
                    ]}
                    contentStyle={{
                      borderRadius: '10px',
                      border: '1px solid #e2e8f0',
                      fontSize: '12px',
                    }}
                  />
                  <Area
                    type="monotone"
                    dataKey="collected"
                    stroke="#2563eb"
                    strokeWidth={2.4}
                    fill="url(#overviewCollectedGrad)"
                  />
                  <Area
                    type="monotone"
                    dataKey="netIncome"
                    stroke="#0d9488"
                    strokeWidth={2.2}
                    fill="url(#overviewNetGrad)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* Course Revenue Breakdown */}
        <div className="lg:col-span-4 bg-white border border-slate-200/90 rounded-xl p-6 flex flex-col">
          <div className="mb-5">
            <h2 className="text-base font-bold text-slate-900">
              Revenue by Course ({currentMetrics.label})
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Collected fee distribution across active programs
            </p>
          </div>

          {courseBreakdown.length === 0 ? (
            <EmptyState
              title="No collections in period"
              description={`No verified fee receipts recorded for ${currentMetrics.label}.`}
            />
          ) : (
            <div className="h-64 w-full flex-1">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={courseBreakdown}
                  layout="vertical"
                  margin={{ top: 4, right: 16, left: 8, bottom: 4 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
                  <XAxis
                    type="number"
                    tick={{ fontSize: 11, fill: '#64748b' }}
                    tickFormatter={(v) => `₹${Number(v).toLocaleString('en-IN')}`}
                  />
                  <YAxis
                    type="category"
                    dataKey="name"
                    width={115}
                    tick={{ fontSize: 11, fill: '#334155' }}
                  />
                  <Tooltip
                    formatter={(v: unknown) => [`₹${Number(v).toLocaleString('en-IN')}`, 'Collected']}
                    contentStyle={{
                      borderRadius: '10px',
                      border: '1px solid #e2e8f0',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="collectedRupees" fill="#4f46e5" radius={[0, 6, 6, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      {/* Recent Verified Receipts & Active Weak-Point Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white border border-slate-200/90 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-slate-900">Recent Fee Receipts</h2>
            <Button variant="ghost" size="sm" onClick={() => onNavigate('fee-collection')}>
              View All Receipts
            </Button>
          </div>

          {payments.length === 0 ? (
            <EmptyState
              title="No receipts issued yet"
              description="Recorded payments will appear here with instant printable PDF receipts."
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead>
                  <tr className="border-b border-slate-200 text-xs font-semibold text-slate-500">
                    <th className="py-2.5 pr-3">Receipt</th>
                    <th className="py-2.5 px-3">Student</th>
                    <th className="py-2.5 px-3">Date · Mode</th>
                    <th className="py-2.5 pl-3 text-right">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {payments.slice(0, 6).map((pay) => (
                    <tr key={pay.id} className="hover:bg-slate-50/80">
                      <td className="py-2.5 pr-3 font-mono text-xs text-slate-600">
                        {pay.receiptNumber}
                      </td>
                      <td className="py-2.5 px-3">
                        <div className="font-semibold text-slate-900">{pay.studentName}</div>
                        <div className="text-xs text-slate-500">{pay.courseName}</div>
                      </td>
                      <td className="py-2.5 px-3 text-xs text-slate-600 font-mono">
                        {pay.paymentDate} · {pay.paymentMethod.replace('_', ' ')}
                      </td>
                      <td className="py-2.5 pl-3 text-right font-mono tabular-nums font-semibold text-slate-900">
                        {pay.status === PaymentStatus.REVERSED ? (
                          <span className="line-through text-slate-400">
                            {formatINR(pay.amountPaise)}
                          </span>
                        ) : (
                          formatINR(pay.amountPaise)
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="lg:col-span-5 bg-white border border-slate-200/90 rounded-xl p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-base font-bold text-slate-900">Weak-Point Radar</h2>
            <Button variant="ghost" size="sm" onClick={() => onNavigate('growth-insights')}>
              Open Diagnostics
            </Button>
          </div>

          {weakPoints.length === 0 ? (
            <div className="py-10 text-center border border-dashed border-slate-200 rounded-xl bg-emerald-50/30 px-4">
              <p className="text-sm font-bold text-emerald-800">All Financial Vectors Nominal</p>
              <p className="text-xs text-slate-600 mt-1">
                No declining collection rates, margin compression, or expense spikes detected for{' '}
                {currentMetrics.label}.
              </p>
            </div>
          ) : (
            <div className="space-y-3.5">
              {weakPoints.slice(0, 4).map((wp) => (
                <div
                  key={wp.id}
                  className="p-3.5 rounded-lg border border-slate-200/90 bg-slate-50/60"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-slate-900">{wp.metricName}</span>
                    <StatusText
                      tone={
                        wp.severity === 'critical'
                          ? 'danger'
                          : wp.severity === 'warning'
                          ? 'warning'
                          : 'info'
                      }
                      label={`${wp.severity.toUpperCase()} · ${wp.percentChangeFormatted}`}
                    />
                  </div>
                  <p className="text-xs text-slate-600 mt-1 leading-relaxed">{wp.reason}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
