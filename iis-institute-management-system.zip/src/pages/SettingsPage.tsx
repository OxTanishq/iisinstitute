import React, { useEffect, useState } from 'react';
import { Plus, Archive, ShieldCheck, Edit2, Trash2, RotateCcw } from 'lucide-react';
import { toast } from 'sonner';
import { useInstitute } from '../context/InstituteContext';
import { Batch, Course, UserProfile, UserRole } from '../shared/types';
import { formatINR } from '../shared/finance';
import {
  Button,
  ConfirmDeleteDialog,
  Dialog,
  DialogContent,
  EmptyState,
  Input,
  Label,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  StatusText,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '../components/ui/primitives';

// Page 13: Settings (Institute Branding, Courses & Batches Catalog, RBAC Access Control)
export function SettingsPage() {
  const {
    activeRole,
    currentUserProfile,
    isDemoMode,
    settings,
    courses,
    batches,
    teachers,
    users,
    saveInstituteSettings,
    resetInstituteSettings,
    createCourse,
    updateCourse,
    archiveCourse,
    deleteCourse,
    createBatch,
    updateBatch,
    deleteBatch,
    updateUserRole,
    deleteUserProfile,
  } = useInstitute();

  const isAdmin = activeRole === UserRole.ADMIN;

  // Profile Settings State
  const [instituteName, setInstituteName] = useState(settings.instituteName);
  const [logoUrl, setLogoUrl] = useState(settings.logoUrl);
  const [tagline, setTagline] = useState(settings.tagline);
  const [phone, setPhone] = useState(settings.phone);
  const [email, setEmail] = useState(settings.email);
  const [address, setAddress] = useState(settings.address);
  const [city, setCity] = useState(settings.city);
  const [receiptPrefix, setReceiptPrefix] = useState(settings.receiptPrefix);
  const [defaultDueDay, setDefaultDueDay] = useState(String(settings.defaultDueDay));
  const [financialYearStartMonth, setFinancialYearStartMonth] = useState(
    String(settings.financialYearStartMonth)
  );
  const [savingSettings, setSavingSettings] = useState(false);
  const [resetSettingsConfirmOpen, setResetSettingsConfirmOpen] = useState(false);

  useEffect(() => {
    setInstituteName(settings.instituteName);
    setLogoUrl(settings.logoUrl);
    setTagline(settings.tagline);
    setPhone(settings.phone);
    setEmail(settings.email);
    setAddress(settings.address);
    setCity(settings.city);
    setReceiptPrefix(settings.receiptPrefix);
    setDefaultDueDay(String(settings.defaultDueDay));
    setFinancialYearStartMonth(String(settings.financialYearStartMonth));
  }, [settings]);

  // Course Modal State
  const [courseModalOpen, setCourseModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [deleteTargetCourse, setDeleteTargetCourse] = useState<Course | null>(null);
  const [courseCode, setCourseCode] = useState('');
  const [courseName, setCourseName] = useState('');
  const [subjectCategory, setSubjectCategory] = useState('Science & Competitive');
  const [defaultFeeRupees, setDefaultFeeRupees] = useState('3500');
  const [durationMonths, setDurationMonths] = useState('12');
  const [courseStatus, setCourseStatus] = useState<'ACTIVE' | 'ARCHIVED'>('ACTIVE');

  // Batch Modal State
  const [batchModalOpen, setBatchModalOpen] = useState(false);
  const [editingBatch, setEditingBatch] = useState<Batch | null>(null);
  const [deleteTargetBatch, setDeleteTargetBatch] = useState<Batch | null>(null);
  const [batchCode, setBatchCode] = useState('');
  const [batchName, setBatchName] = useState('');
  const [batchCourseId, setBatchCourseId] = useState('');
  const [batchTeacherId, setBatchTeacherId] = useState('');
  const [scheduleLabel, setScheduleLabel] = useState('Mon · Wed · Fri — 4:30 PM IST');
  const [batchStatus, setBatchStatus] = useState<'ACTIVE' | 'ARCHIVED'>('ACTIVE');

  // User Edit / Delete Modal State
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [deleteTargetUser, setDeleteTargetUser] = useState<UserProfile | null>(null);
  const [userDisplayName, setUserDisplayName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [roleValue, setRoleValue] = useState<UserRole>(UserRole.TEACHER);
  const [linkedTeacherId, setLinkedTeacherId] = useState<string>('NONE');
  const [userStatus, setUserStatus] = useState<'ACTIVE' | 'SUSPENDED'>('ACTIVE');
  const [submittingModal, setSubmittingModal] = useState(false);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    setSavingSettings(true);
    try {
      await saveInstituteSettings({
        instituteName: instituteName.trim(),
        logoUrl: logoUrl.trim(),
        tagline: tagline.trim(),
        phone: phone.trim(),
        email: email.trim(),
        address: address.trim(),
        city: city.trim(),
        receiptPrefix: receiptPrefix.trim().toUpperCase(),
        defaultDueDay: Number(defaultDueDay),
        financialYearStartMonth: Number(financialYearStartMonth),
      });
      toast.success('Institute settings updated.');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to save settings.');
    } finally {
      setSavingSettings(false);
    }
  };

  const handleResetSettings = async () => {
    setSavingSettings(true);
    try {
      await resetInstituteSettings();
      toast.success('Institute settings reset to defaults.');
      setResetSettingsConfirmOpen(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to reset settings.');
    } finally {
      setSavingSettings(false);
    }
  };

  const openAddCourseModal = () => {
    setEditingCourse(null);
    setCourseCode('');
    setCourseName('');
    setSubjectCategory('Science & Competitive');
    setDefaultFeeRupees('3500');
    setDurationMonths('12');
    setCourseStatus('ACTIVE');
    setCourseModalOpen(true);
  };

  const openEditCourseModal = (crs: Course) => {
    setEditingCourse(crs);
    setCourseCode(crs.code);
    setCourseName(crs.name);
    setSubjectCategory(crs.subjectCategory);
    setDefaultFeeRupees(String(crs.defaultMonthlyFeePaise / 100));
    setDurationMonths(String(crs.durationMonths));
    setCourseStatus(crs.status);
    setCourseModalOpen(true);
  };

  const handleSaveCourse = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittingModal(true);
    try {
      if (editingCourse) {
        await updateCourse(editingCourse.id, {
          code: courseCode.trim().toUpperCase(),
          name: courseName.trim(),
          subjectCategory: subjectCategory.trim(),
          defaultMonthlyFeeRupees: Number(defaultFeeRupees),
          durationMonths: Number(durationMonths),
          status: courseStatus,
        });
        toast.success(`Updated course "${courseName.trim()}".`);
      } else {
        await createCourse({
          code: courseCode.trim().toUpperCase(),
          name: courseName.trim(),
          subjectCategory: subjectCategory.trim(),
          defaultMonthlyFeeRupees: Number(defaultFeeRupees),
          durationMonths: Number(durationMonths),
        });
        toast.success('Course added to catalog.');
      }
      setCourseModalOpen(false);
      setEditingCourse(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to save course.');
    } finally {
      setSubmittingModal(false);
    }
  };

  const handleConfirmDeleteCourse = async () => {
    if (!deleteTargetCourse) return;
    setSubmittingModal(true);
    try {
      await deleteCourse(deleteTargetCourse.id);
      toast.success(`Deleted course "${deleteTargetCourse.name}".`);
      setDeleteTargetCourse(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete course.');
    } finally {
      setSubmittingModal(false);
    }
  };

  const openAddBatchModal = () => {
    setEditingBatch(null);
    setBatchCode('');
    setBatchName('');
    setBatchCourseId(courses[0]?.id ?? '');
    setBatchTeacherId(teachers[0]?.id ?? '');
    setScheduleLabel('Mon · Wed · Fri — 4:30 PM IST');
    setBatchStatus('ACTIVE');
    setBatchModalOpen(true);
  };

  const openEditBatchModal = (bat: Batch) => {
    setEditingBatch(bat);
    setBatchCode(bat.code);
    setBatchName(bat.name);
    setBatchCourseId(bat.courseId);
    setBatchTeacherId(bat.teacherId);
    setScheduleLabel(bat.scheduleLabel);
    setBatchStatus(bat.status);
    setBatchModalOpen(true);
  };

  const handleSaveBatch = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittingModal(true);
    try {
      if (editingBatch) {
        await updateBatch(editingBatch.id, {
          code: batchCode.trim().toUpperCase(),
          name: batchName.trim(),
          courseId: batchCourseId,
          teacherId: batchTeacherId,
          scheduleLabel: scheduleLabel.trim(),
          status: batchStatus,
        });
        toast.success(`Updated batch "${batchName.trim()}".`);
      } else {
        await createBatch({
          code: batchCode.trim().toUpperCase(),
          name: batchName.trim(),
          courseId: batchCourseId,
          teacherId: batchTeacherId,
          scheduleLabel: scheduleLabel.trim(),
        });
        toast.success('Batch created.');
      }
      setBatchModalOpen(false);
      setEditingBatch(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to save batch.');
    } finally {
      setSubmittingModal(false);
    }
  };

  const handleConfirmDeleteBatch = async () => {
    if (!deleteTargetBatch) return;
    setSubmittingModal(true);
    try {
      await deleteBatch(deleteTargetBatch.id);
      toast.success(`Deleted batch "${deleteTargetBatch.name}".`);
      setDeleteTargetBatch(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete batch.');
    } finally {
      setSubmittingModal(false);
    }
  };

  const openEditUserModal = (u: UserProfile) => {
    setEditingUserId(u.id);
    setUserDisplayName(u.displayName);
    setUserEmail(u.email);
    setRoleValue(u.role);
    setLinkedTeacherId(u.teacherId || 'NONE');
    setUserStatus(u.status);
  };

  const handleSaveUserRole = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUserId) return;
    setSubmittingModal(true);
    try {
      await updateUserRole({
        userId: editingUserId,
        displayName: userDisplayName.trim(),
        email: userEmail.trim(),
        role: roleValue,
        teacherId: linkedTeacherId === 'NONE' ? '' : linkedTeacherId,
        status: userStatus,
      });
      toast.success('User profile and role permissions updated.');
      setEditingUserId(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to update user profile.');
    } finally {
      setSubmittingModal(false);
    }
  };

  const handleConfirmDeleteUser = async () => {
    if (!deleteTargetUser) return;
    setSubmittingModal(true);
    try {
      await deleteUserProfile(deleteTargetUser.id);
      toast.success(`Deleted user profile "${deleteTargetUser.email}".`);
      setDeleteTargetUser(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete user profile.');
    } finally {
      setSubmittingModal(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <p className="text-xs font-semibold text-blue-600">Governance & Configuration</p>
        <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-0.5">
          Institute Settings
        </h1>
        <p className="text-sm text-slate-500 mt-1">
          Configure institute identity, invoice billing defaults, academic courses & batches, and
          role-based access control.
        </p>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList>
          <TabsTrigger value="profile">Institute Profile & Billing</TabsTrigger>
          <TabsTrigger value="catalog">Courses & Batches Catalog</TabsTrigger>
          <TabsTrigger value="access">User Roles & Access Control</TabsTrigger>
        </TabsList>

        {/* Tab 1: Institute Profile */}
        <TabsContent value="profile">
          <div className="bg-white border border-slate-200/90 rounded-xl p-6 max-w-3xl">
            <div className="mb-5 pb-4 border-b border-slate-100">
              <h2 className="text-base font-bold text-slate-900">
                Branding, Contact & Financial Defaults
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Used across student PDF fee receipts, executive financial summaries, and invoice due
                schedules (Currency: INR · Timezone: Asia/Kolkata).
              </p>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="set-name">Institute Name *</Label>
                  <Input
                    id="set-name"
                    value={instituteName}
                    onChange={(e) => setInstituteName(e.target.value)}
                    disabled={!isAdmin}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="set-tagline">Tagline / Subtitle</Label>
                  <Input
                    id="set-tagline"
                    value={tagline}
                    onChange={(e) => setTagline(e.target.value)}
                    disabled={!isAdmin}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="set-phone">Official Phone</Label>
                  <Input
                    id="set-phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    disabled={!isAdmin}
                    placeholder="+91 98765 43210"
                  />
                </div>
                <div>
                  <Label htmlFor="set-email">Official Email</Label>
                  <Input
                    id="set-email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    disabled={!isAdmin}
                    placeholder="office@iisinstitute.in"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="sm:col-span-2">
                  <Label htmlFor="set-address">Campus Street Address</Label>
                  <Input
                    id="set-address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    disabled={!isAdmin}
                    placeholder="2nd Floor, Vidya Bhavan, Civil Lines"
                  />
                </div>
                <div>
                  <Label htmlFor="set-city">City & State</Label>
                  <Input
                    id="set-city"
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    disabled={!isAdmin}
                    placeholder="Pune, Maharashtra"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="set-logo">Custom Institute Logo URL (Optional https://)</Label>
                <Input
                  id="set-logo"
                  type="url"
                  value={logoUrl}
                  onChange={(e) => setLogoUrl(e.target.value)}
                  disabled={!isAdmin}
                  placeholder="https://example.com/logo.png"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                <div>
                  <Label htmlFor="set-prefix">Receipt Prefix *</Label>
                  <Input
                    id="set-prefix"
                    value={receiptPrefix}
                    onChange={(e) => setReceiptPrefix(e.target.value)}
                    disabled={!isAdmin}
                    maxLength={12}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="set-dueday">Default Monthly Due Day (1–28) *</Label>
                  <Input
                    id="set-dueday"
                    type="number"
                    min={1}
                    max={28}
                    value={defaultDueDay}
                    onChange={(e) => setDefaultDueDay(e.target.value)}
                    disabled={!isAdmin}
                    required
                  />
                </div>
                <div>
                  <Label>Financial Year Start Month</Label>
                  <Select
                    value={financialYearStartMonth}
                    onValueChange={setFinancialYearStartMonth}
                    disabled={!isAdmin}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="4">April (Indian FY Apr–Mar)</SelectItem>
                      <SelectItem value="1">January (Calendar Year)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {isAdmin ? (
                <div className="pt-3 flex flex-wrap items-center justify-between gap-3">
                  <Button
                    type="button"
                    variant="outlineDanger"
                    size="sm"
                    disabled={savingSettings}
                    onClick={() => setResetSettingsConfirmOpen(true)}
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                    <span>Reset to Defaults</span>
                  </Button>
                  <Button type="submit" disabled={savingSettings}>
                    {savingSettings ? 'Saving Settings...' : 'Save Institute Settings'}
                  </Button>
                </div>
              ) : (
                <p className="text-xs text-slate-500 pt-2">
                  Read-only view. Only Administrators can modify institute-wide settings.
                </p>
              )}
            </form>
          </div>
        </TabsContent>

        {/* Tab 2: Courses & Batches Catalog */}
        <TabsContent value="catalog" className="space-y-6">
          {/* Courses Card */}
          <div className="bg-white border border-slate-200/90 rounded-xl p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-slate-900">Academic Courses & Fee Schedules</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Standard monthly tuition fees used when enrolling students and issuing monthly
                  invoices
                </p>
              </div>
              {isAdmin && (
                <Button size="sm" onClick={openAddCourseModal}>
                  <Plus className="h-3.5 w-3.5" />
                  <span>Add Course</span>
                </Button>
              )}
            </div>

            {courses.length === 0 ? (
              <EmptyState
                title="No courses configured yet"
                description="Add your coaching courses (e.g., JEE Foundation, NEET Target, Class 10 Mathematics) with default monthly fees."
                actionLabel={isAdmin ? 'Add First Course' : undefined}
                onAction={isAdmin ? openAddCourseModal : undefined}
              />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                      <th className="py-3 px-3">Code</th>
                      <th className="py-3 px-3">Course Name</th>
                      <th className="py-3 px-3">Category</th>
                      <th className="py-3 px-3 text-right">Default Monthly Fee</th>
                      <th className="py-3 px-3 text-right">Duration</th>
                      <th className="py-3 px-3">Status</th>
                      {isAdmin && <th className="py-3 px-3 text-right">Actions</th>}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {courses.map((c) => (
                      <tr key={c.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-3 font-mono text-xs font-semibold text-slate-700">
                          {c.code}
                        </td>
                        <td className="py-3 px-3 font-semibold text-slate-900">{c.name}</td>
                        <td className="py-3 px-3 text-xs text-slate-600">{c.subjectCategory}</td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums font-semibold text-slate-900">
                          {formatINR(c.defaultMonthlyFeePaise)}
                        </td>
                        <td className="py-3 px-3 text-right font-mono text-xs text-slate-600">
                          {c.durationMonths} mo
                        </td>
                        <td className="py-3 px-3">
                          <StatusText
                            tone={c.status === 'ACTIVE' ? 'positive' : 'neutral'}
                            label={c.status}
                          />
                        </td>
                        {isAdmin && (
                          <td className="py-3 px-3 text-right whitespace-nowrap">
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => openEditCourseModal(c)}
                                title="Edit course"
                                className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                              >
                                <Edit2 className="h-3.5 w-3.5" />
                              </button>
                              {c.status === 'ACTIVE' && (
                                <button
                                  type="button"
                                  onClick={async () => {
                                    try {
                                      await archiveCourse(c.id);
                                      toast.success('Course archived.');
                                    } catch (err) {
                                      toast.error(
                                        err instanceof Error ? err.message : 'Archive failed.'
                                      );
                                    }
                                  }}
                                  title="Archive course"
                                  className="p-1.5 rounded-md text-slate-400 hover:text-amber-700 hover:bg-amber-50 cursor-pointer"
                                >
                                  <Archive className="h-3.5 w-3.5" />
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => setDeleteTargetCourse(c)}
                                title="Delete course"
                                className="p-1.5 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Batches Card */}
          <div className="bg-white border border-slate-200/90 rounded-xl p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-slate-900">Classroom Batches</h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Link courses with lead teachers and class timing schedules
                </p>
              </div>
              {isAdmin && (
                <Button
                  size="sm"
                  disabled={courses.length === 0 || teachers.length === 0}
                  onClick={openAddBatchModal}
                >
                  <Plus className="h-3.5 w-3.5" />
                  <span>Create Batch</span>
                </Button>
              )}
            </div>

            {batches.length === 0 ? (
              <EmptyState
                title="No classroom batches created yet"
                description="Ensure at least one Course and one Teacher exist, then create batches with timings."
              />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                      <th className="py-3 px-3">Batch Code</th>
                      <th className="py-3 px-3">Batch Name</th>
                      <th className="py-3 px-3">Course</th>
                      <th className="py-3 px-3">Lead Faculty</th>
                      <th className="py-3 px-3">Schedule</th>
                      <th className="py-3 px-3">Status</th>
                      {isAdmin && <th className="py-3 px-3 text-right">Actions</th>}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {batches.map((b) => (
                      <tr key={b.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-3 font-mono text-xs font-semibold text-slate-700">
                          {b.code}
                        </td>
                        <td className="py-3 px-3 font-semibold text-slate-900">{b.name}</td>
                        <td className="py-3 px-3 text-xs text-slate-700">{b.courseName}</td>
                        <td className="py-3 px-3 text-xs text-slate-700">{b.teacherName}</td>
                        <td className="py-3 px-3 text-xs text-slate-500">{b.scheduleLabel}</td>
                        <td className="py-3 px-3">
                          <StatusText
                            tone={b.status === 'ACTIVE' ? 'positive' : 'neutral'}
                            label={b.status}
                          />
                        </td>
                        {isAdmin && (
                          <td className="py-3 px-3 text-right whitespace-nowrap">
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => openEditBatchModal(b)}
                                title="Edit batch"
                                className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                              >
                                <Edit2 className="h-3.5 w-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeleteTargetBatch(b)}
                                title="Delete batch"
                                className="p-1.5 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Tab 3: RBAC Access Control */}
        <TabsContent value="access">
          <div className="bg-white border border-slate-200/90 rounded-xl p-6 space-y-5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Authorized User Accounts & Role Assignments
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Least-privilege RBAC enforced via Firestore Security Rules. Users cannot
                  self-assign ADMIN privileges.
                </p>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-600">
                <ShieldCheck className="h-4 w-4 text-emerald-600" />
                <span>
                  Signed in as <strong>{currentUserProfile?.email}</strong> ({activeRole})
                </span>
              </div>
            </div>

            {!isAdmin ? (
              <div className="rounded-lg border border-slate-200 bg-slate-50 p-4 text-xs text-slate-600 leading-relaxed">
                Your account operates under the <strong>{activeRole}</strong> role
                {isDemoMode ? ' (Isolated Demo Sandbox)' : ''}. Only Institute Administrators can
                view all user accounts or modify role assignments.
              </div>
            ) : users.length === 0 ? (
              <EmptyState
                title="No user profiles loaded"
                description="Sign in with Google to initialize user profiles."
              />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                      <th className="py-3 px-4">Name & Email</th>
                      <th className="py-3 px-4">UID</th>
                      <th className="py-3 px-4">Role</th>
                      <th className="py-3 px-4">Linked Faculty Profile</th>
                      <th className="py-3 px-4">Account Status</th>
                      <th className="py-3 px-4 text-right">Manage</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-sm">
                    {users.map((u) => {
                      const linkedTeacher = teachers.find((t) => t.id === u.teacherId);
                      const isSelf = u.uid === currentUserProfile?.uid;
                      return (
                        <tr key={u.id} className="hover:bg-slate-50/70">
                          <td className="py-3.5 px-4">
                            <div className="font-semibold text-slate-900">{u.displayName}</div>
                            <div className="text-xs text-slate-500">{u.email}</div>
                          </td>
                          <td className="py-3.5 px-4 font-mono text-xs text-slate-500">
                            {u.uid.slice(0, 14)}…
                          </td>
                          <td className="py-3.5 px-4">
                            <StatusText
                              tone={
                                u.role === UserRole.ADMIN
                                  ? 'info'
                                  : u.role === UserRole.ACCOUNTANT
                                  ? 'warning'
                                  : 'positive'
                              }
                              label={u.role}
                            />
                          </td>
                          <td className="py-3.5 px-4 text-xs text-slate-600">
                            {linkedTeacher
                              ? `${linkedTeacher.fullName} (${linkedTeacher.teacherCode})`
                              : '—'}
                          </td>
                          <td className="py-3.5 px-4">
                            <StatusText
                              tone={u.status === 'ACTIVE' ? 'positive' : 'danger'}
                              label={u.status}
                            />
                          </td>
                          <td className="py-3.5 px-4 text-right whitespace-nowrap">
                            <div className="inline-flex items-center gap-1.5">
                              <Button
                                variant="secondary"
                                size="sm"
                                onClick={() => openEditUserModal(u)}
                              >
                                <Edit2 className="h-3.5 w-3.5" />
                                <span>Edit</span>
                              </Button>
                              <button
                                type="button"
                                disabled={isSelf}
                                onClick={() => setDeleteTargetUser(u)}
                                title={
                                  isSelf
                                    ? 'Cannot delete your own active session profile'
                                    : 'Delete user profile'
                                }
                                className="p-1.5 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 disabled:opacity-35 disabled:pointer-events-none cursor-pointer"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Add / Edit Course Modal */}
      <Dialog
        open={courseModalOpen}
        onOpenChange={(o) => {
          setCourseModalOpen(o);
          if (!o) setEditingCourse(null);
        }}
      >
        <DialogContent
          title={editingCourse ? 'Edit Academic Course' : 'Add Academic Course'}
          description="Define course code, subject stream, standard monthly fee, and catalog status."
        >
          <form onSubmit={handleSaveCourse} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="crs-code">Course Code *</Label>
                <Input
                  id="crs-code"
                  value={courseCode}
                  onChange={(e) => setCourseCode(e.target.value)}
                  placeholder="JEE-ADV-26"
                  required
                />
              </div>
              <div>
                <Label htmlFor="crs-cat">Subject Stream *</Label>
                <Input
                  id="crs-cat"
                  value={subjectCategory}
                  onChange={(e) => setSubjectCategory(e.target.value)}
                  placeholder="Engineering Entrance"
                  required
                />
              </div>
            </div>
            <div>
              <Label htmlFor="crs-name">Course Name *</Label>
              <Input
                id="crs-name"
                value={courseName}
                onChange={(e) => setCourseName(e.target.value)}
                placeholder="IIT-JEE Mains & Advanced Physics + Maths"
                required
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="crs-fee">Default Monthly Fee (INR) *</Label>
                <Input
                  id="crs-fee"
                  type="number"
                  min={0}
                  step="50"
                  value={defaultFeeRupees}
                  onChange={(e) => setDefaultFeeRupees(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="crs-dur">Course Duration (Months) *</Label>
                <Input
                  id="crs-dur"
                  type="number"
                  min={1}
                  max={60}
                  value={durationMonths}
                  onChange={(e) => setDurationMonths(e.target.value)}
                  required
                />
              </div>
            </div>
            {editingCourse && (
              <div>
                <Label>Catalog Status</Label>
                <Select
                  value={courseStatus}
                  onValueChange={(v) => setCourseStatus(v as 'ACTIVE' | 'ARCHIVED')}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ACTIVE">ACTIVE</SelectItem>
                    <SelectItem value="ARCHIVED">ARCHIVED</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}
            <div className="flex justify-end gap-2.5 pt-2">
              <Button
                type="button"
                variant="secondary"
                onClick={() => {
                  setCourseModalOpen(false);
                  setEditingCourse(null);
                }}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={submittingModal}>
                {submittingModal
                  ? 'Saving...'
                  : editingCourse
                  ? 'Save Course Changes'
                  : 'Create Course'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Add / Edit Batch Modal */}
      <Dialog
        open={batchModalOpen}
        onOpenChange={(o) => {
          setBatchModalOpen(o);
          if (!o) setEditingBatch(null);
        }}
      >
        <DialogContent
          title={editingBatch ? 'Edit Classroom Batch' : 'Create Classroom Batch'}
          description="Assign a course and lead faculty member to a scheduled batch."
        >
          <form onSubmit={handleSaveBatch} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="bat-code">Batch Code *</Label>
                <Input
                  id="bat-code"
                  value={batchCode}
                  onChange={(e) => setBatchCode(e.target.value)}
                  placeholder="MOR-A1"
                  required
                />
              </div>
              <div>
                <Label htmlFor="bat-name">Batch Name *</Label>
                <Input
                  id="bat-name"
                  value={batchName}
                  onChange={(e) => setBatchName(e.target.value)}
                  placeholder="Morning Champions Batch A1"
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label>Course *</Label>
                <Select value={batchCourseId} onValueChange={setBatchCourseId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select course" />
                  </SelectTrigger>
                  <SelectContent>
                    {courses.map((c) => (
                      <SelectItem key={c.id} value={c.id}>
                        {c.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Lead Teacher *</Label>
                <Select value={batchTeacherId} onValueChange={setBatchTeacherId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select teacher" />
                  </SelectTrigger>
                  <SelectContent>
                    {teachers.map((t) => (
                      <SelectItem key={t.id} value={t.id}>
                        {t.fullName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="bat-sched">Class Schedule *</Label>
                <Input
                  id="bat-sched"
                  value={scheduleLabel}
                  onChange={(e) => setScheduleLabel(e.target.value)}
                  required
                />
              </div>
              {editingBatch && (
                <div>
                  <Label>Batch Status</Label>
                  <Select
                    value={batchStatus}
                    onValueChange={(v) => setBatchStatus(v as 'ACTIVE' | 'ARCHIVED')}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ACTIVE">ACTIVE</SelectItem>
                      <SelectItem value="ARCHIVED">ARCHIVED</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
            <div className="flex justify-end gap-2.5 pt-2">
              <Button
                type="button"
                variant="secondary"
                onClick={() => {
                  setBatchModalOpen(false);
                  setEditingBatch(null);
                }}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={submittingModal}>
                {submittingModal
                  ? 'Saving...'
                  : editingBatch
                  ? 'Save Batch Changes'
                  : 'Create Batch'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit User Profile & Role Modal */}
      <Dialog
        open={Boolean(editingUserId)}
        onOpenChange={(open) => {
          if (!open) setEditingUserId(null);
        }}
      >
        <DialogContent
          title="Edit User Account & Role Policy"
          description="Update display name, email, system role (ADMIN, ACCOUNTANT, TEACHER), and linked faculty profile."
        >
          <form onSubmit={handleSaveUserRole} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <Label>Display Name *</Label>
                <Input
                  value={userDisplayName}
                  onChange={(e) => setUserDisplayName(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Email Address *</Label>
                <Input
                  type="email"
                  value={userEmail}
                  onChange={(e) => setUserEmail(e.target.value)}
                  required
                />
              </div>
            </div>

            <div>
              <Label>System Role *</Label>
              <Select value={roleValue} onValueChange={(v) => setRoleValue(v as UserRole)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={UserRole.ADMIN}>ADMIN — Full Institute Access</SelectItem>
                  <SelectItem value={UserRole.ACCOUNTANT}>
                    ACCOUNTANT — Fees, Payouts & Expenses
                  </SelectItem>
                  <SelectItem value={UserRole.TEACHER}>
                    TEACHER — Assigned Students & Own Payouts
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Linked Faculty Profile (For Teachers)</Label>
              <Select value={linkedTeacherId} onValueChange={setLinkedTeacherId}>
                <SelectTrigger>
                  <SelectValue placeholder="No linked faculty record" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="NONE">None</SelectItem>
                  {teachers.map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      {t.fullName} ({t.teacherCode})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Account Status *</Label>
              <Select
                value={userStatus}
                onValueChange={(v) => setUserStatus(v as 'ACTIVE' | 'SUSPENDED')}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ACTIVE">ACTIVE</SelectItem>
                  <SelectItem value="SUSPENDED">SUSPENDED</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex justify-end gap-2.5 pt-2">
              <Button type="button" variant="secondary" onClick={() => setEditingUserId(null)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submittingModal}>
                {submittingModal ? 'Updating...' : 'Save Access Policy'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDeleteDialog
        open={resetSettingsConfirmOpen}
        onOpenChange={setResetSettingsConfirmOpen}
        title="Reset Institute Settings"
        description="Reset institute branding, contact details, receipt prefix, and due day back to factory defaults?"
        confirmLabel="Reset Settings"
        loading={savingSettings}
        onConfirm={handleResetSettings}
      />

      <ConfirmDeleteDialog
        open={Boolean(deleteTargetCourse)}
        onOpenChange={(o) => !o && setDeleteTargetCourse(null)}
        title="Delete Academic Course"
        description={
          deleteTargetCourse
            ? `Permanently delete course "${deleteTargetCourse.name}" (${deleteTargetCourse.code}) from the catalog?`
            : ''
        }
        loading={submittingModal}
        onConfirm={handleConfirmDeleteCourse}
      />

      <ConfirmDeleteDialog
        open={Boolean(deleteTargetBatch)}
        onOpenChange={(o) => !o && setDeleteTargetBatch(null)}
        title="Delete Classroom Batch"
        description={
          deleteTargetBatch
            ? `Permanently delete classroom batch "${deleteTargetBatch.name}" (${deleteTargetBatch.code})?`
            : ''
        }
        loading={submittingModal}
        onConfirm={handleConfirmDeleteBatch}
      />

      <ConfirmDeleteDialog
        open={Boolean(deleteTargetUser)}
        onOpenChange={(o) => !o && setDeleteTargetUser(null)}
        title="Delete User Profile"
        description={
          deleteTargetUser
            ? `Permanently delete user profile "${deleteTargetUser.displayName}" (${deleteTargetUser.email})?`
            : ''
        }
        loading={submittingModal}
        onConfirm={handleConfirmDeleteUser}
      />
    </div>
  );
}
