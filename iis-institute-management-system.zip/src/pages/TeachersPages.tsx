import React, { useMemo, useState } from 'react';
import { Plus, FileCheck2, Wallet, Download, Edit2, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { useInstitute } from '../context/InstituteContext';
import {
  AllocationStatus,
  PaymentMethod,
  PayoutStatus,
  Teacher,
  TeacherAgreement,
  TeacherCompensationModel,
  TeacherPayout,
  TeacherShareAllocation,
  UserRole,
} from '../shared/types';
import {
  findEffectiveAgreement,
  formatINR,
  formatPeriodLabel,
  getTodayIST,
} from '../shared/finance';
import { downloadServerCSV } from '../lib/pdfExport';
import {
  Button,
  ConfirmDeleteDialog,
  Dialog,
  DialogContent,
  EmptyState,
  Input,
  Label,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  StatusText,
} from '../components/ui/primitives';

// Page 6: Teachers & Compensation Agreements
export function TeachersPage() {
  const {
    activeRole,
    teachers,
    agreements,
    students,
    createTeacher,
    updateTeacher,
    deleteTeacher,
    saveTeacherAgreement,
    updateTeacherAgreement,
    deleteTeacherAgreement,
  } = useInstitute();

  const [teacherModalOpen, setTeacherModalOpen] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null);
  const [deleteTargetTeacher, setDeleteTargetTeacher] = useState<Teacher | null>(null);

  const [agreementModalOpen, setAgreementModalOpen] = useState(false);
  const [editingAgreement, setEditingAgreement] = useState<TeacherAgreement | null>(null);
  const [deleteTargetAgreement, setDeleteTargetAgreement] = useState<TeacherAgreement | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Teacher Form State
  const [teacherCode, setTeacherCode] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [specialization, setSpecialization] = useState('');
  const [subjectsText, setSubjectsText] = useState('');
  const [linkedUserUid, setLinkedUserUid] = useState('');
  const [joinedDate, setJoinedDate] = useState(getTodayIST());
  const [status, setStatus] = useState<'ACTIVE' | 'ARCHIVED'>('ACTIVE');

  // Agreement Form State
  const [agTeacherId, setAgTeacherId] = useState('');
  const [agModelType, setAgModelType] = useState<TeacherCompensationModel>(
    TeacherCompensationModel.PERCENTAGE
  );
  const [agSharePercent, setAgSharePercent] = useState('40');
  const [agFixedRupees, setAgFixedRupees] = useState('0');
  const [agPerStudentRupees, setAgPerStudentRupees] = useState('0');
  const [agEffectiveFrom, setAgEffectiveFrom] = useState(getTodayIST());
  const [agEffectiveTo, setAgEffectiveTo] = useState('');
  const [agNotes, setAgNotes] = useState('');
  const [agStatus, setAgStatus] = useState<'ACTIVE' | 'SUPERSEDED'>('ACTIVE');

  const openAddTeacher = () => {
    setEditingTeacher(null);
    setTeacherCode(`FAC-${101 + teachers.length}`);
    setFullName('');
    setEmail('');
    setPhone('');
    setSpecialization('');
    setSubjectsText('Physics, Mathematics');
    setLinkedUserUid('');
    setJoinedDate(getTodayIST());
    setStatus('ACTIVE');
    setTeacherModalOpen(true);
  };

  const openEditTeacher = (t: Teacher) => {
    setEditingTeacher(t);
    setTeacherCode(t.teacherCode);
    setFullName(t.fullName);
    setEmail(t.email);
    setPhone(t.phone);
    setSpecialization(t.specialization);
    setSubjectsText(t.subjects.join(', '));
    setLinkedUserUid(t.linkedUserUid);
    setJoinedDate(t.joinedDate);
    setStatus(t.status);
    setTeacherModalOpen(true);
  };

  const openAgreementModal = (teacherId?: string) => {
    setEditingAgreement(null);
    const targetId = teacherId ?? teachers[0]?.id ?? '';
    setAgTeacherId(targetId);
    const existing = findEffectiveAgreement(agreements, targetId, getTodayIST());
    if (existing) {
      setAgModelType(existing.modelType);
      setAgSharePercent(String(existing.shareBasisPoints / 100));
      setAgFixedRupees(String(existing.fixedMonthlyPaise / 100));
      setAgPerStudentRupees(String(existing.perStudentPaise / 100));
    } else {
      setAgModelType(TeacherCompensationModel.PERCENTAGE);
      setAgSharePercent('40');
      setAgFixedRupees('0');
      setAgPerStudentRupees('0');
    }
    setAgEffectiveFrom(getTodayIST());
    setAgEffectiveTo('');
    setAgNotes('');
    setAgStatus('ACTIVE');
    setAgreementModalOpen(true);
  };

  const openEditAgreementModal = (ag: TeacherAgreement) => {
    setEditingAgreement(ag);
    setAgTeacherId(ag.teacherId);
    setAgModelType(ag.modelType);
    setAgSharePercent(String(ag.shareBasisPoints / 100));
    setAgFixedRupees(String(ag.fixedMonthlyPaise / 100));
    setAgPerStudentRupees(String(ag.perStudentPaise / 100));
    setAgEffectiveFrom(ag.effectiveFrom);
    setAgEffectiveTo(ag.effectiveTo);
    setAgNotes(ag.notes);
    setAgStatus(ag.status);
    setAgreementModalOpen(true);
  };

  const handleSaveTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const subjects = subjectsText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean)
        .slice(0, 10);

      if (editingTeacher) {
        await updateTeacher(editingTeacher.id, {
          teacherCode,
          fullName,
          email,
          phone,
          specialization,
          subjects,
          linkedUserUid,
          joinedDate,
          status,
        });
        toast.success(`Updated faculty record for ${fullName}`);
      } else {
        await createTeacher({
          teacherCode,
          fullName,
          email,
          phone,
          specialization,
          subjects,
          linkedUserUid,
          joinedDate,
        });
        toast.success(`Added faculty member ${fullName}`);
      }
      setTeacherModalOpen(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to save faculty');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDeleteTeacher = async () => {
    if (!deleteTargetTeacher) return;
    setSubmitting(true);
    try {
      const name = deleteTargetTeacher.fullName;
      await deleteTeacher(deleteTargetTeacher.id);
      toast.success(`Deleted faculty ${name} and linked contracts/allocations`);
      setDeleteTargetTeacher(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete faculty');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSaveAgreement = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      if (editingAgreement) {
        await updateTeacherAgreement(editingAgreement.id, {
          teacherId: agTeacherId,
          modelType: agModelType,
          fixedMonthlyRupees: Number(agFixedRupees) || 0,
          sharePercentage: Number(agSharePercent) || 0,
          perStudentRupees: Number(agPerStudentRupees) || 0,
          effectiveFrom: agEffectiveFrom,
          effectiveTo: agEffectiveTo,
          notes: agNotes,
          status: agStatus,
        });
        toast.success('Updated teacher compensation agreement');
      } else {
        await saveTeacherAgreement({
          teacherId: agTeacherId,
          modelType: agModelType,
          fixedMonthlyRupees: Number(agFixedRupees) || 0,
          sharePercentage: Number(agSharePercent) || 0,
          perStudentRupees: Number(agPerStudentRupees) || 0,
          effectiveFrom: agEffectiveFrom,
          effectiveTo: agEffectiveTo,
          notes: agNotes,
        });
        toast.success('Saved effective-dated compensation agreement');
      }
      setAgreementModalOpen(false);
      setEditingAgreement(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to save agreement');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDeleteAgreement = async () => {
    if (!deleteTargetAgreement) return;
    setSubmitting(true);
    try {
      await deleteTeacherAgreement(deleteTargetAgreement.id);
      toast.success(`Deleted compensation agreement for ${deleteTargetAgreement.teacherName}`);
      setDeleteTargetAgreement(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete agreement');
    } finally {
      setSubmitting(false);
    }
  };

  const formatAgreementSummary = (tId: string): string => {
    const ag = findEffectiveAgreement(agreements, tId, getTodayIST());
    if (!ag) return 'No active agreement configured';
    switch (ag.modelType) {
      case TeacherCompensationModel.PERCENTAGE:
        return `${(ag.shareBasisPoints / 100).toFixed(ag.shareBasisPoints % 100 === 0 ? 0 : 2)}% of collected fees`;
      case TeacherCompensationModel.FIXED_SALARY:
        return `${formatINR(ag.fixedMonthlyPaise)} / month fixed`;
      case TeacherCompensationModel.PER_STUDENT:
        return `${formatINR(ag.perStudentPaise)} / active paid student`;
      case TeacherCompensationModel.CUSTOM:
        return `${formatINR(ag.fixedMonthlyPaise)}/mo + ${(ag.shareBasisPoints / 100).toFixed(0)}% fee share`;
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-blue-600 mb-1">
            Faculty Roster & Revenue-Share Contracts
          </p>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">Teachers</h1>
        </div>

        {activeRole === UserRole.ADMIN && (
          <div className="flex items-center gap-2.5">
            {teachers.length > 0 && (
              <Button variant="secondary" size="sm" onClick={() => openAgreementModal()}>
                <FileCheck2 className="h-3.5 w-3.5 text-blue-600" />
                <span>Define Share Agreement</span>
              </Button>
            )}
            <Button size="sm" onClick={openAddTeacher}>
              <Plus className="h-4 w-4" />
              <span>Add Faculty</span>
            </Button>
          </div>
        )}
      </div>

      {/* Teachers Roster */}
      <div className="bg-white border border-slate-200/90 rounded-xl overflow-hidden">
        {teachers.length === 0 ? (
          <div className="p-6">
            <EmptyState
              title="No faculty records found"
              description="Add teachers and configure their compensation agreements (percentage share, fixed monthly salary, per-student rate, or custom hybrid)."
              actionLabel={activeRole === UserRole.ADMIN ? 'Add Faculty' : undefined}
              onAction={activeRole === UserRole.ADMIN ? openAddTeacher : undefined}
            />
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-xs font-semibold text-slate-500">
                  <th className="py-3 px-4">Code</th>
                  <th className="py-3 px-4">Faculty Member</th>
                  <th className="py-3 px-4">Subjects & Specialization</th>
                  <th className="py-3 px-4 text-right">Assigned Students</th>
                  <th className="py-3 px-4">Active Compensation Model</th>
                  <th className="py-3 px-4">Status</th>
                  {activeRole === UserRole.ADMIN && (
                    <th className="py-3 px-4 text-right">Manage</th>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {teachers.map((t) => {
                  const stuCount = students.filter(
                    (s) => s.assignedTeacherId === t.id && s.status === 'ACTIVE'
                  ).length;
                  return (
                    <tr key={t.id} className="hover:bg-slate-50/80">
                      <td className="py-3 px-4 font-mono text-xs text-slate-600">
                        {t.teacherCode}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{t.fullName}</div>
                        <div className="text-xs text-slate-500">{t.email}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="text-slate-800">{t.specialization || 'Faculty'}</div>
                        <div className="text-xs text-slate-500">{t.subjects.join(' · ')}</div>
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums font-semibold">
                        {stuCount}
                      </td>
                      <td className="py-3 px-4 font-mono text-xs text-blue-700 font-semibold">
                        {formatAgreementSummary(t.id)}
                      </td>
                      <td className="py-3 px-4">
                        <StatusText
                          tone={t.status === 'ACTIVE' ? 'positive' : 'neutral'}
                          label={t.status}
                        />
                      </td>
                      {activeRole === UserRole.ADMIN && (
                        <td className="py-3 px-4 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1.5">
                            <Button
                              size="sm"
                              variant="secondary"
                              onClick={() => openAgreementModal(t.id)}
                            >
                              Set Share
                            </Button>
                            <button
                              type="button"
                              onClick={() => openEditTeacher(t)}
                              title="Edit faculty"
                              className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                            >
                              <Edit2 className="h-3.5 w-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeleteTargetTeacher(t)}
                              title="Delete faculty"
                              className="p-1.5 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Historical Agreement Terms Log */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-6 space-y-4">
        <div>
          <h2 className="text-base font-bold text-slate-900">
            Historical & Active Compensation Agreements
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Defining a new effective-dated agreement supersedes prior terms automatically, or you
            can directly edit or delete individual contract rows below.
          </p>
        </div>

        {agreements.length === 0 ? (
          <EmptyState
            title="No compensation agreements defined"
            description="Set percentage shares, fixed retainers, or per-student agreements for your faculty."
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 font-semibold">
                  <th className="py-2.5 pr-3">Teacher</th>
                  <th className="py-2.5 px-3">Model</th>
                  <th className="py-2.5 px-3">Terms</th>
                  <th className="py-2.5 px-3">Effective From → To</th>
                  <th className="py-2.5 px-3">State</th>
                  {activeRole === UserRole.ADMIN && (
                    <th className="py-2.5 pl-3 text-right">Actions</th>
                  )}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {agreements.map((ag) => (
                  <tr key={ag.id} className="hover:bg-slate-50/70">
                    <td className="py-2.5 pr-3 font-semibold text-slate-900">{ag.teacherName}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-600">{ag.modelType}</td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-slate-800">
                      {ag.modelType === TeacherCompensationModel.PERCENTAGE &&
                        `${(ag.shareBasisPoints / 100).toFixed(1)}% of collected student fees`}
                      {ag.modelType === TeacherCompensationModel.FIXED_SALARY &&
                        `${formatINR(ag.fixedMonthlyPaise)} / month`}
                      {ag.modelType === TeacherCompensationModel.PER_STUDENT &&
                        `${formatINR(ag.perStudentPaise)} / paid student`}
                      {ag.modelType === TeacherCompensationModel.CUSTOM &&
                        `${formatINR(ag.fixedMonthlyPaise)}/mo + ${(ag.shareBasisPoints / 100).toFixed(1)}% fee share`}
                    </td>
                    <td className="py-2.5 px-3 font-mono text-slate-600">
                      {ag.effectiveFrom} → {ag.effectiveTo || 'Present'}
                    </td>
                    <td className="py-2.5 px-3">
                      <StatusText
                        tone={ag.status === 'ACTIVE' ? 'positive' : 'neutral'}
                        label={ag.status}
                      />
                    </td>
                    {activeRole === UserRole.ADMIN && (
                      <td className="py-2.5 pl-3 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => openEditAgreementModal(ag)}
                            title="Edit agreement"
                            className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                          >
                            <Edit2 className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeleteTargetAgreement(ag)}
                            title="Delete agreement"
                            className="p-1.5 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add / Edit Teacher Dialog */}
      <Dialog open={teacherModalOpen} onOpenChange={setTeacherModalOpen}>
        <DialogContent
          title={editingTeacher ? 'Edit Faculty Profile' : 'Add Faculty Member'}
          description="Link an optional Firebase User UID so the teacher can sign in and access their assigned students and personal payouts."
        >
          <form onSubmit={handleSaveTeacher} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Teacher Code</Label>
                <Input
                  value={teacherCode}
                  onChange={(e) => setTeacherCode(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Joined Date</Label>
                <Input
                  type="date"
                  value={joinedDate}
                  onChange={(e) => setJoinedDate(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Full Name</Label>
                <Input
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Dr. Ananya Verma"
                  required
                />
              </div>
              <div>
                <Label>Email Address</Label>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="faculty@iisinstitute.edu.in"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Phone</Label>
                <Input value={phone} onChange={(e) => setPhone(e.target.value)} />
              </div>
              <div>
                <Label>Specialization</Label>
                <Input
                  value={specialization}
                  onChange={(e) => setSpecialization(e.target.value)}
                  placeholder="IIT-JEE Physics"
                />
              </div>
            </div>

            <div>
              <Label>Subjects Taught (Comma-separated)</Label>
              <Input
                value={subjectsText}
                onChange={(e) => setSubjectsText(e.target.value)}
                placeholder="Physics, Mathematics"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <Label>Linked Firebase User UID (Optional)</Label>
                <Input
                  value={linkedUserUid}
                  onChange={(e) => setLinkedUserUid(e.target.value)}
                  placeholder="Paste UID from Settings > User Roles"
                  className="font-mono text-xs"
                />
              </div>
              {editingTeacher && (
                <div>
                  <Label>Faculty Status</Label>
                  <Select
                    value={status}
                    onValueChange={(v) => setStatus(v as 'ACTIVE' | 'ARCHIVED')}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ACTIVE">ACTIVE</SelectItem>
                      <SelectItem value="ARCHIVED">ARCHIVED</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <Button type="button" variant="secondary" onClick={() => setTeacherModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? 'Saving...' : 'Save Faculty'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Define / Edit Agreement Dialog */}
      <Dialog
        open={agreementModalOpen}
        onOpenChange={(o) => {
          setAgreementModalOpen(o);
          if (!o) setEditingAgreement(null);
        }}
      >
        <DialogContent
          title={
            editingAgreement
              ? 'Edit Teacher Compensation Agreement'
              : 'Define Teacher Compensation Agreement'
          }
          description="Example: At 40% share, an eligible ₹2,000 collected fee automatically accrues ₹800 for the teacher."
        >
          <form onSubmit={handleSaveAgreement} className="space-y-4">
            <div>
              <Label>Faculty Member</Label>
              <Select value={agTeacherId} onValueChange={setAgTeacherId}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {teachers.map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      {t.fullName} ({t.teacherCode})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Payment Model</Label>
                <Select
                  value={agModelType}
                  onValueChange={(v) => setAgModelType(v as TeacherCompensationModel)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={TeacherCompensationModel.PERCENTAGE}>
                      Percentage of Collected Fees
                    </SelectItem>
                    <SelectItem value={TeacherCompensationModel.FIXED_SALARY}>
                      Fixed Monthly Salary
                    </SelectItem>
                    <SelectItem value={TeacherCompensationModel.PER_STUDENT}>
                      Fixed Amount per Student
                    </SelectItem>
                    <SelectItem value={TeacherCompensationModel.CUSTOM}>
                      Custom Hybrid (Base + %)
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Effective Start Date</Label>
                <Input
                  type="date"
                  value={agEffectiveFrom}
                  onChange={(e) => setAgEffectiveFrom(e.target.value)}
                  required
                />
              </div>
            </div>

            {editingAgreement && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Effective End Date (Optional)</Label>
                  <Input
                    type="date"
                    value={agEffectiveTo}
                    onChange={(e) => setAgEffectiveTo(e.target.value)}
                  />
                </div>
                <div>
                  <Label>Agreement State</Label>
                  <Select
                    value={agStatus}
                    onValueChange={(v) => setAgStatus(v as 'ACTIVE' | 'SUPERSEDED')}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ACTIVE">ACTIVE</SelectItem>
                      <SelectItem value="SUPERSEDED">SUPERSEDED</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {(agModelType === TeacherCompensationModel.PERCENTAGE ||
              agModelType === TeacherCompensationModel.CUSTOM) && (
              <div>
                <Label>Revenue Share Percentage (%)</Label>
                <Input
                  type="number"
                  min="0"
                  max="100"
                  step="0.5"
                  value={agSharePercent}
                  onChange={(e) => setAgSharePercent(e.target.value)}
                  required
                />
                <p className="text-[11px] text-slate-500 mt-1 font-mono">
                  Sample check: On ₹2,000 fee →{' '}
                  {formatINR(Math.round((200000 * (Number(agSharePercent) || 0)) / 100))} teacher
                  share
                </p>
              </div>
            )}

            {(agModelType === TeacherCompensationModel.FIXED_SALARY ||
              agModelType === TeacherCompensationModel.CUSTOM) && (
              <div>
                <Label>Fixed Monthly Retainer / Salary (₹)</Label>
                <Input
                  type="number"
                  min="0"
                  step="100"
                  value={agFixedRupees}
                  onChange={(e) => setAgFixedRupees(e.target.value)}
                  required
                />
              </div>
            )}

            {agModelType === TeacherCompensationModel.PER_STUDENT && (
              <div>
                <Label>Amount per Paid Student per Month (₹)</Label>
                <Input
                  type="number"
                  min="0"
                  step="50"
                  value={agPerStudentRupees}
                  onChange={(e) => setAgPerStudentRupees(e.target.value)}
                  required
                />
              </div>
            )}

            <div>
              <Label>Agreement Notes</Label>
              <Input
                value={agNotes}
                onChange={(e) => setAgNotes(e.target.value)}
                placeholder="e.g., JEE batch revenue share contract"
              />
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <Button
                type="button"
                variant="secondary"
                onClick={() => {
                  setAgreementModalOpen(false);
                  setEditingAgreement(null);
                }}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting
                  ? 'Saving...'
                  : editingAgreement
                  ? 'Update Agreement'
                  : 'Save Agreement'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDeleteDialog
        open={Boolean(deleteTargetTeacher)}
        onOpenChange={(o) => !o && setDeleteTargetTeacher(null)}
        title="Delete Faculty Member"
        description={
          deleteTargetTeacher
            ? `Permanently delete faculty profile "${deleteTargetTeacher.fullName}" (${deleteTargetTeacher.teacherCode}) along with all linked compensation agreements, share allocations, and payout records?`
            : ''
        }
        loading={submitting}
        onConfirm={handleConfirmDeleteTeacher}
      />

      <ConfirmDeleteDialog
        open={Boolean(deleteTargetAgreement)}
        onOpenChange={(o) => !o && setDeleteTargetAgreement(null)}
        title="Delete Compensation Agreement"
        description={
          deleteTargetAgreement
            ? `Permanently delete the ${deleteTargetAgreement.modelType} agreement (effective ${deleteTargetAgreement.effectiveFrom}) for ${deleteTargetAgreement.teacherName}?`
            : ''
        }
        loading={submitting}
        onConfirm={handleConfirmDeleteAgreement}
      />
    </div>
  );
}

// Page 7: Teacher Payouts (Separating Accrued Share Liabilities vs Actual Disbursements)
export function TeacherPayoutsPage() {
  const {
    activeRole,
    selectedPeriod,
    teachers,
    allocations,
    payouts,
    accrueMonthlyFixedSalaries,
    updateTeacherAllocation,
    deleteTeacherAllocation,
    recordTeacherPayout,
    updateTeacherPayout,
    deleteTeacherPayout,
    getAuthToken,
    isDemoMode,
  } = useInstitute();

  const canManagePayouts = activeRole !== UserRole.TEACHER;

  const [payoutModalOpen, setPayoutModalOpen] = useState(false);
  const [editingPayout, setEditingPayout] = useState<TeacherPayout | null>(null);
  const [deleteTargetPayout, setDeleteTargetPayout] = useState<TeacherPayout | null>(null);

  const [editingAllocation, setEditingAllocation] = useState<TeacherShareAllocation | null>(null);
  const [deleteTargetAllocation, setDeleteTargetAllocation] =
    useState<TeacherShareAllocation | null>(null);

  const [poTeacherId, setPoTeacherId] = useState('');
  const [poBillingPeriod, setPoBillingPeriod] = useState(selectedPeriod);
  const [poAmountRupees, setPoAmountRupees] = useState('');
  const [poMethod, setPoMethod] = useState<PaymentMethod>(PaymentMethod.BANK_TRANSFER);
  const [poDate, setPoDate] = useState(getTodayIST());
  const [poRef, setPoRef] = useState('');
  const [poStatus, setPoStatus] = useState<PayoutStatus>(PayoutStatus.PAID);

  // Allocation Edit Form State
  const [alBillingPeriod, setAlBillingPeriod] = useState(selectedPeriod);
  const [alBasisRupees, setAlBasisRupees] = useState('0');
  const [alAllocatedRupees, setAlAllocatedRupees] = useState('0');
  const [alSnapshotLabel, setAlSnapshotLabel] = useState('');
  const [alStatus, setAlStatus] = useState<AllocationStatus>(AllocationStatus.ACCRUED);

  const [submitting, setSubmitting] = useState(false);

  const teacherStatements = useMemo(() => {
    return teachers.map((t) => {
      const periodAccrued = allocations
        .filter(
          (a) =>
            a.teacherId === t.id &&
            a.billingPeriod === selectedPeriod &&
            a.status !== AllocationStatus.REVERSED
        )
        .reduce((s, a) => s + a.allocatedAmountPaise, 0);

      const periodPaid = payouts
        .filter(
          (p) =>
            p.teacherId === t.id &&
            p.billingPeriod === selectedPeriod &&
            p.status === PayoutStatus.PAID
        )
        .reduce((s, p) => s + p.amountPaise, 0);

      const duePaise = Math.max(0, periodAccrued - periodPaid);
      return {
        teacher: t,
        periodAccrued,
        periodPaid,
        duePaise,
      };
    });
  }, [teachers, allocations, payouts, selectedPeriod]);

  const totalAccrued = teacherStatements.reduce((s, x) => s + x.periodAccrued, 0);
  const totalDisbursed = teacherStatements.reduce((s, x) => s + x.periodPaid, 0);
  const totalUnpaidDue = teacherStatements.reduce((s, x) => s + x.duePaise, 0);

  const periodAllocations = allocations.filter((a) => a.billingPeriod === selectedPeriod);
  const periodPayouts = payouts.filter((p) => p.billingPeriod === selectedPeriod);

  const openDisburseModal = (tId?: string, duePaise?: number) => {
    setEditingPayout(null);
    const first = teacherStatements.find((s) => s.duePaise > 0) ?? teacherStatements[0];
    setPoTeacherId(tId ?? first?.teacher.id ?? '');
    setPoBillingPeriod(selectedPeriod);
    setPoAmountRupees(
      duePaise !== undefined && duePaise > 0
        ? String(duePaise / 100)
        : first && first.duePaise > 0
        ? String(first.duePaise / 100)
        : ''
    );
    setPoMethod(PaymentMethod.BANK_TRANSFER);
    setPoDate(getTodayIST());
    setPoRef('');
    setPoStatus(PayoutStatus.PAID);
    setPayoutModalOpen(true);
  };

  const openEditPayoutModal = (po: TeacherPayout) => {
    setEditingPayout(po);
    setPoTeacherId(po.teacherId);
    setPoBillingPeriod(po.billingPeriod);
    setPoAmountRupees(String(po.amountPaise / 100));
    setPoMethod(po.paymentMethod);
    setPoDate(po.payoutDate);
    setPoRef(po.referenceNote);
    setPoStatus(po.status);
    setPayoutModalOpen(true);
  };

  const openEditAllocationModal = (al: TeacherShareAllocation) => {
    setEditingAllocation(al);
    setAlBillingPeriod(al.billingPeriod);
    setAlBasisRupees(String(al.basisAmountPaise / 100));
    setAlAllocatedRupees(String(al.allocatedAmountPaise / 100));
    setAlSnapshotLabel(al.rateSnapshotLabel);
    setAlStatus(al.status);
  };

  const handleRunFixedSalaryAccrual = async () => {
    setSubmitting(true);
    try {
      const count = await accrueMonthlyFixedSalaries(selectedPeriod);
      if (count === 0) {
        toast.info(`Fixed retainers already accrued (or none applicable) for ${selectedPeriod}.`);
      } else {
        toast.success(`Accrued ${count} fixed monthly salary obligation(s) for ${selectedPeriod}.`);
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Accrual failed');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSavePayout = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      if (editingPayout) {
        await updateTeacherPayout(editingPayout.id, {
          teacherId: poTeacherId,
          billingPeriod: poBillingPeriod,
          amountRupees: Number(poAmountRupees),
          paymentMethod: poMethod,
          payoutDate: poDate,
          referenceNote: poRef,
          status: poStatus,
        });
        toast.success(`Updated payout ${editingPayout.payoutNumber}`);
      } else {
        await recordTeacherPayout({
          teacherId: poTeacherId,
          billingPeriod: selectedPeriod,
          amountRupees: Number(poAmountRupees),
          paymentMethod: poMethod,
          payoutDate: poDate,
          referenceNote: poRef,
        });
        toast.success('Teacher payout recorded');
      }
      setPayoutModalOpen(false);
      setEditingPayout(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to save payout');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDeletePayout = async () => {
    if (!deleteTargetPayout) return;
    setSubmitting(true);
    try {
      await deleteTeacherPayout(deleteTargetPayout.id);
      toast.success(`Deleted payout ${deleteTargetPayout.payoutNumber}`);
      setDeleteTargetPayout(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete payout');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSaveAllocationEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAllocation) return;
    setSubmitting(true);
    try {
      await updateTeacherAllocation(editingAllocation.id, {
        billingPeriod: alBillingPeriod,
        basisAmountRupees: Number(alBasisRupees),
        allocatedAmountRupees: Number(alAllocatedRupees),
        rateSnapshotLabel: alSnapshotLabel,
        status: alStatus,
      });
      toast.success('Updated teacher share allocation');
      setEditingAllocation(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to update allocation');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDeleteAllocation = async () => {
    if (!deleteTargetAllocation) return;
    setSubmitting(true);
    try {
      await deleteTeacherAllocation(deleteTargetAllocation.id);
      toast.success('Deleted teacher share allocation');
      setDeleteTargetAllocation(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete allocation');
    } finally {
      setSubmitting(false);
    }
  };

  const handleExportStatementsCSV = async () => {
    try {
      const token = await getAuthToken();
      await downloadServerCSV({
        filename: `IIS_Teacher_Payouts_${selectedPeriod}.csv`,
        headers: [
          'Teacher Code',
          'Faculty Name',
          'Period',
          'Accrued Share (INR)',
          'Paid Disbursement (INR)',
          'Unpaid Balance Due (INR)',
        ],
        rows: teacherStatements.map((st) => [
          st.teacher.teacherCode,
          st.teacher.fullName,
          selectedPeriod,
          st.periodAccrued / 100,
          st.periodPaid / 100,
          st.duePaise / 100,
        ]),
        idToken: token,
        isDemoMode,
      });
      toast.success('Exported Teacher Payout Statement CSV');
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Export failed');
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-blue-600 mb-1">
            Accrued Share Liabilities vs Disbursed Cash · {formatPeriodLabel(selectedPeriod)}
          </p>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight">
            Teacher Payouts
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <Button variant="secondary" size="sm" onClick={handleExportStatementsCSV}>
            <Download className="h-3.5 w-3.5" />
            <span>Export CSV</span>
          </Button>
          {activeRole === UserRole.ADMIN && (
            <Button
              variant="secondary"
              size="sm"
              disabled={submitting}
              onClick={handleRunFixedSalaryAccrual}
            >
              Accrue Fixed Salaries
            </Button>
          )}
          {canManagePayouts && (
            <Button
              size="sm"
              disabled={teachers.length === 0}
              onClick={() => openDisburseModal()}
            >
              <Wallet className="h-3.5 w-3.5" />
              <span>Record Payout</span>
            </Button>
          )}
        </div>
      </div>

      {/* 3-Card Separation: Accrued Liability vs Paid Cash vs Unpaid Due */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="text-xs text-slate-500">
            Accrued Teacher Share ({formatPeriodLabel(selectedPeriod)})
          </div>
          <div className="text-2xl font-extrabold font-mono tabular-nums text-slate-900 mt-1.5">
            {formatINR(totalAccrued)}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            Earned from verified fee receipts + retainers
          </div>
        </div>
        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="text-xs text-slate-500">Actual Disbursed Payouts</div>
          <div className="text-2xl font-extrabold font-mono tabular-nums text-emerald-700 mt-1.5">
            {formatINR(totalDisbursed)}
          </div>
          <div className="text-xs text-slate-500 mt-1">Settled via Bank Transfer / UPI / Cash</div>
        </div>
        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="text-xs text-slate-500">Net Payout Liability Due</div>
          <div
            className={`text-2xl font-extrabold font-mono tabular-nums mt-1.5 ${
              totalUnpaidDue > 0 ? 'text-amber-700' : 'text-slate-900'
            }`}
          >
            {formatINR(totalUnpaidDue)}
          </div>
          <div className="text-xs text-slate-500 mt-1">Accrued obligation awaiting disbursement</div>
        </div>
      </div>

      {/* Teacher-Specific Earning Statements */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-6 space-y-4">
        <h2 className="text-base font-bold text-slate-900">
          Faculty Earning Statements ({formatPeriodLabel(selectedPeriod)})
        </h2>
        {teacherStatements.length === 0 ? (
          <EmptyState
            title="No faculty statements to display"
            description="Teacher share statements populate automatically as student fees are collected."
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead>
                <tr className="border-b border-slate-200 text-xs font-semibold text-slate-500">
                  <th className="py-2.5 pr-3">Faculty</th>
                  <th className="py-2.5 px-3 text-right">Accrued Share</th>
                  <th className="py-2.5 px-3 text-right">Paid Payouts</th>
                  <th className="py-2.5 px-3 text-right">Unpaid Due</th>
                  <th className="py-2.5 px-3">Settlement Status</th>
                  {canManagePayouts && <th className="py-2.5 pl-3 text-right">Action</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {teacherStatements.map(({ teacher, periodAccrued, periodPaid, duePaise }) => (
                  <tr key={teacher.id} className="hover:bg-slate-50/80">
                    <td className="py-3 pr-3">
                      <div className="font-semibold text-slate-900">{teacher.fullName}</div>
                      <div className="text-xs text-slate-500 font-mono">{teacher.teacherCode}</div>
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums font-medium">
                      {formatINR(periodAccrued)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums text-emerald-700 font-medium">
                      {formatINR(periodPaid)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono tabular-nums font-bold">
                      {formatINR(duePaise)}
                    </td>
                    <td className="py-3 px-3">
                      {periodAccrued === 0 && periodPaid === 0 ? (
                        <StatusText tone="neutral" label="NO ACCRUAL" />
                      ) : duePaise === 0 ? (
                        <StatusText tone="positive" label="SETTLED" />
                      ) : periodPaid > 0 ? (
                        <StatusText tone="warning" label="PARTIAL PAID" />
                      ) : (
                        <StatusText tone="danger" label="UNPAID DUE" />
                      )}
                    </td>
                    {canManagePayouts && (
                      <td className="py-3 pl-3 text-right">
                        {duePaise > 0 && (
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => openDisburseModal(teacher.id, duePaise)}
                          >
                            Settle {formatINR(duePaise)}
                          </Button>
                        )}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Split View: Share Allocations vs Payout Transactions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white border border-slate-200/90 rounded-xl p-6 space-y-3">
          <h3 className="text-sm font-bold text-slate-900">
            Accrued Share Breakdown (Snapshot Agreement Terms)
          </h3>
          {periodAllocations.length === 0 ? (
            <EmptyState
              title="No share allocations for this month"
              description="Each eligible student fee payment atomically records its historical share allocation here."
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-semibold">
                    <th className="py-2 pr-2">Teacher</th>
                    <th className="py-2 px-2">Source · Snapshot Term</th>
                    <th className="py-2 px-2 text-right">Basis</th>
                    <th className="py-2 px-2 text-right">Share Accrued</th>
                    {canManagePayouts && <th className="py-2 pl-2 text-right">Actions</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {periodAllocations.map((al) => (
                    <tr key={al.id} className="hover:bg-slate-50/70">
                      <td className="py-2.5 pr-2 font-semibold text-slate-800">{al.teacherName}</td>
                      <td className="py-2.5 px-2 text-slate-600">
                        <div>{al.studentName || 'Retainer'}</div>
                        <div className="text-[11px] text-slate-400">{al.rateSnapshotLabel}</div>
                      </td>
                      <td className="py-2.5 px-2 text-right font-mono tabular-nums text-slate-600">
                        {formatINR(al.basisAmountPaise)}
                      </td>
                      <td className="py-2.5 px-2 text-right font-mono tabular-nums font-bold text-blue-700">
                        {al.status === AllocationStatus.REVERSED ? (
                          <span className="line-through text-slate-400">
                            {formatINR(al.allocatedAmountPaise)}
                          </span>
                        ) : (
                          formatINR(al.allocatedAmountPaise)
                        )}
                      </td>
                      {canManagePayouts && (
                        <td className="py-2.5 pl-2 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => openEditAllocationModal(al)}
                              title="Edit share allocation"
                              className="p-1 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                            >
                              <Edit2 className="h-3.5 w-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeleteTargetAllocation(al)}
                              title="Delete share allocation"
                              className="p-1 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="lg:col-span-5 bg-white border border-slate-200/90 rounded-xl p-6 space-y-3">
          <h3 className="text-sm font-bold text-slate-900">Payout Transaction History</h3>
          {periodPayouts.length === 0 ? (
            <EmptyState
              title="No disbursements recorded"
              description={`No cash/bank payouts disbursed for ${formatPeriodLabel(selectedPeriod)} yet.`}
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-semibold">
                    <th className="py-2 pr-2">Payout Ref</th>
                    <th className="py-2 px-2">Teacher · Date</th>
                    <th className="py-2 px-2 text-right">Disbursed</th>
                    {canManagePayouts && <th className="py-2 pl-2 text-right">Actions</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {periodPayouts.map((po) => (
                    <tr key={po.id} className="hover:bg-slate-50/70">
                      <td className="py-2.5 pr-2 font-mono text-slate-600">{po.payoutNumber}</td>
                      <td className="py-2.5 px-2">
                        <div className="font-semibold text-slate-800">{po.teacherName}</div>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {po.payoutDate} · {po.paymentMethod.replace('_', ' ')}
                        </div>
                      </td>
                      <td className="py-2.5 px-2 text-right font-mono tabular-nums font-bold text-emerald-700">
                        {po.status === PayoutStatus.REVERSED ? (
                          <span className="line-through text-slate-400">
                            {formatINR(po.amountPaise)}
                          </span>
                        ) : (
                          formatINR(po.amountPaise)
                        )}
                      </td>
                      {canManagePayouts && (
                        <td className="py-2.5 pl-2 text-right whitespace-nowrap">
                          <div className="inline-flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => openEditPayoutModal(po)}
                              title="Edit payout"
                              className="p-1 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                            >
                              <Edit2 className="h-3.5 w-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => setDeleteTargetPayout(po)}
                              title="Delete payout"
                              className="p-1 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Record / Edit Payout Dialog */}
      <Dialog
        open={payoutModalOpen}
        onOpenChange={(o) => {
          setPayoutModalOpen(o);
          if (!o) setEditingPayout(null);
        }}
      >
        <DialogContent
          title={
            editingPayout
              ? 'Edit Teacher Payout Disbursement'
              : 'Record Teacher Payout Disbursement'
          }
          description={`Settles accrued teacher obligations for ${formatPeriodLabel(selectedPeriod)}.`}
        >
          <form onSubmit={handleSavePayout} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <Label>Faculty Member</Label>
                <Select value={poTeacherId} onValueChange={setPoTeacherId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose faculty" />
                  </SelectTrigger>
                  <SelectContent>
                    {teacherStatements.map((st) => (
                      <SelectItem key={st.teacher.id} value={st.teacher.id}>
                        {st.teacher.fullName} (Due: {formatINR(st.duePaise)})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {editingPayout && (
                <div>
                  <Label>Billing Period (YYYY-MM)</Label>
                  <Input
                    type="month"
                    value={poBillingPeriod}
                    onChange={(e) => setPoBillingPeriod(e.target.value)}
                    required
                  />
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Payout Amount (INR ₹)</Label>
                <Input
                  type="number"
                  min="1"
                  step="0.01"
                  value={poAmountRupees}
                  onChange={(e) => setPoAmountRupees(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Disbursement Mode</Label>
                <Select value={poMethod} onValueChange={(v) => setPoMethod(v as PaymentMethod)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={PaymentMethod.BANK_TRANSFER}>Bank Transfer</SelectItem>
                    <SelectItem value={PaymentMethod.UPI}>UPI</SelectItem>
                    <SelectItem value={PaymentMethod.CASH}>Cash</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Payout Date (IST)</Label>
                <Input
                  type="date"
                  value={poDate}
                  onChange={(e) => setPoDate(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Bank UTR / Reference</Label>
                <Input
                  value={poRef}
                  onChange={(e) => setPoRef(e.target.value)}
                  placeholder="NEFT / UPI Reference"
                />
              </div>
            </div>

            {editingPayout && (
              <div>
                <Label>Payout Status</Label>
                <Select value={poStatus} onValueChange={(v) => setPoStatus(v as PayoutStatus)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={PayoutStatus.PAID}>PAID</SelectItem>
                    <SelectItem value={PayoutStatus.PENDING}>PENDING</SelectItem>
                    <SelectItem value={PayoutStatus.REVERSED}>REVERSED</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <Button
                type="button"
                variant="secondary"
                onClick={() => {
                  setPayoutModalOpen(false);
                  setEditingPayout(null);
                }}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={submitting || !poTeacherId}>
                {submitting
                  ? 'Saving...'
                  : editingPayout
                  ? 'Update Payout'
                  : 'Confirm Payout'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Edit Share Allocation Dialog */}
      <Dialog
        open={Boolean(editingAllocation)}
        onOpenChange={(o) => !o && setEditingAllocation(null)}
      >
        <DialogContent
          title="Edit Accrued Teacher Share Allocation"
          description="Adjust basis fee amount, accrued teacher share, snapshot label, or allocation status."
        >
          <form onSubmit={handleSaveAllocationEdit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Billing Period (YYYY-MM)</Label>
                <Input
                  type="month"
                  value={alBillingPeriod}
                  onChange={(e) => setAlBillingPeriod(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Allocation Status</Label>
                <Select
                  value={alStatus}
                  onValueChange={(v) => setAlStatus(v as AllocationStatus)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={AllocationStatus.ACCRUED}>ACCRUED</SelectItem>
                    <SelectItem value={AllocationStatus.SETTLED}>SETTLED</SelectItem>
                    <SelectItem value={AllocationStatus.REVERSED}>REVERSED</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Basis Amount (INR ₹)</Label>
                <Input
                  type="number"
                  min={0}
                  step="0.01"
                  value={alBasisRupees}
                  onChange={(e) => setAlBasisRupees(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Share Accrued (INR ₹)</Label>
                <Input
                  type="number"
                  min={0}
                  step="0.01"
                  value={alAllocatedRupees}
                  onChange={(e) => setAlAllocatedRupees(e.target.value)}
                  required
                />
              </div>
            </div>

            <div>
              <Label>Agreement Snapshot Term Label</Label>
              <Input
                value={alSnapshotLabel}
                onChange={(e) => setAlSnapshotLabel(e.target.value)}
                required
              />
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
              <Button
                type="button"
                variant="secondary"
                onClick={() => setEditingAllocation(null)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? 'Saving...' : 'Save Allocation'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDeleteDialog
        open={Boolean(deleteTargetAllocation)}
        onOpenChange={(o) => !o && setDeleteTargetAllocation(null)}
        title="Delete Teacher Share Allocation"
        description={
          deleteTargetAllocation
            ? `Permanently delete the ${formatINR(deleteTargetAllocation.allocatedAmountPaise)} share allocation for ${deleteTargetAllocation.teacherName}?`
            : ''
        }
        loading={submitting}
        onConfirm={handleConfirmDeleteAllocation}
      />

      <ConfirmDeleteDialog
        open={Boolean(deleteTargetPayout)}
        onOpenChange={(o) => !o && setDeleteTargetPayout(null)}
        title="Delete Teacher Payout"
        description={
          deleteTargetPayout
            ? `Permanently delete payout ${deleteTargetPayout.payoutNumber} (${formatINR(deleteTargetPayout.amountPaise)}) for ${deleteTargetPayout.teacherName}?`
            : ''
        }
        loading={submitting}
        onConfirm={handleConfirmDeletePayout}
      />
    </div>
  );
}
