import React, { useMemo, useState } from 'react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  ComposedChart,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  Sparkles,
  Download,
  FileText,
  AlertTriangle,
  CheckCircle2,
  Edit2,
  Trash2,
} from 'lucide-react';
import { toast } from 'sonner';
import { useInstitute } from '../context/InstituteContext';
import {
  AuditLog,
  ExpenseCategory,
  InvoiceStatus,
  PaymentStatus,
  PayoutStatus,
  UserRole,
} from '../shared/types';
import {
  calculateMoMGrowth,
  computeMonthlyPeriodMetrics,
  detectInstituteWeakPoints,
  formatINR,
  formatPeriodLabel,
  getTrailingPeriods,
  periodFromDate,
  shiftPeriod,
  toRupees,
} from '../shared/finance';
import { downloadServerCSV, generateFinancialReportPDF } from '../lib/pdfExport';
import { RestrictedFinanceNotice } from './FeesPages';
import {
  Button,
  ConfirmDeleteDialog,
  Dialog,
  DialogContent,
  EmptyState,
  Input,
  Label,
  StatusText,
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
  Textarea,
} from '../components/ui/primitives';

const COURSE_PALETTE = ['#2563EB', '#4F46E5', '#0891B2', '#059669', '#7C3AED', '#D97706'];
const EXPENSE_PALETTE: Record<ExpenseCategory, string> = {
  [ExpenseCategory.RENT]: '#2563EB',
  [ExpenseCategory.UTILITIES]: '#0891B2',
  [ExpenseCategory.MARKETING]: '#7C3AED',
  [ExpenseCategory.MATERIALS]: '#059669',
  [ExpenseCategory.SOFTWARE]: '#4F46E5',
  [ExpenseCategory.MAINTENANCE]: '#D97706',
  [ExpenseCategory.OTHER]: '#64748B',
};

function formatINRTooltip(val: unknown): string {
  return formatINR(Math.round(Number(val ?? 0) * 100));
}

// Page 10: Revenue Analytics (All 8+ Interactive Charts)
export function RevenueAnalyticsPage() {
  const {
    activeRole,
    selectedPeriod,
    students,
    courses,
    invoices,
    payments,
    allocations,
    payouts,
    expenses,
  } = useInstitute();

  const [windowMonths, setWindowMonths] = useState<6 | 12>(12);

  if (activeRole === UserRole.TEACHER) {
    return <RestrictedFinanceNotice />;
  }

  const previousPeriod = useMemo(() => shiftPeriod(selectedPeriod, -1), [selectedPeriod]);
  const trailingPeriods = useMemo(
    () => getTrailingPeriods(selectedPeriod, windowMonths),
    [selectedPeriod, windowMonths]
  );
  const full12Periods = useMemo(() => getTrailingPeriods(selectedPeriod, 12), [selectedPeriod]);

  const seriesMetrics = useMemo(
    () =>
      trailingPeriods.map((period) =>
        computeMonthlyPeriodMetrics({
          period,
          students,
          invoices,
          payments,
          allocations,
          payouts,
          expenses,
        })
      ),
    [trailingPeriods, students, invoices, payments, allocations, payouts, expenses]
  );

  const full12Series = useMemo(
    () =>
      full12Periods.map((period) =>
        computeMonthlyPeriodMetrics({
          period,
          students,
          invoices,
          payments,
          allocations,
          payouts,
          expenses,
        })
      ),
    [full12Periods, students, invoices, payments, allocations, payouts, expenses]
  );

  const currentMetrics = useMemo(
    () =>
      computeMonthlyPeriodMetrics({
        period: selectedPeriod,
        students,
        invoices,
        payments,
        allocations,
        payouts,
        expenses,
      }),
    [selectedPeriod, students, invoices, payments, allocations, payouts, expenses]
  );

  const previousMetrics = useMemo(
    () =>
      computeMonthlyPeriodMetrics({
        period: previousPeriod,
        students,
        invoices,
        payments,
        allocations,
        payouts,
        expenses,
      }),
    [previousPeriod, students, invoices, payments, allocations, payouts, expenses]
  );

  const trendChartData = useMemo(
    () =>
      seriesMetrics.map((m) => ({
        month: m.label,
        invoicedRupees: toRupees(m.invoicedNetPaise),
        collectedRupees: toRupees(m.collectedFeePaise),
        netOperatingRupees: toRupees(m.netOperatingIncomePaise),
        accruedTeacherRupees: toRupees(m.accruedTeacherSharePaise),
        paidTeacherRupees: toRupees(m.paidTeacherPayoutPaise),
        operatingExpensesRupees: toRupees(m.operatingExpensesPaise),
        collectionRate: m.collectionRatePercent,
      })),
    [seriesMetrics]
  );

  const history12Data = useMemo(
    () =>
      full12Series.map((m) => ({
        month: m.label,
        collectedRupees: toRupees(m.collectedFeePaise),
        activeStudents: m.activeStudentsCount,
        newEnrollments: m.newEnrollmentsCount,
      })),
    [full12Series]
  );

  const momComparisonBars = useMemo(
    () => [
      {
        metric: 'Invoiced Net',
        previous: toRupees(previousMetrics.invoicedNetPaise),
        current: toRupees(currentMetrics.invoicedNetPaise),
      },
      {
        metric: 'Collected Fees',
        previous: toRupees(previousMetrics.collectedFeePaise),
        current: toRupees(currentMetrics.collectedFeePaise),
      },
      {
        metric: 'Teacher Accrued',
        previous: toRupees(previousMetrics.accruedTeacherSharePaise),
        current: toRupees(currentMetrics.accruedTeacherSharePaise),
      },
      {
        metric: 'Op. Expenses',
        previous: toRupees(previousMetrics.operatingExpensesPaise),
        current: toRupees(currentMetrics.operatingExpensesPaise),
      },
      {
        metric: 'Net Op. Income',
        previous: toRupees(previousMetrics.netOperatingIncomePaise),
        current: toRupees(currentMetrics.netOperatingIncomePaise),
      },
    ],
    [currentMetrics, previousMetrics]
  );

  const revenueByCourseData = useMemo(() => {
    const map = new Map<string, { name: string; collectedPaise: number; pendingPaise: number }>();
    for (const c of courses) {
      map.set(c.id, { name: c.name, collectedPaise: 0, pendingPaise: 0 });
    }
    for (const p of payments) {
      if (p.status !== PaymentStatus.COMPLETED) continue;
      if (periodFromDate(p.paymentDate) !== selectedPeriod) continue;
      const existing = map.get(p.courseId) ?? {
        name: p.courseName,
        collectedPaise: 0,
        pendingPaise: 0,
      };
      existing.collectedPaise += p.amountPaise;
      map.set(p.courseId, existing);
    }
    for (const inv of invoices) {
      if (inv.status === InvoiceStatus.CANCELLED || inv.billingPeriod !== selectedPeriod) continue;
      const existing = map.get(inv.courseId) ?? {
        name: inv.courseName,
        collectedPaise: 0,
        pendingPaise: 0,
      };
      existing.pendingPaise += inv.balanceDuePaise;
      map.set(inv.courseId, existing);
    }

    return Array.from(map.values())
      .filter((item) => item.collectedPaise > 0 || item.pendingPaise > 0)
      .map((item, idx) => ({
        course: item.name.length > 20 ? `${item.name.slice(0, 18)}…` : item.name,
        collectedRupees: toRupees(item.collectedPaise),
        pendingRupees: toRupees(item.pendingPaise),
        fill: COURSE_PALETTE[idx % COURSE_PALETTE.length],
      }))
      .sort((a, b) => b.collectedRupees - a.collectedRupees);
  }, [courses, payments, invoices, selectedPeriod]);

  const expensesByCategoryData = useMemo(() => {
    const map = new Map<ExpenseCategory, number>();
    for (const ex of expenses) {
      if (ex.status !== 'RECORDED' || ex.billingPeriod !== selectedPeriod) continue;
      map.set(ex.category, (map.get(ex.category) ?? 0) + ex.amountPaise);
    }
    return Array.from(map.entries())
      .map(([cat, paise]) => ({
        category: cat,
        rupees: toRupees(paise),
        fill: EXPENSE_PALETTE[cat],
      }))
      .sort((a, b) => b.rupees - a.rupees);
  }, [expenses, selectedPeriod]);

  const hasAnyFinancialHistory = useMemo(
    () =>
      payments.some((p) => p.status === PaymentStatus.COMPLETED) ||
      invoices.some((i) => i.status !== InvoiceStatus.CANCELLED) ||
      expenses.some((e) => e.status === 'RECORDED'),
    [payments, invoices, expenses]
  );

  return (
    <div className="space-y-6">
      {/* Header & Range Selector */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-blue-600">
            Visual Financial Intelligence · {formatPeriodLabel(selectedPeriod)}
          </p>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-0.5">
            Revenue & Profitability Analytics
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Interactive charts separating invoiced billing, verified fee collections, teacher share
            liabilities, and net operating profit.
          </p>
        </div>

        <div className="inline-flex items-center rounded-lg bg-slate-100 p-1">
          <button
            type="button"
            onClick={() => setWindowMonths(6)}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              windowMonths === 6 ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
            }`}
          >
            Trailing 6 Months
          </button>
          <button
            type="button"
            onClick={() => setWindowMonths(12)}
            className={`px-3.5 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              windowMonths === 12 ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
            }`}
          >
            Trailing 12 Months
          </button>
        </div>
      </div>

      {!hasAnyFinancialHistory ? (
        <EmptyState
          title="No verified financial transactions recorded yet"
          description="Issue student invoices, record fee receipts, or log operating expenses to populate interactive revenue, payout, and margin charts."
        />
      ) : (
        <>
          {/* Row 1: Monthly Collection Line Chart + Current vs Previous Month Comparison Bar Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-7 bg-white border border-slate-200/90 rounded-xl p-6">
              <div className="mb-4">
                <h2 className="text-base font-bold text-slate-900">
                  1. Monthly Fee Collection vs Invoiced Net Trend
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Verified cash/UPI/bank receipts compared against net billed tuition ({windowMonths}{' '}
                  months)
                </p>
              </div>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={trendChartData} margin={{ top: 8, right: 16, left: 4, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                    <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#64748B' }} />
                    <YAxis
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`}
                    />
                    <Tooltip
                      formatter={(val, name) => [
                        formatINRTooltip(val),
                        name === 'collectedRupees' ? 'Collected Revenue' : 'Invoiced Net',
                      ]}
                      contentStyle={{ borderRadius: '10px', borderColor: '#E2E8F0', fontSize: '12px' }}
                    />
                    <Legend
                      formatter={(v) =>
                        v === 'collectedRupees' ? 'Collected Revenue' : 'Invoiced Net'
                      }
                    />
                    <Line
                      type="monotone"
                      dataKey="invoicedRupees"
                      stroke="#94A3B8"
                      strokeWidth={2}
                      strokeDasharray="4 4"
                      dot={{ r: 3 }}
                    />
                    <Line
                      type="monotone"
                      dataKey="collectedRupees"
                      stroke="#2563EB"
                      strokeWidth={3}
                      dot={{ r: 4, fill: '#2563EB' }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="lg:col-span-5 bg-white border border-slate-200/90 rounded-xl p-6">
              <div className="mb-4">
                <h2 className="text-base font-bold text-slate-900">
                  2. {currentMetrics.label} vs {previousMetrics.label} Comparison
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Direct Month-over-Month side-by-side comparison across core P&L buckets
                </p>
              </div>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={momComparisonBars}
                    margin={{ top: 8, right: 12, left: 4, bottom: 0 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                    <XAxis dataKey="metric" tick={{ fontSize: 10.5, fill: '#64748B' }} />
                    <YAxis
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`}
                    />
                    <Tooltip
                      formatter={(val, name) => [
                        formatINRTooltip(val),
                        name === 'current' ? currentMetrics.label : previousMetrics.label,
                      ]}
                      contentStyle={{ borderRadius: '10px', borderColor: '#E2E8F0', fontSize: '12px' }}
                    />
                    <Legend
                      formatter={(v) =>
                        v === 'current' ? currentMetrics.label : previousMetrics.label
                      }
                    />
                    <Bar dataKey="previous" fill="#CBD5E1" radius={[4, 4, 0, 0]} maxBarSize={26} />
                    <Bar dataKey="current" fill="#4F46E5" radius={[4, 4, 0, 0]} maxBarSize={26} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Row 2: Monthly Net Operating Income Chart + Teacher Payout Trends Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-6 bg-white border border-slate-200/90 rounded-xl p-6">
              <div className="mb-4">
                <h2 className="text-base font-bold text-slate-900">
                  3. Monthly Net Operating Income Comparison
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Collected fees minus accrued teacher shares and non-payroll operating expenses
                </p>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trendChartData} margin={{ top: 8, right: 16, left: 4, bottom: 0 }}>
                    <defs>
                      <linearGradient id="netIncomeGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#059669" stopOpacity={0.28} />
                        <stop offset="95%" stopColor="#059669" stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                    <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#64748B' }} />
                    <YAxis
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`}
                    />
                    <Tooltip
                      formatter={(val) => [formatINRTooltip(val), 'Net Operating Income']}
                      contentStyle={{ borderRadius: '10px', borderColor: '#E2E8F0', fontSize: '12px' }}
                    />
                    <Area
                      type="monotone"
                      dataKey="netOperatingRupees"
                      stroke="#059669"
                      strokeWidth={2.5}
                      fill="url(#netIncomeGrad)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="lg:col-span-6 bg-white border border-slate-200/90 rounded-xl p-6">
              <div className="mb-4">
                <h2 className="text-base font-bold text-slate-900">
                  4. Teacher Share Accrual vs Cash Payout Trends
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Separates earned faculty share liabilities from settled bank/UPI disbursements
                </p>
              </div>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={trendChartData} margin={{ top: 8, right: 16, left: 4, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                    <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#64748B' }} />
                    <YAxis
                      tick={{ fontSize: 11, fill: '#64748B' }}
                      tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`}
                    />
                    <Tooltip
                      formatter={(val, name) => [
                        formatINRTooltip(val),
                        name === 'accruedTeacherRupees'
                          ? 'Accrued Share Liability'
                          : 'Paid Cash Disbursement',
                      ]}
                      contentStyle={{ borderRadius: '10px', borderColor: '#E2E8F0', fontSize: '12px' }}
                    />
                    <Legend
                      formatter={(v) =>
                        v === 'accruedTeacherRupees'
                          ? 'Accrued Share Liability'
                          : 'Paid Cash Disbursement'
                      }
                    />
                    <Bar
                      dataKey="accruedTeacherRupees"
                      fill="#7C3AED"
                      radius={[4, 4, 0, 0]}
                      maxBarSize={24}
                    />
                    <Bar
                      dataKey="paidTeacherRupees"
                      fill="#06B6D4"
                      radius={[4, 4, 0, 0]}
                      maxBarSize={24}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Row 3: Revenue by Course + Expenses by Category + Collection Rate Trend */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-4 bg-white border border-slate-200/90 rounded-xl p-6">
              <div className="mb-4">
                <h2 className="text-base font-bold text-slate-900">
                  5. Revenue by Course ({currentMetrics.label})
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Collected vs pending balance per academic program
                </p>
              </div>
              {revenueByCourseData.length === 0 ? (
                <div className="h-60 flex items-center justify-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-lg">
                  No course collections recorded in {currentMetrics.label}.
                </div>
              ) : (
                <div className="h-60">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={revenueByCourseData}
                      layout="vertical"
                      margin={{ top: 4, right: 12, left: 8, bottom: 0 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" horizontal={false} />
                      <XAxis
                        type="number"
                        tick={{ fontSize: 10, fill: '#64748B' }}
                        tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`}
                      />
                      <YAxis
                        type="category"
                        dataKey="course"
                        width={100}
                        tick={{ fontSize: 10.5, fill: '#334155' }}
                      />
                      <Tooltip
                        formatter={(val, name) => [
                          formatINRTooltip(val),
                          name === 'collectedRupees' ? 'Collected' : 'Pending Due',
                        ]}
                        contentStyle={{
                          borderRadius: '10px',
                          borderColor: '#E2E8F0',
                          fontSize: '12px',
                        }}
                      />
                      <Bar
                        dataKey="collectedRupees"
                        stackId="a"
                        fill="#2563EB"
                        radius={[0, 0, 0, 0]}
                        maxBarSize={22}
                      />
                      <Bar
                        dataKey="pendingRupees"
                        stackId="a"
                        fill="#F59E0B"
                        radius={[0, 4, 4, 0]}
                        maxBarSize={22}
                      />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

            <div className="lg:col-span-4 bg-white border border-slate-200/90 rounded-xl p-6">
              <div className="mb-4">
                <h2 className="text-base font-bold text-slate-900">
                  6. Expenses by Category ({currentMetrics.label})
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Non-teacher operating overhead breakdown
                </p>
              </div>
              {expensesByCategoryData.length === 0 ? (
                <div className="h-60 flex items-center justify-center text-xs text-slate-400 border border-dashed border-slate-200 rounded-lg">
                  No operating expenses recorded in {currentMetrics.label}.
                </div>
              ) : (
                <div className="h-60">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={expensesByCategoryData}
                      margin={{ top: 8, right: 12, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                      <XAxis dataKey="category" tick={{ fontSize: 10, fill: '#64748B' }} />
                      <YAxis
                        tick={{ fontSize: 10, fill: '#64748B' }}
                        tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`}
                      />
                      <Tooltip
                        formatter={(val) => [formatINRTooltip(val), 'Operating Spend']}
                        contentStyle={{
                          borderRadius: '10px',
                          borderColor: '#E2E8F0',
                          fontSize: '12px',
                        }}
                      />
                      <Bar dataKey="rupees" radius={[4, 4, 0, 0]} maxBarSize={28}>
                        {expensesByCategoryData.map((entry) => (
                          <Cell key={entry.category} fill={entry.fill} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

            <div className="lg:col-span-4 bg-white border border-slate-200/90 rounded-xl p-6">
              <div className="mb-4">
                <h2 className="text-base font-bold text-slate-900">
                  7. Invoice Collection Rate Trend (%)
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Percentage of billed tuition realized per billing month
                </p>
              </div>
              <div className="h-60">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trendChartData} margin={{ top: 8, right: 12, left: -12, bottom: 0 }}>
                    <defs>
                      <linearGradient id="collRateGrad" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#0891B2" stopOpacity={0.28} />
                        <stop offset="95%" stopColor="#0891B2" stopOpacity={0.02} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                    <XAxis dataKey="month" tick={{ fontSize: 10, fill: '#64748B' }} />
                    <YAxis domain={[0, 100]} unit="%" tick={{ fontSize: 10, fill: '#64748B' }} />
                    <Tooltip
                      formatter={(val) => [`${Number(val ?? 0).toFixed(1)}%`, 'Collection Rate']}
                      contentStyle={{ borderRadius: '10px', borderColor: '#E2E8F0', fontSize: '12px' }}
                    />
                    <Area
                      type="monotone"
                      dataKey="collectionRate"
                      stroke="#0891B2"
                      strokeWidth={2.5}
                      fill="url(#collRateGrad)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Row 4: 12-Month Revenue History & Student Enrollment Growth */}
          <div className="bg-white border border-slate-200/90 rounded-xl p-6">
            <div className="mb-4">
              <h2 className="text-base font-bold text-slate-900">
                8. 12-Month Revenue History & Active Student Enrollment Growth
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Dual-axis trajectory correlating student headcount expansion against monthly cash
                realization
              </p>
            </div>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={history12Data} margin={{ top: 8, right: 18, left: 4, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                  <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#64748B' }} />
                  <YAxis
                    yAxisId="left"
                    tick={{ fontSize: 11, fill: '#64748B' }}
                    tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`}
                  />
                  <YAxis
                    yAxisId="right"
                    orientation="right"
                    allowDecimals={false}
                    tick={{ fontSize: 11, fill: '#64748B' }}
                  />
                  <Tooltip
                    formatter={(val, name) => {
                      if (name === 'collectedRupees') {
                        return [formatINRTooltip(val), 'Collected Revenue'];
                      }
                      return [`${Number(val ?? 0)} students`, name === 'activeStudents' ? 'Active Roster' : 'New Enrollments'];
                    }}
                    contentStyle={{ borderRadius: '10px', borderColor: '#E2E8F0', fontSize: '12px' }}
                  />
                  <Legend
                    formatter={(v) =>
                      v === 'collectedRupees'
                        ? '12M Collected Revenue (INR)'
                        : 'Active Enrolled Students'
                    }
                  />
                  <Bar
                    yAxisId="left"
                    dataKey="collectedRupees"
                    fill="#3B82F6"
                    radius={[4, 4, 0, 0]}
                    maxBarSize={30}
                  />
                  <Line
                    yAxisId="right"
                    type="monotone"
                    dataKey="activeStudents"
                    stroke="#0F172A"
                    strokeWidth={2.5}
                    dot={{ r: 3.5, fill: '#0F172A' }}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

// Page 11: Growth Insights & Weak-Point Detection Engine
export function GrowthInsightsPage() {
  const {
    activeRole,
    selectedPeriod,
    settings,
    students,
    invoices,
    payments,
    allocations,
    payouts,
    expenses,
    getAuthToken,
    isDemoMode,
  } = useInstitute();

  const [aiBriefing, setAiBriefing] = useState<string | null>(null);
  const [aiGeneratedDate, setAiGeneratedDate] = useState<string | null>(null);
  const [generatingAi, setGeneratingAi] = useState(false);

  if (activeRole === UserRole.TEACHER) {
    return <RestrictedFinanceNotice />;
  }

  const previousPeriod = useMemo(() => shiftPeriod(selectedPeriod, -1), [selectedPeriod]);

  const current = useMemo(
    () =>
      computeMonthlyPeriodMetrics({
        period: selectedPeriod,
        students,
        invoices,
        payments,
        allocations,
        payouts,
        expenses,
      }),
    [selectedPeriod, students, invoices, payments, allocations, payouts, expenses]
  );

  const previous = useMemo(
    () =>
      computeMonthlyPeriodMetrics({
        period: previousPeriod,
        students,
        invoices,
        payments,
        allocations,
        payouts,
        expenses,
      }),
    [previousPeriod, students, invoices, payments, allocations, payouts, expenses]
  );

  const revenueMoM = useMemo(
    () => calculateMoMGrowth(current.collectedFeePaise, previous.collectedFeePaise),
    [current, previous]
  );
  const netIncomeMoM = useMemo(
    () => calculateMoMGrowth(current.netOperatingIncomePaise, previous.netOperatingIncomePaise),
    [current, previous]
  );
  const receivablesMoM = useMemo(
    () => calculateMoMGrowth(current.pendingBalancePaise, previous.pendingBalancePaise),
    [current, previous]
  );
  const expensesMoM = useMemo(
    () => calculateMoMGrowth(current.operatingExpensesPaise, previous.operatingExpensesPaise),
    [current, previous]
  );

  const findings = useMemo(
    () =>
      detectInstituteWeakPoints({
        current,
        previous,
        payments,
        invoices,
      }),
    [current, previous, payments, invoices]
  );

  const revenueRoseWhileProfitFell =
    current.collectedFeePaise >= previous.collectedFeePaise &&
    current.collectedFeePaise > 0 &&
    current.netOperatingIncomePaise < previous.netOperatingIncomePaise;

  const handleGenerateAiBriefing = async () => {
    setGeneratingAi(true);
    try {
      const token = await getAuthToken();
      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (isDemoMode) {
        headers['X-Demo-Sandbox'] = 'true';
      } else if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const res = await fetch('/api/insights/ai-briefing', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          instituteName: settings.instituteName || 'IIS Institute',
          currentLabel: current.label,
          previousLabel: previous.label,
          collectedCurrentINR: formatINR(current.collectedFeePaise),
          collectedPreviousINR: formatINR(previous.collectedFeePaise),
          revenueGrowthLabel: revenueMoM.formattedPercent,
          netIncomeCurrentINR: formatINR(current.netOperatingIncomePaise),
          netIncomePreviousINR: formatINR(previous.netOperatingIncomePaise),
          pendingBalanceINR: formatINR(current.pendingBalancePaise),
          collectionRatePercent: current.collectionRatePercent,
          teacherPayoutRatioPercent: current.teacherPayoutRatioPercent,
          operatingExpensesINR: formatINR(current.operatingExpensesPaise),
          findings: findings.map((f) => ({
            metricName: f.metricName,
            currentValueFormatted: f.currentValueFormatted,
            comparisonValueFormatted: f.comparisonValueFormatted,
            percentChangeFormatted: f.percentChangeFormatted,
            severity: f.severity,
            reason: f.reason,
          })),
        }),
      });

      const body = (await res.json()) as {
        briefing?: string;
        generatedAtIST?: string;
        error?: string;
      };
      if (!res.ok) {
        throw new Error(body.error || 'Failed to generate executive briefing.');
      }

      setAiBriefing(body.briefing ?? null);
      setAiGeneratedDate(body.generatedAtIST ?? null);
      toast.success('Executive financial briefing generated from verified metrics.');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Unable to generate AI briefing.');
    } finally {
      setGeneratingAi(false);
    }
  };

  const momCards = [
    {
      title: 'Monthly Collected Revenue',
      currentStr: formatINR(current.collectedFeePaise),
      prevStr: formatINR(previous.collectedFeePaise),
      mom: revenueMoM,
      invertGood: false,
    },
    {
      title: 'Net Operating Income (Profit)',
      currentStr: formatINR(current.netOperatingIncomePaise),
      prevStr: formatINR(previous.netOperatingIncomePaise),
      mom: netIncomeMoM,
      invertGood: false,
    },
    {
      title: 'Pending Fee Receivables',
      currentStr: formatINR(current.pendingBalancePaise),
      prevStr: formatINR(previous.pendingBalancePaise),
      mom: receivablesMoM,
      invertGood: true,
    },
    {
      title: 'Non-Payroll Operating Expenses',
      currentStr: formatINR(current.operatingExpensesPaise),
      prevStr: formatINR(previous.operatingExpensesPaise),
      mom: expensesMoM,
      invertGood: true,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-blue-600">
            Month-over-Month Diagnostics · {current.label} vs {previous.label}
          </p>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-0.5">
            Growth Insights & Weak-Point Detection
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Formula-verified MoM comparisons and automated margin, receivable, and payout bottleneck
            diagnostics.
          </p>
        </div>

        <Button
          onClick={handleGenerateAiBriefing}
          disabled={generatingAi}
          variant="secondary"
        >
          <Sparkles className="h-4 w-4 text-indigo-600" />
          <span>{generatingAi ? 'Analyzing Ledger...' : 'Generate Executive Briefing'}</span>
        </Button>
      </div>

      {/* Explicit Divergence Banner when Revenue Rises but Net Profit Falls */}
      {revenueRoseWhileProfitFell && (
        <div className="rounded-xl border border-amber-300 bg-amber-50/90 p-4 flex items-start gap-3">
          <AlertTriangle className="h-5 w-5 text-amber-700 shrink-0 mt-0.5" />
          <div>
            <div className="text-sm font-bold text-amber-950">
              Revenue-to-Profit Divergence Detected ({current.label})
            </div>
            <p className="text-xs text-amber-900 mt-1 leading-relaxed">
              Top-line fee collections held or increased ({formatINR(previous.collectedFeePaise)} →{' '}
              {formatINR(current.collectedFeePaise)}), yet <strong>Net Operating Income fell</strong>{' '}
              from {formatINR(previous.netOperatingIncomePaise)} to{' '}
              {formatINR(current.netOperatingIncomePaise)} because combined teacher share accruals (
              {formatINR(current.accruedTeacherSharePaise)}) and operating expenses (
              {formatINR(current.operatingExpensesPaise)}) expanded faster than collections.
            </p>
          </div>
        </div>
      )}

      {/* MoM Growth Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        {momCards.map((card) => {
          const { mom } = card;
          const absDiffFormatted = `${mom.absoluteDiff >= 0 ? '+' : '-'}${formatINR(
            Math.abs(mom.absoluteDiff)
          )}`;
          const isFavorable = card.invertGood
            ? mom.direction === 'down'
            : mom.direction === 'up';
          const isUnfavorable = card.invertGood
            ? mom.direction === 'up'
            : mom.direction === 'down';

          return (
            <div
              key={card.title}
              className="bg-white border border-slate-200/90 rounded-xl p-5 flex flex-col justify-between"
            >
              <div>
                <div className="text-xs text-slate-500">{card.title}</div>
                <div className="text-2xl font-extrabold text-slate-900 font-mono tabular-nums mt-1.5">
                  {card.currentStr}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500">MoM Growth (%)</span>
                  <span
                    className={`inline-flex items-center gap-1 font-mono font-bold ${
                      mom.isZeroBase
                        ? 'text-slate-600'
                        : isFavorable
                        ? 'text-emerald-700'
                        : isUnfavorable
                        ? 'text-red-700'
                        : 'text-slate-600'
                    }`}
                  >
                    {mom.direction === 'up' && <ArrowUpRight className="h-3.5 w-3.5" />}
                    {mom.direction === 'down' && <ArrowDownRight className="h-3.5 w-3.5" />}
                    {mom.direction === 'flat' && <Minus className="h-3.5 w-3.5" />}
                    {mom.formattedPercent}
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500">INR Difference</span>
                  <span className="font-mono tabular-nums text-slate-800 font-medium">
                    {absDiffFormatted}
                  </span>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400">
                  <span>{previous.label} Base</span>
                  <span className="font-mono tabular-nums">
                    {card.prevStr}
                    {mom.isZeroBase ? ' (Zero base → N/A)' : ''}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Optional Grounded Executive Briefing Output */}
      {aiBriefing && (
        <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950 text-white rounded-xl p-6 shadow-sm">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 mb-4 border-b border-white/10">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-cyan-400" />
              <h2 className="text-sm font-bold tracking-wide">
                Controller Executive Briefing ({current.label} vs {previous.label})
              </h2>
            </div>
            <span className="text-[11px] text-slate-400 font-mono">
              Grounded strictly on verified ledger figures {aiGeneratedDate ? `· ${aiGeneratedDate}` : ''}
            </span>
          </div>
          <div className="space-y-3 text-sm text-slate-200 leading-relaxed whitespace-pre-line">
            {aiBriefing}
          </div>
        </div>
      )}

      {/* Deterministic Weak-Point Detection Findings */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Deterministic Weak-Point & Margin Diagnostics
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Evaluates 7 risk vectors: collection decline, rising receivables, realization drop,
              teacher payout ratio, overhead spikes, course contraction, and margin compression.
            </p>
          </div>
          <StatusText
            tone={findings.length === 0 ? 'positive' : 'warning'}
            label={
              findings.length === 0
                ? 'All 7 Diagnostics Nominal'
                : `${findings.length} Active Alert(s)`
            }
          />
        </div>

        {findings.length === 0 ? (
          <div className="rounded-xl border border-emerald-200 bg-emerald-50/60 p-6 flex items-center gap-3">
            <CheckCircle2 className="h-5 w-5 text-emerald-700 shrink-0" />
            <div>
              <div className="text-sm font-bold text-emerald-950">
                No Financial Weaknesses Triggered for {current.label}
              </div>
              <p className="text-xs text-emerald-800 mt-0.5">
                Collection realization, teacher share ratios, operating expenses, and net margins
                are within healthy operating thresholds compared to {previous.label}.
              </p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {findings.map((finding) => {
              const borderClass =
                finding.severity === 'critical'
                  ? 'border-l-4 border-l-red-600 border-slate-200'
                  : finding.severity === 'warning'
                  ? 'border-l-4 border-l-amber-500 border-slate-200'
                  : 'border-l-4 border-l-blue-600 border-slate-200';

              return (
                <div
                  key={finding.id}
                  className={`rounded-xl border bg-slate-50/40 p-5 space-y-3 ${borderClass}`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                        {finding.category}
                      </div>
                      <h3 className="text-sm font-bold text-slate-900 mt-0.5">
                        {finding.metricName}
                      </h3>
                    </div>
                    <StatusText
                      tone={
                        finding.severity === 'critical'
                          ? 'danger'
                          : finding.severity === 'warning'
                          ? 'warning'
                          : 'info'
                      }
                      label={finding.severity.toUpperCase()}
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2 rounded-lg bg-white border border-slate-200/80 p-3 text-xs">
                    <div>
                      <div className="text-slate-400">Current ({current.label})</div>
                      <div className="font-mono tabular-nums font-bold text-slate-900 mt-0.5">
                        {finding.currentValueFormatted}
                      </div>
                    </div>
                    <div>
                      <div className="text-slate-400">Previous ({previous.label})</div>
                      <div className="font-mono tabular-nums font-semibold text-slate-700 mt-0.5">
                        {finding.comparisonValueFormatted}
                      </div>
                    </div>
                    <div>
                      <div className="text-slate-400">Shift</div>
                      <div className="font-mono tabular-nums font-bold text-red-700 mt-0.5">
                        {finding.percentChangeFormatted}
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-700 leading-relaxed">{finding.reason}</p>

                  <div className="text-xs text-slate-900 bg-white border border-slate-200/70 rounded-lg p-3">
                    <span className="font-bold text-blue-700">Suggested Action: </span>
                    {finding.suggestedAction}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

// Page 12: Financial Reports, Exports & Audit Ledger
export function FinancialReportsPage() {
  const {
    activeRole,
    selectedPeriod,
    settings,
    students,
    invoices,
    payments,
    allocations,
    payouts,
    expenses,
    auditLogs,
    updateAuditLog,
    deleteAuditLog,
    getAuthToken,
    isDemoMode,
  } = useInstitute();

  const [exportingKey, setExportingKey] = useState<string | null>(null);
  const [editingAuditLog, setEditingAuditLog] = useState<AuditLog | null>(null);
  const [deleteTargetAuditLog, setDeleteTargetAuditLog] = useState<AuditLog | null>(null);
  const [auditAction, setAuditAction] = useState('');
  const [auditSummary, setAuditSummary] = useState('');
  const [auditAmountRupees, setAuditAmountRupees] = useState('0');
  const [submittingAudit, setSubmittingAudit] = useState(false);

  if (activeRole === UserRole.TEACHER) {
    return <RestrictedFinanceNotice />;
  }

  const openEditAuditModal = (log: AuditLog) => {
    setEditingAuditLog(log);
    setAuditAction(log.action);
    setAuditSummary(log.summary);
    setAuditAmountRupees(String(log.amountPaise / 100));
  };

  const handleSaveAuditLog = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingAuditLog) return;
    setSubmittingAudit(true);
    try {
      await updateAuditLog(editingAuditLog.id, {
        action: auditAction.trim(),
        summary: auditSummary.trim(),
        amountRupees: Number(auditAmountRupees) || 0,
      });
      toast.success('Audit log entry updated.');
      setEditingAuditLog(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to update audit log.');
    } finally {
      setSubmittingAudit(false);
    }
  };

  const handleConfirmDeleteAuditLog = async () => {
    if (!deleteTargetAuditLog) return;
    setSubmittingAudit(true);
    try {
      await deleteAuditLog(deleteTargetAuditLog.id);
      toast.success('Audit log entry deleted.');
      setDeleteTargetAuditLog(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete audit log.');
    } finally {
      setSubmittingAudit(false);
    }
  };

  const previousPeriod = useMemo(() => shiftPeriod(selectedPeriod, -1), [selectedPeriod]);
  const trailing12 = useMemo(() => getTrailingPeriods(selectedPeriod, 12), [selectedPeriod]);

  const current = useMemo(
    () =>
      computeMonthlyPeriodMetrics({
        period: selectedPeriod,
        students,
        invoices,
        payments,
        allocations,
        payouts,
        expenses,
      }),
    [selectedPeriod, students, invoices, payments, allocations, payouts, expenses]
  );

  const previous = useMemo(
    () =>
      computeMonthlyPeriodMetrics({
        period: previousPeriod,
        students,
        invoices,
        payments,
        allocations,
        payouts,
        expenses,
      }),
    [previousPeriod, students, invoices, payments, allocations, payouts, expenses]
  );

  const trailingSeries = useMemo(
    () =>
      trailing12.map((period) =>
        computeMonthlyPeriodMetrics({
          period,
          students,
          invoices,
          payments,
          allocations,
          payouts,
          expenses,
        })
      ),
    [trailing12, students, invoices, payments, allocations, payouts, expenses]
  );

  const findings = useMemo(
    () => detectInstituteWeakPoints({ current, previous, payments, invoices }),
    [current, previous, payments, invoices]
  );

  const handleDownloadPDFSummary = () => {
    try {
      generateFinancialReportPDF({
        settings,
        current,
        previous,
        trailingSeries,
        findings,
      });
      toast.success(`Downloaded Financial Summary PDF for ${current.label}.`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'PDF generation failed.');
    }
  };

  const handleCSVExport = async (
    type: 'payments' | 'invoices' | 'payouts' | 'expenses' | 'students'
  ) => {
    setExportingKey(type);
    try {
      const idToken = await getAuthToken();
      if (type === 'payments') {
        await downloadServerCSV({
          filename: `IIS_Payments_Ledger_${selectedPeriod}.csv`,
          headers: [
            'Receipt No',
            'Payment Date',
            'Billing Period',
            'Student Name',
            'Course',
            'Method',
            'Amount (INR)',
            'Status',
            'Idempotency Key',
          ],
          rows: payments.map((p) => [
            p.receiptNumber,
            p.paymentDate,
            p.billingPeriod,
            p.studentName,
            p.courseName,
            p.paymentMethod,
            toRupees(p.amountPaise),
            p.status,
            p.idempotencyKey,
          ]),
          idToken,
          isDemoMode,
        });
      } else if (type === 'invoices') {
        await downloadServerCSV({
          filename: `IIS_Invoices_Ledger_${selectedPeriod}.csv`,
          headers: [
            'Invoice No',
            'Billing Period',
            'Student Name',
            'Course',
            'Gross (INR)',
            'Discount (INR)',
            'Net Due (INR)',
            'Paid (INR)',
            'Balance Due (INR)',
            'Due Date',
            'Status',
          ],
          rows: invoices.map((i) => [
            i.invoiceNumber,
            i.billingPeriod,
            i.studentName,
            i.courseName,
            toRupees(i.grossAmountPaise),
            toRupees(i.discountPaise),
            toRupees(i.netAmountDuePaise),
            toRupees(i.paidAmountPaise),
            toRupees(i.balanceDuePaise),
            i.dueDate,
            i.status,
          ]),
          idToken,
          isDemoMode,
        });
      } else if (type === 'payouts') {
        await downloadServerCSV({
          filename: `IIS_Teacher_Payouts_${selectedPeriod}.csv`,
          headers: [
            'Payout No',
            'Faculty Name',
            'Billing Period',
            'Payout Date',
            'Method',
            'Amount (INR)',
            'Status',
            'Reference',
          ],
          rows: payouts.map((po) => [
            po.payoutNumber,
            po.teacherName,
            po.billingPeriod,
            po.payoutDate,
            po.paymentMethod,
            toRupees(po.amountPaise),
            po.status,
            po.referenceNote,
          ]),
          idToken,
          isDemoMode,
        });
      } else if (type === 'expenses') {
        await downloadServerCSV({
          filename: `IIS_Operating_Expenses_${selectedPeriod}.csv`,
          headers: [
            'Expense Date',
            'Period',
            'Title',
            'Category',
            'Vendor',
            'Method',
            'Amount (INR)',
            'Status',
          ],
          rows: expenses.map((ex) => [
            ex.expenseDate,
            ex.billingPeriod,
            ex.title,
            ex.category,
            ex.vendorName,
            ex.paymentMethod,
            toRupees(ex.amountPaise),
            ex.status,
          ]),
          idToken,
          isDemoMode,
        });
      } else {
        await downloadServerCSV({
          filename: `IIS_Students_Master_${selectedPeriod}.csv`,
          headers: [
            'Student Code',
            'Full Name',
            'Primary Course',
            'Batch',
            'Assigned Teacher',
            'Enrollment Date',
            'Monthly Fee (INR)',
            'Schedule',
            'Guardian',
            'Phone',
            'Status',
          ],
          rows: students.map((s) => [
            s.studentCode,
            s.fullName,
            s.primaryCourseName,
            s.batchName,
            s.assignedTeacherName,
            s.enrollmentDate,
            toRupees(s.monthlyFeePaise),
            s.paymentSchedule,
            s.guardianName,
            s.guardianPhone,
            s.status,
          ]),
          idToken,
          isDemoMode,
        });
      }
      toast.success(`Exported ${type} CSV dataset.`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'CSV export failed.');
    } finally {
      setExportingKey(null);
    }
  };

  const statementRows: Array<{
    section: string;
    label: string;
    currVal: string;
    prevVal: string;
    momStr: string;
    bold?: boolean;
  }> = [
    {
      section: 'Billing & Realization',
      label: 'Gross Tuition Invoiced',
      currVal: formatINR(current.invoicedGrossPaise),
      prevVal: formatINR(previous.invoicedGrossPaise),
      momStr: calculateMoMGrowth(current.invoicedGrossPaise, previous.invoicedGrossPaise)
        .formattedPercent,
    },
    {
      section: 'Billing & Realization',
      label: 'Net Tuition Invoiced (After Scholarships/Discounts)',
      currVal: formatINR(current.invoicedNetPaise),
      prevVal: formatINR(previous.invoicedNetPaise),
      momStr: calculateMoMGrowth(current.invoicedNetPaise, previous.invoicedNetPaise)
        .formattedPercent,
    },
    {
      section: 'Billing & Realization',
      label: 'Verified Collected Fee Revenue (Cash / UPI / Bank)',
      currVal: formatINR(current.collectedFeePaise),
      prevVal: formatINR(previous.collectedFeePaise),
      momStr: calculateMoMGrowth(current.collectedFeePaise, previous.collectedFeePaise)
        .formattedPercent,
      bold: true,
    },
    {
      section: 'Billing & Realization',
      label: 'Uncollected Pending Invoice Balance',
      currVal: formatINR(current.pendingBalancePaise),
      prevVal: formatINR(previous.pendingBalancePaise),
      momStr: calculateMoMGrowth(current.pendingBalancePaise, previous.pendingBalancePaise)
        .formattedPercent,
    },
    {
      section: 'Faculty Obligations & Overhead',
      label: 'Less: Accrued Teacher Share Liabilities (Earned)',
      currVal: formatINR(current.accruedTeacherSharePaise),
      prevVal: formatINR(previous.accruedTeacherSharePaise),
      momStr: calculateMoMGrowth(
        current.accruedTeacherSharePaise,
        previous.accruedTeacherSharePaise
      ).formattedPercent,
    },
    {
      section: 'Faculty Obligations & Overhead',
      label: 'Less: Non-Payroll Operating Expenses',
      currVal: formatINR(current.operatingExpensesPaise),
      prevVal: formatINR(previous.operatingExpensesPaise),
      momStr: calculateMoMGrowth(current.operatingExpensesPaise, previous.operatingExpensesPaise)
        .formattedPercent,
    },
    {
      section: 'Profitability & Cash Reconciliation',
      label: 'Net Operating Income (Accrual-Adjusted Profit)',
      currVal: formatINR(current.netOperatingIncomePaise),
      prevVal: formatINR(previous.netOperatingIncomePaise),
      momStr: calculateMoMGrowth(current.netOperatingIncomePaise, previous.netOperatingIncomePaise)
        .formattedPercent,
      bold: true,
    },
    {
      section: 'Profitability & Cash Reconciliation',
      label: 'Disbursed Teacher Payouts (Cash Outflow)',
      currVal: formatINR(current.paidTeacherPayoutPaise),
      prevVal: formatINR(previous.paidTeacherPayoutPaise),
      momStr: calculateMoMGrowth(current.paidTeacherPayoutPaise, previous.paidTeacherPayoutPaise)
        .formattedPercent,
    },
    {
      section: 'Profitability & Cash Reconciliation',
      label: 'Unpaid Teacher Share Liability Carried Forward',
      currVal: formatINR(current.unpaidTeacherLiabilityPaise),
      prevVal: formatINR(previous.unpaidTeacherLiabilityPaise),
      momStr: calculateMoMGrowth(
        current.unpaidTeacherLiabilityPaise,
        previous.unpaidTeacherLiabilityPaise
      ).formattedPercent,
    },
    {
      section: 'Profitability & Cash Reconciliation',
      label: 'Cash Net Surplus (Collected − Paid Payouts − Expenses)',
      currVal: formatINR(current.cashNetSurplusPaise),
      prevVal: formatINR(previous.cashNetSurplusPaise),
      momStr: calculateMoMGrowth(current.cashNetSurplusPaise, previous.cashNetSurplusPaise)
        .formattedPercent,
      bold: true,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-blue-600">
            Auditable Statements & Exports · {current.label}
          </p>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-0.5">
            Financial Reports & Audit Trail
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Formal P&L reconciliation separating invoiced vs collected revenue and accrued teacher
            liabilities vs cash disbursements.
          </p>
        </div>

        <Button onClick={handleDownloadPDFSummary}>
          <FileText className="h-4 w-4" />
          <span>Download Executive PDF Report</span>
        </Button>
      </div>

      <Tabs defaultValue="statement" className="space-y-6">
        <TabsList>
          <TabsTrigger value="statement">Monthly P&L Statement</TabsTrigger>
          <TabsTrigger value="exports">CSV Data Exports</TabsTrigger>
          {activeRole === UserRole.ADMIN && (
            <TabsTrigger value="audit">Audit Logs ({auditLogs.length})</TabsTrigger>
          )}
        </TabsList>

        {/* Tab 1: Formal Statement */}
        <TabsContent value="statement">
          <div className="bg-white border border-slate-200/90 rounded-xl overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-2">
              <div>
                <h2 className="text-base font-bold text-slate-900">
                  Statement of Institute Operations & Cash Reconciliation
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  All figures computed from integer-paise atomic ledgers in Asia/Kolkata (INR)
                </p>
              </div>
              <div className="text-xs font-mono text-slate-500">
                Collection Rate: {current.collectionRatePercent.toFixed(1)}% · Net Margin:{' '}
                {current.netMarginPercent.toFixed(1)}%
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                    <th className="py-3.5 px-6">Accounting Line Item</th>
                    <th className="py-3.5 px-6 text-right">{current.label}</th>
                    <th className="py-3.5 px-6 text-right">{previous.label}</th>
                    <th className="py-3.5 px-6 text-right">MoM Change</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {statementRows.map((row) => (
                    <tr
                      key={row.label}
                      className={
                        row.bold ? 'bg-slate-50/90 font-bold text-slate-900' : 'hover:bg-slate-50/50'
                      }
                    >
                      <td className="py-3.5 px-6">
                        <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                          {row.section}
                        </div>
                        <div className={row.bold ? 'font-bold text-slate-900' : 'text-slate-700'}>
                          {row.label}
                        </div>
                      </td>
                      <td className="py-3.5 px-6 text-right font-mono tabular-nums">
                        {row.currVal}
                      </td>
                      <td className="py-3.5 px-6 text-right font-mono tabular-nums text-slate-600">
                        {row.prevVal}
                      </td>
                      <td className="py-3.5 px-6 text-right font-mono tabular-nums text-xs">
                        {row.momStr}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </TabsContent>

        {/* Tab 2: CSV Export Center */}
        <TabsContent value="exports">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              {
                key: 'payments' as const,
                title: 'Fee Payments & Receipts CSV',
                desc: 'Complete verified & reversed receipts with payment mode, date, and idempotency keys.',
                count: `${payments.length} records`,
              },
              {
                key: 'invoices' as const,
                title: 'Student Invoices & Dues CSV',
                desc: 'Gross billed fees, discounts, net payable, cumulative paid, and remaining balances.',
                count: `${invoices.length} invoices`,
              },
              {
                key: 'payouts' as const,
                title: 'Teacher Payout Disbursements CSV',
                desc: 'All faculty payout vouchers with billing periods, bank/UPI modes, and references.',
                count: `${payouts.length} payouts`,
              },
              {
                key: 'expenses' as const,
                title: 'Operating Expenses CSV',
                desc: 'Rent, utilities, materials, software, and facility vouchers with status.',
                count: `${expenses.length} vouchers`,
              },
              {
                key: 'students' as const,
                title: 'Master Student Roster CSV',
                desc: 'Active and archived students with courses, batches, assigned faculty, and guardian contacts.',
                count: `${students.length} students`,
              },
            ].map((item) => (
              <div
                key={item.key}
                className="bg-white border border-slate-200/90 rounded-xl p-5 flex flex-col justify-between gap-4"
              >
                <div>
                  <div className="text-xs font-mono text-blue-600 font-semibold">{item.count}</div>
                  <h3 className="text-base font-bold text-slate-900 mt-1">{item.title}</h3>
                  <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">{item.desc}</p>
                </div>
                <Button
                  variant="secondary"
                  size="sm"
                  disabled={exportingKey === item.key}
                  onClick={() => handleCSVExport(item.key)}
                >
                  <Download className="h-3.5 w-3.5" />
                  <span>{exportingKey === item.key ? 'Exporting...' : 'Download CSV'}</span>
                </Button>
              </div>
            ))}
          </div>
        </TabsContent>

        {/* Tab 3: Editable & Deletable Audit Logs */}
        {activeRole === UserRole.ADMIN && (
          <TabsContent value="audit">
            {auditLogs.length === 0 ? (
              <EmptyState
                title="No financial audit log entries yet"
                description="Every payment, reversal, payout, agreement update, and role modification is logged here."
              />
            ) : (
              <div className="bg-white border border-slate-200/90 rounded-xl overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                        <th className="py-3.5 px-4">Timestamp</th>
                        <th className="py-3.5 px-4">Actor</th>
                        <th className="py-3.5 px-4">Action & Entity</th>
                        <th className="py-3.5 px-4">Summary</th>
                        <th className="py-3.5 px-4 text-right">Amount</th>
                        <th className="py-3.5 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-sm">
                      {auditLogs.slice(0, 100).map((log) => (
                        <tr key={log.id} className="hover:bg-slate-50/70">
                          <td className="py-3 px-4 font-mono text-xs text-slate-500 whitespace-nowrap">
                            {log.createdAt.slice(0, 19).replace('T', ' ')}
                          </td>
                          <td className="py-3 px-4">
                            <div className="text-xs font-semibold text-slate-900">
                              {log.actorEmail}
                            </div>
                            <div className="text-[11px] text-slate-400">{log.actorRole}</div>
                          </td>
                          <td className="py-3 px-4">
                            <div className="text-xs font-bold text-slate-800">{log.action}</div>
                            <div className="text-[11px] font-mono text-slate-400">
                              {log.entityType} · {log.entityId.slice(0, 14)}
                            </div>
                          </td>
                          <td className="py-3 px-4 text-xs text-slate-700 max-w-md">
                            {log.summary}
                          </td>
                          <td className="py-3 px-4 text-right font-mono tabular-nums text-xs font-semibold text-slate-900">
                            {log.amountPaise > 0 ? formatINR(log.amountPaise) : '—'}
                          </td>
                          <td className="py-3 px-4 text-right whitespace-nowrap">
                            <div className="inline-flex items-center gap-1">
                              <button
                                type="button"
                                onClick={() => openEditAuditModal(log)}
                                title="Edit audit entry"
                                className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                              >
                                <Edit2 className="h-3.5 w-3.5" />
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeleteTargetAuditLog(log)}
                                title="Delete audit entry"
                                className="p-1.5 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </TabsContent>
        )}
      </Tabs>

      {/* Edit Audit Log Entry Dialog */}
      <Dialog
        open={Boolean(editingAuditLog)}
        onOpenChange={(o) => !o && setEditingAuditLog(null)}
      >
        <DialogContent
          title="Edit Audit Log Entry"
          description="Update the action code, summary description, or recorded INR amount."
        >
          <form onSubmit={handleSaveAuditLog} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Action Code</Label>
                <Input
                  value={auditAction}
                  onChange={(e) => setAuditAction(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label>Amount (INR ₹)</Label>
                <Input
                  type="number"
                  min={0}
                  step="0.01"
                  value={auditAmountRupees}
                  onChange={(e) => setAuditAmountRupees(e.target.value)}
                />
              </div>
            </div>
            <div>
              <Label>Summary</Label>
              <Textarea
                value={auditSummary}
                onChange={(e) => setAuditSummary(e.target.value)}
                required
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <Button
                type="button"
                variant="secondary"
                onClick={() => setEditingAuditLog(null)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={submittingAudit}>
                {submittingAudit ? 'Saving...' : 'Save Audit Entry'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDeleteDialog
        open={Boolean(deleteTargetAuditLog)}
        onOpenChange={(o) => !o && setDeleteTargetAuditLog(null)}
        title="Delete Audit Log Entry"
        description={
          deleteTargetAuditLog
            ? `Permanently delete audit log entry "${deleteTargetAuditLog.action}" (${deleteTargetAuditLog.summary})?`
            : ''
        }
        loading={submittingAudit}
        onConfirm={handleConfirmDeleteAuditLog}
      />
    </div>
  );
}
