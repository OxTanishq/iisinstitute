import React, { useMemo, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import {
  Plus,
  Edit2,
  Trash2,
  Search,
  Download,
  RotateCcw,
  ShieldAlert,
} from 'lucide-react';
import { toast } from 'sonner';
import { useInstitute } from '../context/InstituteContext';
import {
  AcademicProgress,
  Expense,
  ExpenseCategory,
  PaymentMethod,
  StudentReport,
  UserRole,
} from '../shared/types';
import {
  formatINR,
  formatPeriodLabel,
  getTodayIST,
  toRupees,
} from '../shared/finance';
import { downloadServerCSV } from '../lib/pdfExport';
import { RestrictedFinanceNotice } from './FeesPages';
import {
  Button,
  ConfirmDeleteDialog,
  Dialog,
  DialogContent,
  EmptyState,
  Input,
  Label,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
  StatusText,
  Textarea,
} from '../components/ui/primitives';

const PROGRESS_LABELS: Record<AcademicProgress, string> = {
  [AcademicProgress.EXCELLENT]: 'Excellent',
  [AcademicProgress.GOOD]: 'Good',
  [AcademicProgress.SATISFACTORY]: 'Satisfactory',
  [AcademicProgress.NEEDS_ATTENTION]: 'Needs Attention',
};

const EXPENSE_CATEGORY_COLORS: Record<ExpenseCategory, string> = {
  [ExpenseCategory.RENT]: '#2563EB',
  [ExpenseCategory.UTILITIES]: '#0891B2',
  [ExpenseCategory.MARKETING]: '#7C3AED',
  [ExpenseCategory.MATERIALS]: '#059669',
  [ExpenseCategory.SOFTWARE]: '#4F46E5',
  [ExpenseCategory.MAINTENANCE]: '#D97706',
  [ExpenseCategory.OTHER]: '#64748B',
};

// Page 8: Student Performance Reports
export function PerformanceReportsPage() {
  const {
    activeRole,
    currentUserProfile,
    selectedPeriod,
    students,
    courses,
    teachers,
    reports,
    submitStudentReport,
    updateStudentReport,
    deleteStudentReport,
  } = useInstitute();

  const [searchTerm, setSearchTerm] = useState('');
  const [courseFilter, setCourseFilter] = useState<string>('ALL');
  const [progressFilter, setProgressFilter] = useState<'ALL' | AcademicProgress>('ALL');
  const [periodScope, setPeriodScope] = useState<'SELECTED' | 'ALL'>('ALL');

  const [modalOpen, setModalOpen] = useState(false);
  const [editingReport, setEditingReport] = useState<StudentReport | null>(null);
  const [deleteTargetReport, setDeleteTargetReport] = useState<StudentReport | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Report Form State
  const [studentId, setStudentId] = useState('');
  const [reportingPeriod, setReportingPeriod] = useState(selectedPeriod);
  const [subject, setSubject] = useState('');
  const [attendancePercent, setAttendancePercent] = useState('92');
  const [testMarks, setTestMarks] = useState('84');
  const [maxMarks, setMaxMarks] = useState('100');
  const [academicProgress, setAcademicProgress] = useState<AcademicProgress>(
    AcademicProgress.GOOD
  );
  const [strengths, setStrengths] = useState('');
  const [areasForImprovement, setAreasForImprovement] = useState('');
  const [teacherComments, setTeacherComments] = useState('');
  const [submissionDate, setSubmissionDate] = useState(getTodayIST());

  if (activeRole === UserRole.ACCOUNTANT) {
    return (
      <div className="bg-white border border-slate-200 rounded-xl p-10 text-center max-w-lg mx-auto my-10">
        <ShieldAlert className="h-8 w-8 text-amber-600 mx-auto mb-3" />
        <h2 className="text-lg font-bold text-slate-900">Academic Assessment Restricted</h2>
        <p className="text-sm text-slate-600 mt-1.5 leading-relaxed">
          Student academic performance reports are accessible only to Faculty members and
          Administrators. Accountants can manage fee collections, payouts, and institute expenses.
        </p>
      </div>
    );
  }

  // Scope eligible students: Teachers can only submit/view reports for students assigned to them
  const eligibleStudents = useMemo(() => {
    const activeList = students.filter(
      (s) => s.status === 'ACTIVE' || s.id === editingReport?.studentId
    );
    if (activeRole === UserRole.TEACHER) {
      const uid = currentUserProfile?.uid ?? '';
      const linkedTeacherId = currentUserProfile?.teacherId ?? '';
      return activeList.filter(
        (s) =>
          (uid && s.assignedTeacherUid === uid) ||
          (linkedTeacherId && s.assignedTeacherId === linkedTeacherId)
      );
    }
    return activeList;
  }, [students, activeRole, currentUserProfile, editingReport]);

  const scopedReports = useMemo(() => {
    return reports
      .filter((r) => {
        if (activeRole === UserRole.TEACHER) {
          const uid = currentUserProfile?.uid ?? '';
          const linkedTeacherId = currentUserProfile?.teacherId ?? '';
          const matchesTeacher =
            (uid && r.teacherUid === uid) || (linkedTeacherId && r.teacherId === linkedTeacherId);
          if (!matchesTeacher) return false;
        }
        if (periodScope === 'SELECTED' && r.reportingPeriod !== selectedPeriod) return false;
        if (courseFilter !== 'ALL' && r.courseId !== courseFilter) return false;
        if (progressFilter !== 'ALL' && r.academicProgress !== progressFilter) return false;
        if (searchTerm.trim()) {
          const q = searchTerm.toLowerCase();
          return (
            r.studentName.toLowerCase().includes(q) ||
            r.subject.toLowerCase().includes(q) ||
            r.teacherName.toLowerCase().includes(q) ||
            r.courseName.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => b.submissionDate.localeCompare(a.submissionDate));
  }, [
    reports,
    activeRole,
    currentUserProfile,
    periodScope,
    selectedPeriod,
    courseFilter,
    progressFilter,
    searchTerm,
  ]);

  // Real performance chart aggregations from actual report data
  const subjectChartData = useMemo(() => {
    const map = new Map<
      string,
      { subject: string; totalPct: number; totalAttendance: number; count: number }
    >();
    for (const r of scopedReports) {
      const pct = (r.testMarks / Math.max(1, r.maxMarks)) * 100;
      const entry = map.get(r.subject) ?? {
        subject: r.subject,
        totalPct: 0,
        totalAttendance: 0,
        count: 0,
      };
      entry.totalPct += pct;
      entry.totalAttendance += r.attendancePercent;
      entry.count += 1;
      map.set(r.subject, entry);
    }
    return Array.from(map.values())
      .map((item) => ({
        subject: item.subject.length > 18 ? `${item.subject.slice(0, 16)}…` : item.subject,
        fullSubject: item.subject,
        avgScorePct: Math.round((item.totalPct / item.count) * 10) / 10,
        avgAttendancePct: Math.round((item.totalAttendance / item.count) * 10) / 10,
        reportsCount: item.count,
      }))
      .sort((a, b) => b.avgScorePct - a.avgScorePct)
      .slice(0, 8);
  }, [scopedReports]);

  const progressDistributionData = useMemo(() => {
    const counts: Record<AcademicProgress, number> = {
      [AcademicProgress.EXCELLENT]: 0,
      [AcademicProgress.GOOD]: 0,
      [AcademicProgress.SATISFACTORY]: 0,
      [AcademicProgress.NEEDS_ATTENTION]: 0,
    };
    for (const r of scopedReports) {
      counts[r.academicProgress] = (counts[r.academicProgress] ?? 0) + 1;
    }
    return [
      { label: 'Excellent', count: counts[AcademicProgress.EXCELLENT], fill: '#059669' },
      { label: 'Good', count: counts[AcademicProgress.GOOD], fill: '#2563EB' },
      { label: 'Satisfactory', count: counts[AcademicProgress.SATISFACTORY], fill: '#0891B2' },
      { label: 'Needs Attention', count: counts[AcademicProgress.NEEDS_ATTENTION], fill: '#DC2626' },
    ];
  }, [scopedReports]);

  const summaryMetrics = useMemo(() => {
    if (scopedReports.length === 0) {
      return { avgScore: 0, avgAttendance: 0, attentionCount: 0 };
    }
    const totalScore = scopedReports.reduce(
      (sum, r) => sum + (r.testMarks / Math.max(1, r.maxMarks)) * 100,
      0
    );
    const totalAtt = scopedReports.reduce((sum, r) => sum + r.attendancePercent, 0);
    const attentionCount = scopedReports.filter(
      (r) => r.academicProgress === AcademicProgress.NEEDS_ATTENTION
    ).length;
    return {
      avgScore: Math.round((totalScore / scopedReports.length) * 10) / 10,
      avgAttendance: Math.round((totalAtt / scopedReports.length) * 10) / 10,
      attentionCount,
    };
  }, [scopedReports]);

  const openCreateModal = () => {
    const firstStu = eligibleStudents[0];
    setEditingReport(null);
    setStudentId(firstStu?.id ?? '');
    setReportingPeriod(selectedPeriod);
    setSubject(firstStu?.primaryCourseName ?? '');
    setAttendancePercent('92');
    setTestMarks('82');
    setMaxMarks('100');
    setAcademicProgress(AcademicProgress.GOOD);
    setStrengths('');
    setAreasForImprovement('');
    setTeacherComments('');
    setSubmissionDate(getTodayIST());
    setModalOpen(true);
  };

  const openEditModal = (report: StudentReport) => {
    setEditingReport(report);
    setStudentId(report.studentId);
    setReportingPeriod(report.reportingPeriod);
    setSubject(report.subject);
    setAttendancePercent(String(report.attendancePercent));
    setTestMarks(String(report.testMarks));
    setMaxMarks(String(report.maxMarks));
    setAcademicProgress(report.academicProgress);
    setStrengths(report.strengths);
    setAreasForImprovement(report.areasForImprovement);
    setTeacherComments(report.teacherComments);
    setSubmissionDate(report.submissionDate);
    setModalOpen(true);
  };

  const handleSaveReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentId) {
      toast.error('Please select an assigned student.');
      return;
    }
    setSubmitting(true);
    try {
      const payload = {
        studentId,
        reportingPeriod,
        subject: subject.trim(),
        attendancePercent: Math.round(Number(attendancePercent)),
        testMarks: Math.round(Number(testMarks)),
        maxMarks: Math.round(Number(maxMarks)),
        academicProgress,
        strengths: strengths.trim(),
        areasForImprovement: areasForImprovement.trim(),
        teacherComments: teacherComments.trim(),
        submissionDate,
      };

      if (editingReport) {
        await updateStudentReport(editingReport.id, payload);
        toast.success('Student performance report updated.');
      } else {
        await submitStudentReport(payload);
        toast.success('Student performance report submitted.');
      }
      setModalOpen(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to save report.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDeleteReport = async () => {
    if (!deleteTargetReport) return;
    setSubmitting(true);
    try {
      await deleteStudentReport(deleteTargetReport.id);
      toast.success('Student performance report deleted.');
      setDeleteTargetReport(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete report.');
    } finally {
      setSubmitting(false);
    }
  };

  const progressTone = (prog: AcademicProgress) => {
    switch (prog) {
      case AcademicProgress.EXCELLENT:
        return 'positive' as const;
      case AcademicProgress.GOOD:
        return 'info' as const;
      case AcademicProgress.SATISFACTORY:
        return 'neutral' as const;
      case AcademicProgress.NEEDS_ATTENTION:
        return 'danger' as const;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-blue-600">
            {activeRole === UserRole.TEACHER
              ? 'Assigned Cohort Academic Assessments'
              : 'Institute-Wide Academic Evaluation'}
          </p>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-0.5">
            Student Performance Reports
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Track subject test scores, classroom attendance, academic strengths, and intervention
            priorities.
          </p>
        </div>

        <Button
          onClick={openCreateModal}
          disabled={eligibleStudents.length === 0 || teachers.length === 0}
        >
          <Plus className="h-4 w-4" />
          <span>Submit Performance Report</span>
        </Button>
      </div>

      {/* KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="text-xs text-slate-500">Evaluations in View</div>
          <div className="text-2xl font-extrabold text-slate-900 font-mono tabular-nums mt-1.5">
            {scopedReports.length}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            {periodScope === 'SELECTED'
              ? `Period: ${formatPeriodLabel(selectedPeriod)}`
              : 'Across all reporting periods'}
          </div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="text-xs text-slate-500">Mean Assessment Score</div>
          <div className="text-2xl font-extrabold text-blue-700 font-mono tabular-nums mt-1.5">
            {scopedReports.length > 0 ? `${summaryMetrics.avgScore.toFixed(1)}%` : '—'}
          </div>
          <div className="text-xs text-slate-500 mt-1">Weighted test marks / maximum marks</div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="text-xs text-slate-500">Mean Batch Attendance</div>
          <div className="text-2xl font-extrabold text-emerald-700 font-mono tabular-nums mt-1.5">
            {scopedReports.length > 0 ? `${summaryMetrics.avgAttendance.toFixed(1)}%` : '—'}
          </div>
          <div className="text-xs text-slate-500 mt-1">Verified faculty attendance logs</div>
        </div>

        <div className="bg-white border border-slate-200/90 rounded-xl p-5">
          <div className="text-xs text-slate-500">Students Needing Attention</div>
          <div className="text-2xl font-extrabold text-red-700 font-mono tabular-nums mt-1.5">
            {summaryMetrics.attentionCount}
          </div>
          <div className="text-xs text-slate-500 mt-1">Flagged for academic remediation</div>
        </div>
      </div>

      {/* Real-Data Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white border border-slate-200/90 rounded-xl p-6">
          <div className="flex items-center justify-between gap-2 mb-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Subject Score & Attendance Benchmark (%)
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Computed directly from submitted student test scores and attendance records
              </p>
            </div>
          </div>

          {subjectChartData.length === 0 ? (
            <div className="h-64 flex items-center justify-center text-sm text-slate-400 border border-dashed border-slate-200 rounded-lg">
              Submit student performance reports to populate subject benchmarks.
            </div>
          ) : (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={subjectChartData} margin={{ top: 8, right: 16, left: -12, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                  <XAxis dataKey="subject" tick={{ fontSize: 11, fill: '#64748B' }} />
                  <YAxis domain={[0, 100]} tick={{ fontSize: 11, fill: '#64748B' }} unit="%" />
                  <Tooltip
                    formatter={(val, name) => [
                      `${Number(val ?? 0).toFixed(1)}%`,
                      name === 'avgScorePct' ? 'Avg Test Score' : 'Avg Attendance',
                    ]}
                    contentStyle={{
                      borderRadius: '10px',
                      borderColor: '#E2E8F0',
                      fontSize: '12px',
                    }}
                  />
                  <Bar
                    dataKey="avgScorePct"
                    name="avgScorePct"
                    fill="#2563EB"
                    radius={[4, 4, 0, 0]}
                    maxBarSize={32}
                  />
                  <Bar
                    dataKey="avgAttendancePct"
                    name="avgAttendancePct"
                    fill="#06B6D4"
                    radius={[4, 4, 0, 0]}
                    maxBarSize={32}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        <div className="lg:col-span-5 bg-white border border-slate-200/90 rounded-xl p-6">
          <div className="mb-4">
            <h2 className="text-base font-bold text-slate-900">Academic Progress Standing</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Distribution of faculty progress ratings across filtered reports
            </p>
          </div>

          {scopedReports.length === 0 ? (
            <div className="h-64 flex items-center justify-center text-sm text-slate-400 border border-dashed border-slate-200 rounded-lg">
              No academic evaluations recorded yet.
            </div>
          ) : (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={progressDistributionData}
                  layout="vertical"
                  margin={{ top: 8, right: 20, left: 20, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" horizontal={false} />
                  <XAxis type="number" allowDecimals={false} tick={{ fontSize: 11, fill: '#64748B' }} />
                  <YAxis
                    type="category"
                    dataKey="label"
                    width={105}
                    tick={{ fontSize: 11, fill: '#334155' }}
                  />
                  <Tooltip
                    formatter={(val) => [`${Number(val ?? 0)} report(s)`, 'Count']}
                    contentStyle={{
                      borderRadius: '10px',
                      borderColor: '#E2E8F0',
                      fontSize: '12px',
                    }}
                  />
                  <Bar dataKey="count" radius={[0, 4, 4, 0]} maxBarSize={26}>
                    {progressDistributionData.map((entry) => (
                      <Cell key={entry.label} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[240px]">
          <div className="relative flex-1 max-w-xs">
            <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search student, subject, teacher..."
              className="pl-9"
            />
          </div>

          <div className="w-44">
            <Select value={courseFilter} onValueChange={setCourseFilter}>
              <SelectTrigger>
                <SelectValue placeholder="All Courses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Courses</SelectItem>
                {courses.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="w-44">
            <Select
              value={progressFilter}
              onValueChange={(v) => setProgressFilter(v as 'ALL' | AcademicProgress)}
            >
              <SelectTrigger>
                <SelectValue placeholder="All Standings" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Standings</SelectItem>
                <SelectItem value={AcademicProgress.EXCELLENT}>Excellent</SelectItem>
                <SelectItem value={AcademicProgress.GOOD}>Good</SelectItem>
                <SelectItem value={AcademicProgress.SATISFACTORY}>Satisfactory</SelectItem>
                <SelectItem value={AcademicProgress.NEEDS_ATTENTION}>Needs Attention</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="inline-flex items-center rounded-lg bg-slate-100 p-1">
          <button
            type="button"
            onClick={() => setPeriodScope('ALL')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              periodScope === 'ALL' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
            }`}
          >
            All Periods
          </button>
          <button
            type="button"
            onClick={() => setPeriodScope('SELECTED')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              periodScope === 'SELECTED' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
            }`}
          >
            {formatPeriodLabel(selectedPeriod)} Only
          </button>
        </div>
      </div>

      {/* Reports Ledger */}
      {scopedReports.length === 0 ? (
        <EmptyState
          title="No student performance reports match your filters"
          description={
            eligibleStudents.length === 0
              ? 'Enroll active students and assign a faculty member first before submitting performance evaluations.'
              : 'Submit periodic academic assessments with test marks, attendance, strengths, and focus areas.'
          }
          actionLabel={eligibleStudents.length > 0 ? 'Submit First Report' : undefined}
          onAction={eligibleStudents.length > 0 ? openCreateModal : undefined}
        />
      ) : (
        <div className="bg-white border border-slate-200/90 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  <th className="py-3.5 px-4">Student & Course</th>
                  <th className="py-3.5 px-4">Period & Subject</th>
                  <th className="py-3.5 px-4 text-right">Attendance</th>
                  <th className="py-3.5 px-4 text-right">Test Score</th>
                  <th className="py-3.5 px-4">Standing</th>
                  <th className="py-3.5 px-4">Qualitative Feedback</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {scopedReports.map((r) => {
                  const pct = Math.round((r.testMarks / Math.max(1, r.maxMarks)) * 100);
                  return (
                    <tr key={r.id} className="hover:bg-slate-50/70 transition-colors align-top">
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-slate-900">{r.studentName}</div>
                        <div className="text-xs text-slate-500 mt-0.5">
                          {r.courseName} · Faculty: {r.teacherName}
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-medium text-slate-800">{r.subject}</div>
                        <div className="text-xs text-slate-500 mt-0.5">
                          {formatPeriodLabel(r.reportingPeriod)} · Submitted {r.submissionDate}
                        </div>
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono tabular-nums text-slate-800">
                        {r.attendancePercent}%
                      </td>
                      <td className="py-3.5 px-4 text-right font-mono tabular-nums">
                        <div className="font-bold text-slate-900">
                          {r.testMarks}/{r.maxMarks}
                        </div>
                        <div className="text-xs text-slate-500">{pct}%</div>
                      </td>
                      <td className="py-3.5 px-4">
                        <StatusText
                          tone={progressTone(r.academicProgress)}
                          label={PROGRESS_LABELS[r.academicProgress]}
                        />
                      </td>
                      <td className="py-3.5 px-4 max-w-xs">
                        <div className="text-xs text-slate-700">
                          <span className="font-semibold text-slate-900">Strengths:</span>{' '}
                          {r.strengths}
                        </div>
                        <div className="text-xs text-slate-600 mt-1">
                          <span className="font-semibold text-slate-800">Improve:</span>{' '}
                          {r.areasForImprovement}
                        </div>
                        {r.teacherComments && (
                          <div className="text-xs text-slate-500 mt-1 italic">
                            “{r.teacherComments}”
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right whitespace-nowrap">
                        <div className="inline-flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => openEditModal(r)}
                            title="Edit evaluation"
                          >
                            <Edit2 className="h-3.5 w-3.5" />
                            <span>Edit</span>
                          </Button>
                          <button
                            type="button"
                            onClick={() => setDeleteTargetReport(r)}
                            title="Delete evaluation"
                            className="p-1.5 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Submit / Edit Modal */}
      <Dialog open={modalOpen} onOpenChange={setModalOpen}>
        <DialogContent
          title={editingReport ? 'Edit Student Performance Report' : 'Submit Student Performance Report'}
          description="Record verified test marks, attendance percentage, and qualitative faculty observations."
          maxWidthClass="max-w-2xl"
        >
          <form onSubmit={handleSaveReport} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label>Student *</Label>
                <Select
                  value={studentId}
                  onValueChange={(val) => {
                    setStudentId(val);
                    const stu = eligibleStudents.find((s) => s.id === val);
                    if (stu && !editingReport) {
                      setSubject(stu.primaryCourseName);
                    }
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select assigned student" />
                  </SelectTrigger>
                  <SelectContent>
                    {eligibleStudents.map((s) => (
                      <SelectItem key={s.id} value={s.id}>
                        {s.fullName} ({s.studentCode})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="rep-period">Reporting Period (YYYY-MM) *</Label>
                <Input
                  id="rep-period"
                  type="month"
                  value={reportingPeriod}
                  onChange={(e) => setReportingPeriod(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="rep-subject">Subject / Assessment Topic *</Label>
                <Input
                  id="rep-subject"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g., Physics — Rotational Mechanics"
                  required
                />
              </div>

              <div>
                <Label>Academic Progress Standing *</Label>
                <Select
                  value={academicProgress}
                  onValueChange={(v) => setAcademicProgress(v as AcademicProgress)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={AcademicProgress.EXCELLENT}>Excellent</SelectItem>
                    <SelectItem value={AcademicProgress.GOOD}>Good</SelectItem>
                    <SelectItem value={AcademicProgress.SATISFACTORY}>Satisfactory</SelectItem>
                    <SelectItem value={AcademicProgress.NEEDS_ATTENTION}>
                      Needs Attention
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div>
                <Label htmlFor="rep-att">Attendance (%) *</Label>
                <Input
                  id="rep-att"
                  type="number"
                  min={0}
                  max={100}
                  step="1"
                  value={attendancePercent}
                  onChange={(e) => setAttendancePercent(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="rep-marks">Test Marks *</Label>
                <Input
                  id="rep-marks"
                  type="number"
                  min={0}
                  step="1"
                  value={testMarks}
                  onChange={(e) => setTestMarks(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="rep-max">Max Marks *</Label>
                <Input
                  id="rep-max"
                  type="number"
                  min={1}
                  step="1"
                  value={maxMarks}
                  onChange={(e) => setMaxMarks(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="rep-date">Submission Date *</Label>
                <Input
                  id="rep-date"
                  type="date"
                  value={submissionDate}
                  onChange={(e) => setSubmissionDate(e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="rep-strengths">Observed Strengths *</Label>
                <Textarea
                  id="rep-strengths"
                  value={strengths}
                  onChange={(e) => setStrengths(e.target.value)}
                  placeholder="Analytical speed, conceptual clarity in numerical problems..."
                  required
                />
              </div>
              <div>
                <Label htmlFor="rep-improve">Areas for Improvement *</Label>
                <Textarea
                  id="rep-improve"
                  value={areasForImprovement}
                  onChange={(e) => setAreasForImprovement(e.target.value)}
                  placeholder="Time allocation on multi-step derivations, revision consistency..."
                  required
                />
              </div>
            </div>

            <div>
              <Label htmlFor="rep-comments">Additional Teacher Comments</Label>
              <Textarea
                id="rep-comments"
                value={teacherComments}
                onChange={(e) => setTeacherComments(e.target.value)}
                placeholder="Optional remarks for guardian or institute academic review..."
              />
            </div>

            <div className="flex justify-end gap-2.5 pt-2">
              <Button type="button" variant="secondary" onClick={() => setModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting ? 'Saving...' : editingReport ? 'Update Report' : 'Submit Report'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDeleteDialog
        open={Boolean(deleteTargetReport)}
        onOpenChange={(o) => !o && setDeleteTargetReport(null)}
        title="Delete Performance Report"
        description={
          deleteTargetReport
            ? `Permanently delete the ${deleteTargetReport.subject} evaluation (${deleteTargetReport.reportingPeriod}) for ${deleteTargetReport.studentName}?`
            : ''
        }
        loading={submitting}
        onConfirm={handleConfirmDeleteReport}
      />
    </div>
  );
}

// Page 9: Operating Expenses
export function ExpensesPage() {
  const {
    activeRole,
    selectedPeriod,
    expenses,
    createExpense,
    updateExpense,
    reverseExpense,
    deleteExpense,
    getAuthToken,
    isDemoMode,
  } = useInstitute();

  const [categoryFilter, setCategoryFilter] = useState<'ALL' | ExpenseCategory>('ALL');
  const [periodMode, setPeriodMode] = useState<'SELECTED' | 'ALL'>('SELECTED');
  const [searchTerm, setSearchTerm] = useState('');

  const [addModalOpen, setAddModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const [deleteTargetExpense, setDeleteTargetExpense] = useState<Expense | null>(null);
  const [reverseTargetId, setReverseTargetId] = useState<string | null>(null);
  const [reverseReason, setReverseReason] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Add / Edit Expense Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ExpenseCategory>(ExpenseCategory.RENT);
  const [amountRupees, setAmountRupees] = useState('');
  const [expenseDate, setExpenseDate] = useState(getTodayIST());
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(PaymentMethod.BANK_TRANSFER);
  const [vendorName, setVendorName] = useState('');
  const [notes, setNotes] = useState('');
  const [expenseStatus, setExpenseStatus] = useState<'RECORDED' | 'REVERSED'>('RECORDED');

  if (activeRole === UserRole.TEACHER) {
    return <RestrictedFinanceNotice />;
  }

  const filteredExpenses = useMemo(() => {
    return expenses
      .filter((ex) => {
        if (periodMode === 'SELECTED' && ex.billingPeriod !== selectedPeriod) return false;
        if (categoryFilter !== 'ALL' && ex.category !== categoryFilter) return false;
        if (searchTerm.trim()) {
          const q = searchTerm.toLowerCase();
          return (
            ex.title.toLowerCase().includes(q) ||
            ex.vendorName.toLowerCase().includes(q) ||
            ex.category.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => b.expenseDate.localeCompare(a.expenseDate));
  }, [expenses, periodMode, selectedPeriod, categoryFilter, searchTerm]);

  const activeRecordedPaise = useMemo(
    () =>
      filteredExpenses
        .filter((e) => e.status === 'RECORDED')
        .reduce((sum, e) => sum + e.amountPaise, 0),
    [filteredExpenses]
  );

  const categoryBreakdown = useMemo(() => {
    const totals = new Map<ExpenseCategory, number>();
    for (const ex of filteredExpenses) {
      if (ex.status !== 'RECORDED') continue;
      totals.set(ex.category, (totals.get(ex.category) ?? 0) + ex.amountPaise);
    }
    return Array.from(totals.entries())
      .map(([cat, paise]) => ({
        category: cat,
        rupees: toRupees(paise),
        paise,
        fill: EXPENSE_CATEGORY_COLORS[cat],
      }))
      .sort((a, b) => b.paise - a.paise);
  }, [filteredExpenses]);

  const openAddExpenseModal = () => {
    setEditingExpense(null);
    setTitle('');
    setCategory(ExpenseCategory.RENT);
    setAmountRupees('');
    setExpenseDate(getTodayIST());
    setPaymentMethod(PaymentMethod.BANK_TRANSFER);
    setVendorName('');
    setNotes('');
    setExpenseStatus('RECORDED');
    setAddModalOpen(true);
  };

  const openEditExpenseModal = (ex: Expense) => {
    setEditingExpense(ex);
    setTitle(ex.title);
    setCategory(ex.category);
    setAmountRupees(String(ex.amountPaise / 100));
    setExpenseDate(ex.expenseDate);
    setPaymentMethod(ex.paymentMethod);
    setVendorName(ex.vendorName);
    setNotes(ex.notes);
    setExpenseStatus(ex.status);
    setAddModalOpen(true);
  };

  const handleSaveExpense = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      if (editingExpense) {
        await updateExpense(editingExpense.id, {
          title: title.trim(),
          category,
          amountRupees: Number(amountRupees),
          expenseDate,
          paymentMethod,
          vendorName: vendorName.trim(),
          notes: notes.trim(),
          status: expenseStatus,
        });
        toast.success('Operating expense updated.');
      } else {
        await createExpense({
          title: title.trim(),
          category,
          amountRupees: Number(amountRupees),
          expenseDate,
          paymentMethod,
          vendorName: vendorName.trim(),
          notes: notes.trim(),
        });
        toast.success('Operating expense recorded.');
      }
      setAddModalOpen(false);
      setEditingExpense(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to save expense.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmDeleteExpense = async () => {
    if (!deleteTargetExpense) return;
    setSubmitting(true);
    try {
      await deleteExpense(deleteTargetExpense.id);
      toast.success(`Deleted expense "${deleteTargetExpense.title}"`);
      setDeleteTargetExpense(null);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to delete expense.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleConfirmReverse = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reverseTargetId) return;
    setSubmitting(true);
    try {
      await reverseExpense(reverseTargetId, reverseReason.trim());
      toast.success('Expense reversed.');
      setReverseTargetId(null);
      setReverseReason('');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to reverse expense.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleExportExpensesCSV = async () => {
    try {
      const idToken = await getAuthToken();
      await downloadServerCSV({
        filename: `IIS_Expenses_${periodMode === 'SELECTED' ? selectedPeriod : 'All'}.csv`,
        headers: [
          'Date',
          'Period',
          'Expense Title',
          'Category',
          'Vendor',
          'Payment Mode',
          'Amount (INR)',
          'Status',
        ],
        rows: filteredExpenses.map((ex) => [
          ex.expenseDate,
          ex.billingPeriod,
          ex.title,
          ex.category,
          ex.vendorName || '-',
          ex.paymentMethod,
          toRupees(ex.amountPaise),
          ex.status,
        ]),
        idToken,
        isDemoMode,
      });
      toast.success('Expenses CSV exported.');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Export failed.');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="text-xs font-semibold text-blue-600">Non-Payroll Overhead Ledger</p>
          <h1 className="text-2xl font-extrabold text-slate-900 tracking-tight mt-0.5">
            Operating Expenses
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Track rent, utilities, study materials, marketing, and facility maintenance separately
            from teacher share payouts.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <Button variant="secondary" onClick={handleExportExpensesCSV}>
            <Download className="h-4 w-4" />
            <span>Export CSV</span>
          </Button>
          <Button onClick={openAddExpenseModal}>
            <Plus className="h-4 w-4" />
            <span>Record Expense</span>
          </Button>
        </div>
      </div>

      {/* Top Summary + Category Breakdown Chart */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 bg-white border border-slate-200/90 rounded-xl p-6 flex flex-col justify-between">
          <div>
            <div className="text-xs text-slate-500">
              Verified Operating Spend (
              {periodMode === 'SELECTED' ? formatPeriodLabel(selectedPeriod) : 'All Periods'})
            </div>
            <div className="text-3xl font-extrabold text-slate-900 font-mono tabular-nums mt-2">
              {formatINR(activeRecordedPaise)}
            </div>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Deducted directly alongside accrued teacher shares to compute Net Operating Income.
              Every expense voucher can be edited, reversed, or deleted.
            </p>
          </div>

          <div className="mt-6 pt-5 border-t border-slate-100 space-y-2.5">
            {categoryBreakdown.length === 0 ? (
              <div className="text-xs text-slate-400">No recorded expenses in current view.</div>
            ) : (
              categoryBreakdown.slice(0, 4).map((item) => (
                <div key={item.category} className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span
                      className="h-2.5 w-2.5 rounded-xs shrink-0"
                      style={{ backgroundColor: item.fill }}
                    />
                    <span className="font-medium text-slate-700">{item.category}</span>
                  </div>
                  <span className="font-mono tabular-nums font-semibold text-slate-900">
                    {formatINR(item.paise)}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="lg:col-span-7 bg-white border border-slate-200/90 rounded-xl p-6">
          <div className="mb-3">
            <h2 className="text-base font-bold text-slate-900">Expenses by Category</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Category distribution in INR across active recorded vouchers
            </p>
          </div>

          {categoryBreakdown.length === 0 ? (
            <div className="h-56 flex items-center justify-center text-sm text-slate-400 border border-dashed border-slate-200 rounded-lg">
              Record operating expenses to view category breakdown.
            </div>
          ) : (
            <div className="h-56 grid grid-cols-1 sm:grid-cols-2 items-center gap-4">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryBreakdown}
                    dataKey="rupees"
                    nameKey="category"
                    innerRadius={48}
                    outerRadius={80}
                    paddingAngle={2}
                  >
                    {categoryBreakdown.map((entry) => (
                      <Cell key={entry.category} fill={entry.fill} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(val) => [formatINR(Math.round(Number(val ?? 0) * 100)), 'Spend']}
                    contentStyle={{
                      borderRadius: '10px',
                      borderColor: '#E2E8F0',
                      fontSize: '12px',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>

              <div className="space-y-2">
                {categoryBreakdown.map((c) => {
                  const pct =
                    activeRecordedPaise > 0
                      ? ((c.paise / activeRecordedPaise) * 100).toFixed(1)
                      : '0.0';
                  return (
                    <div key={c.category} className="flex items-center justify-between text-xs">
                      <span className="text-slate-600">{c.category}</span>
                      <span className="font-mono tabular-nums text-slate-900 font-semibold">
                        {pct}% · {formatINR(c.paise)}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white border border-slate-200/90 rounded-xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[240px]">
          <div className="relative flex-1 max-w-xs">
            <Search className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <Input
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search title or vendor..."
              className="pl-9"
            />
          </div>

          <div className="w-48">
            <Select
              value={categoryFilter}
              onValueChange={(v) => setCategoryFilter(v as 'ALL' | ExpenseCategory)}
            >
              <SelectTrigger>
                <SelectValue placeholder="All Categories" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Categories</SelectItem>
                {Object.values(ExpenseCategory).map((cat) => (
                  <SelectItem key={cat} value={cat}>
                    {cat}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="inline-flex items-center rounded-lg bg-slate-100 p-1">
          <button
            type="button"
            onClick={() => setPeriodMode('SELECTED')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              periodMode === 'SELECTED' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
            }`}
          >
            {formatPeriodLabel(selectedPeriod)}
          </button>
          <button
            type="button"
            onClick={() => setPeriodMode('ALL')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              periodMode === 'ALL' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
            }`}
          >
            All Months
          </button>
        </div>
      </div>

      {/* Expenses Ledger Table */}
      {filteredExpenses.length === 0 ? (
        <EmptyState
          title="No operating expenses recorded for this filter"
          description="Record campus rent, electricity, study material printing, software subscriptions, or marketing vouchers."
          actionLabel="Record Expense"
          onAction={openAddExpenseModal}
        />
      ) : (
        <div className="bg-white border border-slate-200/90 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  <th className="py-3.5 px-4">Date</th>
                  <th className="py-3.5 px-4">Expense Item & Vendor</th>
                  <th className="py-3.5 px-4">Category</th>
                  <th className="py-3.5 px-4">Mode</th>
                  <th className="py-3.5 px-4 text-right">Amount</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-sm">
                {filteredExpenses.map((ex) => (
                  <tr key={ex.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3.5 px-4 font-mono text-xs text-slate-600">
                      {ex.expenseDate}
                    </td>
                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-slate-900">{ex.title}</div>
                      <div className="text-xs text-slate-500 mt-0.5">
                        {ex.vendorName ? `Vendor: ${ex.vendorName}` : 'Direct voucher'}
                        {ex.notes ? ` · ${ex.notes}` : ''}
                      </div>
                    </td>
                    <td className="py-3.5 px-4 text-xs font-semibold text-slate-700">
                      {ex.category}
                    </td>
                    <td className="py-3.5 px-4 text-xs text-slate-600">
                      {ex.paymentMethod.replace('_', ' ')}
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono tabular-nums font-bold text-slate-900">
                      {ex.status === 'REVERSED' ? (
                        <span className="line-through text-slate-400">
                          {formatINR(ex.amountPaise)}
                        </span>
                      ) : (
                        formatINR(ex.amountPaise)
                      )}
                    </td>
                    <td className="py-3.5 px-4">
                      <StatusText
                        tone={ex.status === 'RECORDED' ? 'positive' : 'danger'}
                        label={ex.status}
                      />
                    </td>
                    <td className="py-3.5 px-4 text-right whitespace-nowrap">
                      <div className="inline-flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => openEditExpenseModal(ex)}
                          title="Edit expense"
                          className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                        >
                          <Edit2 className="h-3.5 w-3.5" />
                        </button>
                        {ex.status === 'RECORDED' && (
                          <button
                            type="button"
                            onClick={() => {
                              setReverseTargetId(ex.id);
                              setReverseReason('');
                            }}
                            title="Reverse expense"
                            className="p-1.5 rounded-md text-slate-400 hover:text-amber-700 hover:bg-amber-50 cursor-pointer"
                          >
                            <RotateCcw className="h-3.5 w-3.5" />
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => setDeleteTargetExpense(ex)}
                          title="Delete expense"
                          className="p-1.5 rounded-md text-slate-400 hover:text-red-600 hover:bg-red-50 cursor-pointer"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Add / Edit Expense Dialog */}
      <Dialog
        open={addModalOpen}
        onOpenChange={(o) => {
          setAddModalOpen(o);
          if (!o) setEditingExpense(null);
        }}
      >
        <DialogContent
          title={editingExpense ? 'Edit Operating Expense' : 'Record Operating Expense'}
          description="Entries are stored in integer paise and linked to the IST billing month of the expense date."
        >
          <form onSubmit={handleSaveExpense} className="space-y-4">
            <div>
              <Label htmlFor="exp-title">Expense Description *</Label>
              <Input
                id="exp-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Main Campus Monthly Classroom Lease"
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label>Category *</Label>
                <Select
                  value={category}
                  onValueChange={(v) => setCategory(v as ExpenseCategory)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.values(ExpenseCategory).map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="exp-amount">Amount (INR) *</Label>
                <Input
                  id="exp-amount"
                  type="number"
                  min={1}
                  step="0.01"
                  value={amountRupees}
                  onChange={(e) => setAmountRupees(e.target.value)}
                  placeholder="15000"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="exp-date">Expense Date *</Label>
                <Input
                  id="exp-date"
                  type="date"
                  value={expenseDate}
                  onChange={(e) => setExpenseDate(e.target.value)}
                  required
                />
              </div>

              <div>
                <Label>Payment Method *</Label>
                <Select
                  value={paymentMethod}
                  onValueChange={(v) => setPaymentMethod(v as PaymentMethod)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={PaymentMethod.BANK_TRANSFER}>Bank Transfer</SelectItem>
                    <SelectItem value={PaymentMethod.UPI}>UPI</SelectItem>
                    <SelectItem value={PaymentMethod.CASH}>Cash</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="exp-vendor">Vendor / Payee Name</Label>
                <Input
                  id="exp-vendor"
                  value={vendorName}
                  onChange={(e) => setVendorName(e.target.value)}
                  placeholder="e.g., Saraswati Print House / BESCOM"
                />
              </div>

              {editingExpense && (
                <div>
                  <Label>Voucher Status</Label>
                  <Select
                    value={expenseStatus}
                    onValueChange={(v) => setExpenseStatus(v as 'RECORDED' | 'REVERSED')}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="RECORDED">RECORDED</SelectItem>
                      <SelectItem value="REVERSED">REVERSED</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            <div>
              <Label htmlFor="exp-notes">Voucher / Reference Notes</Label>
              <Textarea
                id="exp-notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Invoice reference or remarks..."
              />
            </div>

            <div className="flex justify-end gap-2.5 pt-2">
              <Button
                type="button"
                variant="secondary"
                onClick={() => {
                  setAddModalOpen(false);
                  setEditingExpense(null);
                }}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={submitting}>
                {submitting
                  ? 'Saving...'
                  : editingExpense
                  ? 'Save Expense Changes'
                  : 'Record Expense'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Reverse Expense Dialog */}
      <Dialog
        open={Boolean(reverseTargetId)}
        onOpenChange={(open) => {
          if (!open) setReverseTargetId(null);
        }}
      >
        <DialogContent
          title="Reverse Operating Expense"
          description="Marks this voucher REVERSED so it remains visible on the ledger without deducting from operating profit."
        >
          <form onSubmit={handleConfirmReverse} className="space-y-4">
            <div>
              <Label htmlFor="exp-rev-reason">Reversal Reason *</Label>
              <Textarea
                id="exp-rev-reason"
                value={reverseReason}
                onChange={(e) => setReverseReason(e.target.value)}
                placeholder="Duplicate voucher entry / vendor credit note issued..."
                required
              />
            </div>
            <div className="flex justify-end gap-2.5">
              <Button
                type="button"
                variant="secondary"
                onClick={() => setReverseTargetId(null)}
              >
                Cancel
              </Button>
              <Button type="submit" variant="danger" disabled={submitting || !reverseReason.trim()}>
                {submitting ? 'Reversing...' : 'Confirm Reversal'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <ConfirmDeleteDialog
        open={Boolean(deleteTargetExpense)}
        onOpenChange={(o) => !o && setDeleteTargetExpense(null)}
        title="Delete Operating Expense"
        description={
          deleteTargetExpense
            ? `Permanently delete expense "${deleteTargetExpense.title}" (${formatINR(deleteTargetExpense.amountPaise)})?`
            : ''
        }
        loading={submitting}
        onConfirm={handleConfirmDeleteExpense}
      />
    </div>
  );
}
