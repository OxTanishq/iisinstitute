import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, ArrowRight, PlayCircle } from 'lucide-react';
import { useInstitute } from '../../context/InstituteContext';
import { UserRole } from '../../shared/types';
import { Button } from '../ui/primitives';
import campusAtriumImg from '../../assets/images/iis_campus_atrium_1793203922348.jpg';

export function BrandMark({ logoUrl, size = 36 }: { logoUrl?: string; size?: number }) {
  const [imgFailed, setImgFailed] = useState(false);

  if (logoUrl && !imgFailed) {
    return (
      <img
        src={logoUrl}
        alt="IIS Institute Logo"
        referrerPolicy="no-referrer"
        onError={() => setImgFailed(true)}
        style={{ width: size, height: size }}
        className="rounded-lg object-cover shrink-0 border border-slate-200"
      />
    );
  }

  return (
    <div
      style={{ width: size, height: size }}
      className="rounded-lg bg-gradient-to-br from-blue-600 via-indigo-600 to-cyan-500 flex items-center justify-center text-white shrink-0 shadow-xs"
      aria-hidden="true"
    >
      <svg
        width={Math.round(size * 0.58)}
        height={Math.round(size * 0.58)}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
        <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
      </svg>
    </div>
  );
}

export function LoginScreen() {
  const { signInWithGoogle, enterDemoSandbox } = useInstitute();
  const [heroImgFailed, setHeroImgFailed] = useState(false);
  const [signingIn, setSigningIn] = useState(false);

  const handleGoogleLogin = async () => {
    setSigningIn(true);
    try {
      await signInWithGoogle();
    } finally {
      setSigningIn(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Clean 3-zone top bar */}
      <header className="flex items-center justify-between gap-8 px-6 lg:px-10 py-4 bg-white border-b border-slate-200/80">
        <div className="flex items-center gap-3 shrink-0">
          <BrandMark size={34} />
          <span className="text-base font-extrabold tracking-tight text-slate-900 whitespace-nowrap">
            IIS Institute
          </span>
        </div>

        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          <span className="whitespace-nowrap shrink-0">Student Roster</span>
          <span className="whitespace-nowrap shrink-0">Fee Ledger</span>
          <span className="whitespace-nowrap shrink-0">Faculty Shares</span>
          <span className="whitespace-nowrap shrink-0">Revenue Analytics</span>
        </nav>

        <div className="shrink-0">
          <Button onClick={handleGoogleLogin} disabled={signingIn} size="sm">
            {signingIn ? 'Connecting...' : 'Sign In with Google'}
          </Button>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-6 lg:px-10 py-10 lg:py-14 grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
        {/* Left Auth Column */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.2 }}
          className="lg:col-span-5 flex flex-col justify-center bg-white border border-slate-200/90 rounded-2xl p-8 lg:p-10 shadow-xs"
        >
          <p className="text-xs font-semibold text-blue-600 tracking-tight mb-2">
            Institute Administration & Faculty Portal
          </p>
          <h1
            className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight leading-tight"
            style={{ textWrap: 'balance' }}
          >
            Financial clarity and academic tracking for IIS Institute
          </h1>
          <p className="text-sm text-slate-600 mt-3 leading-relaxed">
            Manage enrollments, collect full or installment fees in Indian Rupees, compute
            historical faculty revenue shares, and identify margin bottlenecks from verified Cloud
            Firestore records.
          </p>

          <div className="mt-8 space-y-3">
            <Button
              onClick={handleGoogleLogin}
              disabled={signingIn}
              size="lg"
              className="w-full justify-center"
            >
              <svg className="h-4 w-4 bg-white rounded-xs p-0.5" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17Z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.3 0 6.08-1.09 8.11-2.96l-3.88-3.05c-1.1.74-2.51 1.18-4.23 1.18-3.26 0-6.02-2.2-7-5.16H1.01v3.14C3.05 21.2 7.24 24 12 24Z"
                />
                <path
                  fill="#FBBC05"
                  d="M5 14.01c-.25-.74-.39-1.54-.39-2.36 0-.82.14-1.62.39-2.36V6.15H1.01C.37 7.43 0 8.87 0 10.39s.37 2.96 1.01 4.24L5 14.01Z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.79 0 3.41.62 4.68 1.82l3.51-3.51C18.07 1.19 15.3 0 12 0 7.24 0 3.05 2.8 1.01 6.85L5 9.99c.98-2.96 3.74-5.24 7-5.24Z"
                />
              </svg>
              <span>{signingIn ? 'Authenticating...' : 'Continue with Google Sign-In'}</span>
              <ArrowRight className="h-4 w-4 ml-1" />
            </Button>

            <div className="pt-4 border-t border-slate-100">
              <p className="text-xs font-semibold text-slate-700 mb-2">
                Separate Evaluation Environment (Zero Production Writes)
              </p>
              <div className="grid grid-cols-3 gap-2">
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() => enterDemoSandbox(UserRole.ADMIN)}
                >
                  <PlayCircle className="h-3.5 w-3.5 text-blue-600" />
                  <span>Demo Admin</span>
                </Button>
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() => enterDemoSandbox(UserRole.TEACHER)}
                >
                  <span>Demo Teacher</span>
                </Button>
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  onClick={() => enterDemoSandbox(UserRole.ACCOUNTANT)}
                >
                  <span>Demo Accounts</span>
                </Button>
              </div>
              <p className="text-[11px] text-slate-500 mt-2 leading-normal">
                Demo mode loads realistic 12-month sample records in isolated memory so your live
                Firestore database stays completely clean.
              </p>
            </div>
          </div>

          <div className="mt-8 pt-5 border-t border-slate-100 flex items-start gap-2.5 text-xs text-slate-500">
            <ShieldCheck className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
            <span>
              Protected by Zero-Trust Firestore Security Rules, role-based least-privilege access,
              and integer-paise financial precision (Asia/Kolkata IST).
            </span>
          </div>
        </motion.div>

        {/* Right Showcase Visual Column */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.25 }}
          className="lg:col-span-7 relative rounded-2xl overflow-hidden border border-slate-200/90 min-h-[380px] bg-gradient-to-br from-slate-900 via-indigo-950 to-blue-950 flex flex-col justify-end"
        >
          {!heroImgFailed && (
            <img
              src={campusAtriumImg}
              alt="Modern academic study hall and library atrium at IIS Institute"
              referrerPolicy="no-referrer"
              onError={() => setHeroImgFailed(true)}
              className="absolute inset-0 w-full h-full object-cover"
            />
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/45 to-transparent" />

          <div className="relative z-10 p-8 lg:p-10 text-white">
            <p className="text-xs font-medium text-cyan-300 mb-2">
              Unified Operations · Fee Realization · Faculty Shares · Academic Progress
            </p>
            <h2
              className="text-xl sm:text-2xl font-bold tracking-tight max-w-xl"
              style={{ textWrap: 'balance' }}
            >
              Built to separate invoiced fees from verified collections and accrued teacher shares
              from actual disbursements.
            </h2>

            <div className="grid grid-cols-3 gap-6 mt-6 pt-6 border-t border-white/15">
              <div>
                <div className="text-lg font-bold font-mono tabular-nums text-white">INR · Paise</div>
                <div className="text-xs text-slate-300 mt-0.5">Exact integer ledger</div>
              </div>
              <div>
                <div className="text-lg font-bold font-mono tabular-nums text-white">4 Models</div>
                <div className="text-xs text-slate-300 mt-0.5">Historical teacher shares</div>
              </div>
              <div>
                <div className="text-lg font-bold font-mono tabular-nums text-white">IST Period</div>
                <div className="text-xs text-slate-300 mt-0.5">Asia/Kolkata analytics</div>
              </div>
            </div>
          </div>
        </motion.div>
      </main>
    </div>
  );
}
