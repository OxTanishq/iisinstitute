import React, { useState } from 'react';
import {
  LayoutDashboard,
  Users,
  UserSquare2,
  ReceiptIndianRupee,
  AlertCircle,
  GraduationCap,
  WalletCards,
  ClipboardCheck,
  Building2,
  LineChart,
  TrendingUp,
  FileSpreadsheet,
  Settings,
  PanelLeftClose,
  PanelLeftOpen,
  Menu,
  X,
  LogOut,
  FlaskConical,
} from 'lucide-react';
import { useInstitute } from '../../context/InstituteContext';
import { NavPageId, UserRole } from '../../shared/types';
import { formatPeriodLabel, getCurrentPeriodIST, getTrailingPeriods } from '../../shared/finance';
import { BrandMark } from '../auth/LoginScreen';
import {
  Button,
  cn,
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/primitives';

export interface NavItemSpec {
  id: NavPageId;
  label: string;
  group: 'Workspace' | 'Fee & Payroll' | 'Intelligence';
  icon: React.ComponentType<{ className?: string }>;
  allowedRoles: UserRole[];
}

export const NAV_ITEMS: NavItemSpec[] = [
  {
    id: 'overview',
    label: 'Overview Dashboard',
    group: 'Workspace',
    icon: LayoutDashboard,
    allowedRoles: [UserRole.ADMIN, UserRole.ACCOUNTANT, UserRole.TEACHER],
  },
  {
    id: 'students',
    label: 'Students',
    group: 'Workspace',
    icon: Users,
    allowedRoles: [UserRole.ADMIN, UserRole.ACCOUNTANT, UserRole.TEACHER],
  },
  {
    id: 'student-profiles',
    label: 'Student Profiles',
    group: 'Workspace',
    icon: UserSquare2,
    allowedRoles: [UserRole.ADMIN, UserRole.ACCOUNTANT, UserRole.TEACHER],
  },
  {
    id: 'performance-reports',
    label: 'Student Performance Reports',
    group: 'Workspace',
    icon: ClipboardCheck,
    allowedRoles: [UserRole.ADMIN, UserRole.TEACHER],
  },
  {
    id: 'fee-collection',
    label: 'Fee Collection',
    group: 'Fee & Payroll',
    icon: ReceiptIndianRupee,
    allowedRoles: [UserRole.ADMIN, UserRole.ACCOUNTANT],
  },
  {
    id: 'outstanding-fees',
    label: 'Outstanding Fees',
    group: 'Fee & Payroll',
    icon: AlertCircle,
    allowedRoles: [UserRole.ADMIN, UserRole.ACCOUNTANT],
  },
  {
    id: 'teachers',
    label: 'Teachers',
    group: 'Fee & Payroll',
    icon: GraduationCap,
    allowedRoles: [UserRole.ADMIN, UserRole.TEACHER],
  },
  {
    id: 'teacher-payouts',
    label: 'Teacher Payouts',
    group: 'Fee & Payroll',
    icon: WalletCards,
    allowedRoles: [UserRole.ADMIN, UserRole.ACCOUNTANT, UserRole.TEACHER],
  },
  {
    id: 'expenses',
    label: 'Expenses',
    group: 'Fee & Payroll',
    icon: Building2,
    allowedRoles: [UserRole.ADMIN, UserRole.ACCOUNTANT],
  },
  {
    id: 'revenue-analytics',
    label: 'Revenue Analytics',
    group: 'Intelligence',
    icon: LineChart,
    allowedRoles: [UserRole.ADMIN, UserRole.ACCOUNTANT],
  },
  {
    id: 'growth-insights',
    label: 'Growth Insights',
    group: 'Intelligence',
    icon: TrendingUp,
    allowedRoles: [UserRole.ADMIN, UserRole.ACCOUNTANT],
  },
  {
    id: 'financial-reports',
    label: 'Financial Reports',
    group: 'Intelligence',
    icon: FileSpreadsheet,
    allowedRoles: [UserRole.ADMIN, UserRole.ACCOUNTANT],
  },
  {
    id: 'settings',
    label: 'Settings',
    group: 'Intelligence',
    icon: Settings,
    allowedRoles: [UserRole.ADMIN, UserRole.ACCOUNTANT, UserRole.TEACHER],
  },
];

export function AppShell({
  activePage,
  onNavigate,
  children,
}: {
  activePage: NavPageId;
  onNavigate: (page: NavPageId) => void;
  children: React.ReactNode;
}) {
  const {
    settings,
    currentUserProfile,
    activeRole,
    isDemoMode,
    selectedPeriod,
    setSelectedPeriod,
    signOutUser,
    exitDemoSandbox,
    switchDemoRole,
  } = useInstitute();

  const [collapsed, setCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const periodOptions = getTrailingPeriods(getCurrentPeriodIST(), 15).reverse();
  const currentNavSpec = NAV_ITEMS.find((n) => n.id === activePage) ?? NAV_ITEMS[0];

  const renderSidebarLinks = (isMobile = false) => {
    const groups: Array<NavItemSpec['group']> = ['Workspace', 'Fee & Payroll', 'Intelligence'];

    return (
      <div className="flex-1 overflow-y-auto py-4 px-3 space-y-6">
        {groups.map((grp) => {
          const groupItems = NAV_ITEMS.filter((item) => item.group === grp);
          return (
            <div key={grp}>
              {(!collapsed || isMobile) && (
                <div className="px-3 mb-2 text-[11px] font-semibold text-slate-400 tracking-wide">
                  {grp}
                </div>
              )}
              <div className="space-y-0.5">
                {groupItems.map((item) => {
                  const Icon = item.icon;
                  const isActive = activePage === item.id;
                  const isPermitted = item.allowedRoles.includes(activeRole);

                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        onNavigate(item.id);
                        if (isMobile) setMobileMenuOpen(false);
                      }}
                      title={collapsed && !isMobile ? item.label : undefined}
                      className={cn(
                        'w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors cursor-pointer text-left',
                        isActive
                          ? 'bg-gradient-to-r from-blue-50 to-indigo-50/70 text-blue-700 font-semibold'
                          : isPermitted
                          ? 'text-slate-600 hover:bg-slate-100/80 hover:text-slate-900 font-medium'
                          : 'text-slate-400 hover:bg-slate-50 font-normal'
                      )}
                    >
                      <Icon
                        className={cn(
                          'h-4 w-4 shrink-0',
                          isActive
                            ? 'text-blue-600'
                            : isPermitted
                            ? 'text-slate-500'
                            : 'text-slate-300'
                        )}
                      />
                      {(!collapsed || isMobile) && (
                        <span className="truncate flex-1">{item.label}</span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Desktop Collapsible Sidebar */}
      <aside
        className={cn(
          'hidden lg:flex flex-col bg-white border-r border-slate-200/90 sticky top-0 h-screen shrink-0 transition-[width] duration-150',
          collapsed ? 'w-[72px]' : 'w-[264px]'
        )}
      >
        <div className="h-16 flex items-center justify-between px-4 border-b border-slate-100">
          <button
            type="button"
            onClick={() => onNavigate('overview')}
            className="flex items-center gap-2.5 min-w-0 cursor-pointer text-left"
          >
            <BrandMark logoUrl={settings.logoUrl} size={32} />
            {!collapsed && (
              <span className="text-sm font-extrabold text-slate-900 truncate">
                {settings.instituteName || 'IIS Institute'}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setCollapsed((c) => !c)}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 cursor-pointer shrink-0"
          >
            {collapsed ? (
              <PanelLeftOpen className="h-4 w-4" />
            ) : (
              <PanelLeftClose className="h-4 w-4" />
            )}
          </button>
        </div>

        {renderSidebarLinks(false)}

        {/* User Footer */}
        <div className="p-3 border-t border-slate-100">
          {!collapsed ? (
            <div className="flex items-center justify-between gap-2 px-2 py-1.5">
              <div className="min-w-0">
                <div className="text-xs font-bold text-slate-900 truncate">
                  {currentUserProfile?.displayName ?? 'Institute Staff'}
                </div>
                <div className="text-[11px] text-slate-500 truncate">
                  {activeRole} · IST
                </div>
              </div>
              <button
                type="button"
                onClick={signOutUser}
                title="Sign out"
                className="p-2 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer shrink-0"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={signOutUser}
              title="Sign out"
              className="w-full flex justify-center p-2 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 transition-colors cursor-pointer"
            >
              <LogOut className="h-4 w-4" />
            </button>
          )}
        </div>
      </aside>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/45 backdrop-blur-xs"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative z-10 w-[280px] max-w-[85vw] bg-white h-full flex flex-col shadow-xl">
            <div className="h-16 flex items-center justify-between px-4 border-b border-slate-100">
              <div className="flex items-center gap-2.5 min-w-0">
                <BrandMark logoUrl={settings.logoUrl} size={30} />
                <span className="text-sm font-extrabold text-slate-900 truncate">
                  {settings.instituteName || 'IIS Institute'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close navigation menu"
                className="p-1.5 rounded-lg text-slate-500 hover:bg-slate-100"
              >
                <X className="h-4 w-4" />
              </button>
            </div>
            {renderSidebarLinks(true)}
            <div className="p-4 border-t border-slate-100">
              <Button variant="secondary" size="sm" onClick={signOutUser} className="w-full">
                <LogOut className="h-3.5 w-3.5" />
                <span>{isDemoMode ? 'Exit Demo Sandbox' : 'Sign Out'}</span>
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Clean 3-Zone Top Bar */}
        <header className="h-16 bg-white/90 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-8 sticky top-0 z-30">
          {/* Zone 1: Mobile Menu Trigger + Breadcrumb */}
          <div className="flex items-center gap-3 min-w-0 shrink-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open menu"
              className="lg:hidden p-2 rounded-lg text-slate-600 hover:bg-slate-100"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2 text-sm min-w-0">
              <span className="hidden sm:inline text-slate-400 font-medium whitespace-nowrap">
                {currentNavSpec.group}
              </span>
              <span className="hidden sm:inline text-slate-300" aria-hidden="true">
                /
              </span>
              <span className="font-bold text-slate-900 truncate whitespace-nowrap">
                {currentNavSpec.label}
              </span>
            </div>
          </div>

          {/* Zone 2: Reporting Period Selector */}
          <div className="hidden md:flex items-center gap-2 shrink-0">
            <span className="text-xs text-slate-500 font-medium whitespace-nowrap">
              Reporting Period:
            </span>
            <div className="w-40">
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger aria-label="Select reporting month">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {periodOptions.map((p) => (
                    <SelectItem key={p} value={p}>
                      {formatPeriodLabel(p)} ({p})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Zone 3: Single Primary Action */}
          <div className="flex items-center gap-3 shrink-0">
            {activeRole !== UserRole.TEACHER ? (
              <Button
                size="sm"
                onClick={() => onNavigate('fee-collection')}
                variant={activePage === 'fee-collection' ? 'secondary' : 'primary'}
              >
                Collect Fee
              </Button>
            ) : (
              <Button
                size="sm"
                onClick={() => onNavigate('performance-reports')}
                variant={activePage === 'performance-reports' ? 'secondary' : 'primary'}
              >
                Submit Report
              </Button>
            )}
          </div>
        </header>

        {/* Isolated Demo Sandbox Banner + Mobile Period Picker */}
        {isDemoMode && (
          <div className="bg-indigo-950 text-white px-4 sm:px-6 lg:px-8 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <FlaskConical className="h-4 w-4 text-cyan-300 shrink-0" />
              <span>
                <strong>Isolated Demo Sandbox:</strong> Sample records run strictly in browser
                memory. Your production Cloud Firestore database remains untouched.
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1 bg-white/10 p-0.5 rounded-md">
                {([UserRole.ADMIN, UserRole.TEACHER, UserRole.ACCOUNTANT] as UserRole[]).map(
                  (r) => (
                    <button
                      key={r}
                      type="button"
                      onClick={() => switchDemoRole(r)}
                      className={cn(
                        'px-2.5 py-1 rounded text-[11px] font-semibold transition-colors cursor-pointer whitespace-nowrap',
                        activeRole === r
                          ? 'bg-white text-slate-900'
                          : 'text-slate-200 hover:text-white'
                      )}
                    >
                      {r}
                    </button>
                  )
                )}
              </div>
              <button
                type="button"
                onClick={exitDemoSandbox}
                className="underline text-cyan-300 hover:text-white font-semibold ml-2 cursor-pointer whitespace-nowrap"
              >
                Switch to Live Sign-In
              </button>
            </div>
          </div>
        )}

        <div className="md:hidden px-4 pt-3">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger aria-label="Select reporting month">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {periodOptions.map((p) => (
                <SelectItem key={p} value={p}>
                  {formatPeriodLabel(p)} ({p})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Page Viewport */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1440px] w-full mx-auto">{children}</main>
      </div>
    </div>
  );
}
